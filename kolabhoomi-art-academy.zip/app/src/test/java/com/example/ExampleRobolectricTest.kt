package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.UserRole
import com.example.ui.viewmodel.AcademyViewModel
import com.example.util.PdfDocumentGenerator
import com.example.util.QrCodeMatrix
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read academy app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Kolabhoomi Art Academy", appName)
    }

    @Test
    fun `role based login and analytics data load cleanly`() {
        val vm = AcademyViewModel()
        val adminLogin = vm.login("KAA-ADM-001", "admin123")
        assertTrue(adminLogin.isSuccess)
        assertEquals(UserRole.SUPER_ADMIN, adminLogin.getOrThrow().role)

        val state = vm.uiState.value
        assertTrue(state.students.isNotEmpty())
        assertTrue(state.branches.size >= 4)
        assertEquals(8, state.courses.size)
        assertTrue(state.monthlyRevenueHistory.size >= 6)
        assertTrue(state.branchAttendanceStats().isNotEmpty())
        assertTrue(state.courseEnrollmentDistribution().isNotEmpty())
    }

    @Test
    fun `qr matrix and pdf documents generate cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vm = AcademyViewModel()
        val state = vm.uiState.value

        val qr = QrCodeMatrix.generate("https://verify.kolabhoomi.edu/cert/KAA-CERT-2026-8492")
        assertEquals(QrCodeMatrix.SIZE, qr.size)

        val result = state.examResults.first()
        val fee = state.feeRecords.first()

        val marksheetPdf = PdfDocumentGenerator.exportMarksheetPdf(context, state.academyInfo, result)
        assertTrue(marksheetPdf.isSuccess)
        assertTrue(marksheetPdf.getOrThrow().length() > 0)

        val receiptPdf = PdfDocumentGenerator.exportPaymentReceiptPdf(context, state.academyInfo, fee, state.branchName(fee.branchId))
        assertTrue(receiptPdf.isSuccess)
        assertTrue(receiptPdf.getOrThrow().length() > 0)

        val certPdf = PdfDocumentGenerator.exportCertificatePdf(context, state.academyInfo, result)
        assertTrue(certPdf.isSuccess)
        assertTrue(certPdf.getOrThrow().length() > 0)
    }
}

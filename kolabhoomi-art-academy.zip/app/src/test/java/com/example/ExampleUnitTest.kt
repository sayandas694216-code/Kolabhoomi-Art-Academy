package com.example

import com.example.data.model.AttendanceStatus
import com.example.data.model.Branch
import com.example.data.model.FeeType
import com.example.data.model.UserRole
import com.example.ui.viewmodel.AcademyViewModel
import com.example.util.QrCodeMatrix
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun roleBasedAuthentication_worksForAllThreeRoles() {
        val vm = AcademyViewModel()

        val admin = vm.login("KAA-ADM-001", "admin123")
        assertTrue(admin.isSuccess)
        assertEquals(UserRole.SUPER_ADMIN, admin.getOrThrow().role)

        val teacher = vm.login("KAA-TCH-101", "teach123")
        assertTrue(teacher.isSuccess)
        assertEquals(UserRole.TEACHER, teacher.getOrThrow().role)

        val student = vm.login("KAA-STU-2026-001", "student123")
        assertTrue(student.isSuccess)
        assertEquals(UserRole.STUDENT, student.getOrThrow().role)
    }

    @Test
    fun analyticsAndCoreModules_computeAccurately() {
        val vm = AcademyViewModel()
        val state = vm.uiState.value

        assertEquals(8, state.courses.size)
        assertTrue(state.branches.size >= 4)
        assertTrue(state.students.size >= 12)
        assertTrue(state.monthlyRevenueHistory.size >= 6)
        assertEquals(state.branches.size, state.branchAttendanceStats().size)
        assertEquals(state.courses.size, state.courseEnrollmentDistribution().size)
    }

    @Test
    fun unlimitedBranches_fees_and_qrMatrix_workEndToEnd() {
        val vm = AcademyViewModel()
        val initialBranches = vm.uiState.value.branches.size

        vm.addOrUpdateBranch(
            Branch(
                id = "BR-99",
                code = "HWH",
                name = "Howrah Riverside Studio",
                address = "12 GT Road, Howrah",
                coordinatorName = "Sri Dipankar Pal",
                coordinatorPhone = "+91 98300 00001",
                classTimings = "Tue–Sun • 09:00 AM – 07:00 PM"
            ),
            isEdit = false
        )
        assertEquals(initialBranches + 1, vm.uiState.value.branches.size)

        val student = vm.uiState.value.students.first()
        val receipt = vm.collectFeePayment(student, FeeType.MONTHLY_TUITION, "Dec 2026", 3200.0, 3200.0, "UPI / Bank")
        assertTrue(receipt.receiptNo.startsWith("KAA-RCP-"))

        vm.markAttendance("2026-11-25", student.id, student.fullName, false, student.branchId, "Drawing", AttendanceStatus.PRESENT)
        assertTrue(vm.uiState.value.attendanceRecords.any { it.date == "2026-11-25" && it.personId == student.id })

        val qr = QrCodeMatrix.generate("https://verify.kolabhoomi.edu/cert/KAA-CERT-2026-8492")
        assertEquals(QrCodeMatrix.SIZE, qr.size)
        assertTrue(qr[0][0]) // Top-left QR finder corner
    }
}

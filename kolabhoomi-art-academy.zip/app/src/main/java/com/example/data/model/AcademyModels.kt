package com.example.data.model

enum class UserRole(val displayName: String, val badgeLabel: String) {
    SUPER_ADMIN("Super Admin", "Director / Owner"),
    TEACHER("Teacher", "Faculty"),
    STUDENT("Student", "Scholar")
}

data class UserAccount(
    val userId: String,
    val password: String,
    val role: UserRole,
    val fullName: String,
    val email: String,
    val phone: String,
    val linkedEntityId: String = "",
    val isActive: Boolean = true
)

data class AcademyInfo(
    val name: String = "KOLABHOOMI ART ACADEMY",
    val officialSubtitle: String = "OFFICIAL ACADEMY MANAGEMENT PORTAL",
    val tagline: String = "Nurturing Fine Arts, Classical Music & Cultural Excellence",
    val registrationNo: String = "REG/WB/ART/2018/04921",
    val address: String = "42 Rashbehari Heritage Avenue, South Kolkata - 700029",
    val phone: String = "+91 98300 41280",
    val email: String = "registrar@kolabhoomiartacademy.edu.in",
    val website: String = "www.kolabhoomiartacademy.edu.in",
    val logoUri: String? = null,
    val principalName: String = "Acharya Debabrata Sen",
    val directorName: String = "Smt. Ananya Chatterjee",
    val controllerName: String = "Prof. Subhashis Roy"
)

data class Branch(
    val id: String,
    val code: String,
    val name: String,
    val address: String,
    val coordinatorName: String,
    val coordinatorPhone: String,
    val classTimings: String,
    val establishedYear: Int = 2020
)

data class Course(
    val id: String,
    val name: String,
    val category: String,
    val monthlyFee: Double,
    val admissionFee: Double,
    val durationMonths: Int,
    val description: String,
    val assignedTeacherIds: List<String> = emptyList()
)

enum class StudentStatus(val label: String) {
    ACTIVE("Active"),
    ON_LEAVE("On Leave"),
    ALUMNI("Alumni"),
    INACTIVE("Inactive")
}

data class Student(
    val id: String,
    val fullName: String,
    val dateOfBirth: String,
    val gender: String,
    val phone: String,
    val email: String,
    val address: String,
    val photoUri: String? = null,
    val guardianName: String,
    val guardianPhone: String,
    val guardianRelation: String,
    val branchId: String,
    val courseIds: List<String>,
    val admissionDate: String,
    val status: StudentStatus = StudentStatus.ACTIVE
)

data class SalaryRecord(
    val id: String,
    val month: String,
    val amount: Double,
    val status: String,
    val paidDate: String
)

data class Teacher(
    val id: String,
    val fullName: String,
    val specialization: String,
    val qualification: String,
    val phone: String,
    val email: String,
    val address: String,
    val branchIds: List<String>,
    val courseIds: List<String>,
    val monthlySalary: Double,
    val joiningDate: String,
    val classSchedule: String,
    val salaryRecords: List<SalaryRecord> = emptyList()
)

enum class AttendanceStatus(val label: String, val shortCode: String) {
    PRESENT("Present", "P"),
    ABSENT("Absent", "A"),
    LEAVE("Leave", "L")
}

data class AttendanceRecord(
    val id: String,
    val date: String,
    val personId: String,
    val personName: String,
    val isTeacher: Boolean,
    val branchId: String,
    val courseName: String,
    val status: AttendanceStatus,
    val remarks: String = ""
)

enum class FeeType(val label: String) {
    ADMISSION("Admission Fee"),
    MONTHLY_TUITION("Monthly Tuition"),
    COURSE_FEE("Course Material Fee"),
    EXAM_FEE("Examination Fee")
}

enum class FeeStatus(val label: String) {
    PAID("Paid"),
    PENDING("Pending"),
    PARTIAL("Partial"),
    OVERDUE("Overdue")
}

data class FeeRecord(
    val id: String,
    val receiptNo: String,
    val studentId: String,
    val studentName: String,
    val branchId: String,
    val courseName: String,
    val feeType: FeeType,
    val billingMonth: String,
    val amount: Double,
    val paidAmount: Double,
    val paymentDate: String,
    val paymentMode: String,
    val status: FeeStatus
) {
    val balanceDue: Double get() = (amount - paidAmount).coerceAtLeast(0.0)
}

data class ExpenseRecord(
    val id: String,
    val title: String,
    val category: String,
    val branchId: String,
    val amount: Double,
    val date: String,
    val vendor: String
)

data class Examination(
    val id: String,
    val title: String,
    val session: String,
    val courseId: String,
    val branchId: String,
    val examDate: String,
    val maxTheory: Int = 30,
    val maxPractical: Int = 40,
    val maxProject: Int = 20,
    val maxTeamwork: Int = 10
) {
    val totalMaxMarks: Int get() = maxTheory + maxPractical + maxProject + maxTeamwork
}

data class ExamResult(
    val id: String,
    val examId: String,
    val examTitle: String,
    val session: String,
    val studentId: String,
    val studentName: String,
    val courseName: String,
    val branchName: String,
    val theoryMarks: Int,
    val practicalMarks: Int,
    val projectMarks: Int,
    val teamworkMarks: Int,
    val maxTheory: Int = 30,
    val maxPractical: Int = 40,
    val maxProject: Int = 20,
    val maxTeamwork: Int = 10,
    val remarks: String = "Exemplary artistic discipline and presentation.",
    val certificateId: String? = null,
    val issuedDate: String = "2026-11-20"
) {
    val totalObtained: Int get() = theoryMarks + practicalMarks + projectMarks + teamworkMarks
    val totalMax: Int get() = maxTheory + maxPractical + maxProject + maxTeamwork
    val percentage: Double get() = if (totalMax > 0) (totalObtained * 100.0) / totalMax else 0.0
    val grade: String
        get() = when {
            percentage >= 90 -> "A+ (Distinction)"
            percentage >= 80 -> "A (First Class)"
            percentage >= 70 -> "B+ (Merit)"
            percentage >= 60 -> "B (Pass)"
            percentage >= 45 -> "C (Pass)"
            else -> "D (Re-Appear)"
        }
    val shortGrade: String
        get() = when {
            percentage >= 90 -> "A+"
            percentage >= 80 -> "A"
            percentage >= 70 -> "B+"
            percentage >= 60 -> "B"
            percentage >= 45 -> "C"
            else -> "D"
        }
    val isPassed: Boolean get() = percentage >= 45.0
}

enum class NoticeCategory(val label: String) {
    FEE_REMINDER("Fee Reminder"),
    ATTENDANCE("Attendance"),
    EXAM("Exam Announcement"),
    ADMISSION("New Admission"),
    GENERAL("Important Notice")
}

data class AcademyNotice(
    val id: String,
    val title: String,
    val body: String,
    val category: NoticeCategory,
    val date: String,
    val targetAudience: String = "All Members",
    val isRead: Boolean = false
)

data class ActivityLog(
    val id: String,
    val title: String,
    val subtitle: String,
    val timestamp: String,
    val category: String
)

data class MonthlyRevenuePoint(
    val month: String,
    val revenue: Double,
    val expenses: Double
)

data class BranchAttendanceStat(
    val branchId: String,
    val branchCode: String,
    val branchName: String,
    val presentPercent: Float,
    val absentPercent: Float,
    val leavePercent: Float,
    val totalMarked: Int
)

data class CourseEnrollmentSlice(
    val courseId: String,
    val courseName: String,
    val studentCount: Int,
    val monthlyRevenuePotential: Double
)

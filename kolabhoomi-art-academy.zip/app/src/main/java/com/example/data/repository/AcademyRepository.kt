package com.example.data.repository

import android.content.Context
import com.example.data.model.AcademyInfo
import com.example.data.model.AcademyNotice
import com.example.data.model.ActivityLog
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.Branch
import com.example.data.model.Course
import com.example.data.model.ExamResult
import com.example.data.model.Examination
import com.example.data.model.ExpenseRecord
import com.example.data.model.FeeRecord
import com.example.data.model.FeeStatus
import com.example.data.model.FeeType
import com.example.data.model.MonthlyRevenuePoint
import com.example.data.model.NoticeCategory
import com.example.data.model.SalaryRecord
import com.example.data.model.Student
import com.example.data.model.StudentStatus
import com.example.data.model.Teacher
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Clean data snapshot designed for 1-to-1 mapping with future Supabase PostgreSQL tables:
 * branches, courses, teachers, students, attendance_records, fee_records, expenses,
 * examinations, exam_results, notices, activity_logs, academy_settings, user_accounts.
 */
data class AcademySnapshot(
    val academyInfo: AcademyInfo,
    val accounts: List<UserAccount>,
    val branches: List<Branch>,
    val courses: List<Course>,
    val teachers: List<Teacher>,
    val students: List<Student>,
    val attendanceRecords: List<AttendanceRecord>,
    val feeRecords: List<FeeRecord>,
    val expenses: List<ExpenseRecord>,
    val examinations: List<Examination>,
    val examResults: List<ExamResult>,
    val notices: List<AcademyNotice>,
    val activities: List<ActivityLog>,
    val monthlyRevenueHistory: List<MonthlyRevenuePoint>
)

interface AcademyDataSource {
    fun loadInitialSnapshot(): AcademySnapshot
    fun exportBackupJson(context: Context, snapshot: AcademySnapshot): Result<File>
    fun restoreLatestBackupSummary(context: Context): Result<String>
}

class LocalAcademyRepository : AcademyDataSource {

    override fun loadInitialSnapshot(): AcademySnapshot {
        val branches = listOf(
            Branch(
                id = "BR-01",
                code = "SKH",
                name = "South Kolkata Heritage Campus",
                address = "42 Rashbehari Avenue, Kalighat, Kolkata 700029",
                coordinatorName = "Smt. Rituparna Ghosh",
                coordinatorPhone = "+91 98301 55210",
                classTimings = "Tue–Sun • 08:30 AM – 08:00 PM",
                establishedYear = 2018
            ),
            Branch(
                id = "BR-02",
                code = "SLC",
                name = "Salt Lake Cultural Wing",
                address = "BD-114 Sector I, Bidhannagar, Kolkata 700064",
                coordinatorName = "Sri Soumik Banerjee",
                coordinatorPhone = "+91 98312 67402",
                classTimings = "Wed–Sun • 09:30 AM – 07:30 PM",
                establishedYear = 2020
            ),
            Branch(
                id = "BR-03",
                code = "BLG",
                name = "Ballygunge Fine Arts Studio",
                address = "19B Gariahat Road South, Ballygunge, Kolkata 700019",
                coordinatorName = "Ms. Madhumita Sengupta",
                coordinatorPhone = "+91 98308 88194",
                classTimings = "Tue–Sat • 10:00 AM – 07:00 PM",
                establishedYear = 2022
            ),
            Branch(
                id = "BR-04",
                code = "NTW",
                name = "New Town Conservatory Annex",
                address = "Action Area IA, Plot 24, New Town, Kolkata 700156",
                coordinatorName = "Sri Arnab Chakraborty",
                coordinatorPhone = "+91 90512 31094",
                classTimings = "Thu–Sun • 10:00 AM – 08:00 PM",
                establishedYear = 2024
            )
        )

        val courses = listOf(
            Course(
                id = "CRS-01",
                name = "Drawing",
                category = "Visual Arts",
                monthlyFee = 1400.0,
                admissionFee = 2000.0,
                durationMonths = 24,
                description = "Charcoal, watercolor, pastel, portraiture, and classical composition.",
                assignedTeacherIds = listOf("KAA-TCH-101")
            ),
            Course(
                id = "CRS-02",
                name = "Guitar",
                category = "String Instruments",
                monthlyFee = 1800.0,
                admissionFee = 2500.0,
                durationMonths = 18,
                description = "Classical fingerstyle, acoustic chord theory, staff notation, and recital craft.",
                assignedTeacherIds = listOf("KAA-TCH-102")
            ),
            Course(
                id = "CRS-03",
                name = "Handicrafts",
                category = "Applied Arts",
                monthlyFee = 1200.0,
                admissionFee = 1500.0,
                durationMonths = 12,
                description = "Terracotta sculpting, paper mache, batik textile, and heritage Bengal crafts.",
                assignedTeacherIds = listOf("KAA-TCH-101", "KAA-TCH-106")
            ),
            Course(
                id = "CRS-04",
                name = "Dance",
                category = "Performing Arts",
                monthlyFee = 1750.0,
                admissionFee = 2500.0,
                durationMonths = 36,
                description = "Kathak, Bharatanatyam, Rabindra Nritya, and rhythmic stage choreography.",
                assignedTeacherIds = listOf("KAA-TCH-103")
            ),
            Course(
                id = "CRS-05",
                name = "Vocal Music",
                category = "Classical Music",
                monthlyFee = 1600.0,
                admissionFee = 2000.0,
                durationMonths = 36,
                description = "Hindustani Classical, Rabindra Sangeet, Nazrul Geeti, and voice culture.",
                assignedTeacherIds = listOf("KAA-TCH-104")
            ),
            Course(
                id = "CRS-06",
                name = "Tabla",
                category = "Percussion",
                monthlyFee = 1550.0,
                admissionFee = 2000.0,
                durationMonths = 36,
                description = "Farrukhabad & Benares Gharana bols, taal mastery, and accompaniment.",
                assignedTeacherIds = listOf("KAA-TCH-105")
            ),
            Course(
                id = "CRS-07",
                name = "Other Musical Instruments",
                category = "Instrumental Ensemble",
                monthlyFee = 1900.0,
                admissionFee = 2500.0,
                durationMonths = 24,
                description = "Violin, Sitar, Harmonium, Bansuri Flute, and Keyboard orchestration.",
                assignedTeacherIds = listOf("KAA-TCH-102", "KAA-TCH-105")
            ),
            Course(
                id = "CRS-08",
                name = "Photography",
                category = "Visual Media",
                monthlyFee = 2200.0,
                admissionFee = 3000.0,
                durationMonths = 12,
                description = "Fine art composition, studio lighting, documentary framing, and curation.",
                assignedTeacherIds = listOf("KAA-TCH-106")
            )
        )

        val teachers = listOf(
            Teacher(
                id = "KAA-TCH-101",
                fullName = "Prof. Sudipto Mukherjee",
                specialization = "Drawing & Fine Handicrafts",
                qualification = "MFA, Government College of Art & Craft",
                phone = "+91 98304 11820",
                email = "sudipto.m@kolabhoomi.edu.in",
                address = "Lake Gardens, Kolkata",
                branchIds = listOf("BR-01", "BR-03"),
                courseIds = listOf("CRS-01", "CRS-03"),
                monthlySalary = 38000.0,
                joiningDate = "2019-04-12",
                classSchedule = "Tue, Thu, Sat • 10:00 AM – 01:00 PM & 04:00 PM – 07:00 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-101-10", "Oct 2026", 38000.0, "Paid", "2026-10-31"),
                    SalaryRecord("SAL-101-09", "Sep 2026", 38000.0, "Paid", "2026-09-30")
                )
            ),
            Teacher(
                id = "KAA-TCH-102",
                fullName = "Sri Rajarshi Bose",
                specialization = "Guitar & String Ensemble",
                qualification = "Trinity Grade 8 Guitar, B.Mus",
                phone = "+91 98310 49201",
                email = "rajarshi.b@kolabhoomi.edu.in",
                address = "Salt Lake Sector II, Kolkata",
                branchIds = listOf("BR-01", "BR-02", "BR-04"),
                courseIds = listOf("CRS-02", "CRS-07"),
                monthlySalary = 42000.0,
                joiningDate = "2020-07-01",
                classSchedule = "Wed, Fri, Sun • 04:00 PM – 08:00 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-102-10", "Oct 2026", 42000.0, "Paid", "2026-10-31"),
                    SalaryRecord("SAL-102-09", "Sep 2026", 42000.0, "Paid", "2026-09-30")
                )
            ),
            Teacher(
                id = "KAA-TCH-103",
                fullName = "Vidushi Nandini Dasgupta",
                specialization = "Classical Dance & Choreography",
                qualification = "Sangeet Visharad (Kathak & Bharatanatyam)",
                phone = "+91 98307 72318",
                email = "nandini.d@kolabhoomi.edu.in",
                address = "Ballygunge Place, Kolkata",
                branchIds = listOf("BR-01", "BR-03"),
                courseIds = listOf("CRS-04"),
                monthlySalary = 40000.0,
                joiningDate = "2018-09-15",
                classSchedule = "Tue, Thu, Sun • 09:00 AM – 12:30 PM & 05:00 PM – 07:30 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-103-10", "Oct 2026", 40000.0, "Paid", "2026-10-31"),
                    SalaryRecord("SAL-103-09", "Sep 2026", 40000.0, "Paid", "2026-09-30")
                )
            ),
            Teacher(
                id = "KAA-TCH-104",
                fullName = "Pandit Anirban Roychowdhury",
                specialization = "Hindustani Vocal & Rabindra Sangeet",
                qualification = "M.Mus, Rabindra Bharati University",
                phone = "+91 98300 94155",
                email = "anirban.r@kolabhoomi.edu.in",
                address = "Tollygunge, Kolkata",
                branchIds = listOf("BR-01", "BR-02"),
                courseIds = listOf("CRS-05"),
                monthlySalary = 45000.0,
                joiningDate = "2018-06-05",
                classSchedule = "Wed, Sat, Sun • 08:30 AM – 12:00 PM & 05:00 PM – 07:30 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-104-10", "Oct 2026", 45000.0, "Paid", "2026-10-31")
                )
            ),
            Teacher(
                id = "KAA-TCH-105",
                fullName = "Ustad Tanmoy Bhattacharya",
                specialization = "Tabla & Classical Percussion",
                qualification = "Sangeet Praveen, Allahabad Prayag Sangeet Samiti",
                phone = "+91 98315 33287",
                email = "tanmoy.b@kolabhoomi.edu.in",
                address = "Behala Chowrasta, Kolkata",
                branchIds = listOf("BR-01", "BR-02", "BR-04"),
                courseIds = listOf("CRS-06", "CRS-07"),
                monthlySalary = 39000.0,
                joiningDate = "2021-01-18",
                classSchedule = "Tue, Fri, Sun • 04:30 PM – 08:00 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-105-10", "Oct 2026", 39000.0, "Paid", "2026-10-31")
                )
            ),
            Teacher(
                id = "KAA-TCH-106",
                fullName = "Ms. Devika Lahiri",
                specialization = "Fine Art Photography & Applied Craft",
                qualification = "PG Diploma in Visual Arts & Photography",
                phone = "+91 90518 60442",
                email = "devika.l@kolabhoomi.edu.in",
                address = "New Town Action Area I, Kolkata",
                branchIds = listOf("BR-03", "BR-04"),
                courseIds = listOf("CRS-08", "CRS-03"),
                monthlySalary = 36000.0,
                joiningDate = "2023-03-10",
                classSchedule = "Thu, Sat, Sun • 11:00 AM – 06:00 PM",
                salaryRecords = listOf(
                    SalaryRecord("SAL-106-10", "Oct 2026", 36000.0, "Pending", "-")
                )
            )
        )

        val students = listOf(
            Student(
                id = "KAA-STU-2026-001",
                fullName = "Aarav Chatterjee",
                dateOfBirth = "2011-05-14",
                gender = "Male",
                phone = "+91 98302 10441",
                email = "aarav.c@student.kolabhoomi.edu.in",
                address = "28 Southern Avenue, Kolkata",
                guardianName = "Subir Chatterjee",
                guardianPhone = "+91 98302 10440",
                guardianRelation = "Father",
                branchId = "BR-01",
                courseIds = listOf("CRS-01", "CRS-02"),
                admissionDate = "2025-04-06",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-002",
                fullName = "Meera Sen",
                dateOfBirth = "2010-08-22",
                gender = "Female",
                phone = "+91 98311 22019",
                email = "meera.sen@student.kolabhoomi.edu.in",
                address = "14 Hindustan Park, Kolkata",
                guardianName = "Indrani Sen",
                guardianPhone = "+91 98311 22018",
                guardianRelation = "Mother",
                branchId = "BR-01",
                courseIds = listOf("CRS-04", "CRS-05"),
                admissionDate = "2024-11-12",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-003",
                fullName = "Rohan Das",
                dateOfBirth = "2008-02-19",
                gender = "Male",
                phone = "+91 98305 74912",
                email = "rohan.das@student.kolabhoomi.edu.in",
                address = "CF-90 Sector I, Salt Lake",
                guardianName = "Pradip Das",
                guardianPhone = "+91 98305 74911",
                guardianRelation = "Father",
                branchId = "BR-02",
                courseIds = listOf("CRS-06", "CRS-05"),
                admissionDate = "2025-01-20",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-004",
                fullName = "Anwesha Roy",
                dateOfBirth = "2012-10-05",
                gender = "Female",
                phone = "+91 90514 88321",
                email = "anwesha.r@student.kolabhoomi.edu.in",
                address = "9 Dover Lane, Ballygunge",
                guardianName = "Tapas Roy",
                guardianPhone = "+91 90514 88320",
                guardianRelation = "Father",
                branchId = "BR-03",
                courseIds = listOf("CRS-01", "CRS-03"),
                admissionDate = "2025-06-14",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-005",
                fullName = "Ishaan Banerjee",
                dateOfBirth = "2007-12-03",
                gender = "Male",
                phone = "+91 98309 30192",
                email = "ishaan.b@student.kolabhoomi.edu.in",
                address = "Greenwood Park, New Town",
                guardianName = "Kausik Banerjee",
                guardianPhone = "+91 98309 30190",
                guardianRelation = "Father",
                branchId = "BR-04",
                courseIds = listOf("CRS-08", "CRS-02"),
                admissionDate = "2026-02-02",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-006",
                fullName = "Shreya Chakraborty",
                dateOfBirth = "2013-03-27",
                gender = "Female",
                phone = "+91 98301 66408",
                email = "shreya.c@student.kolabhoomi.edu.in",
                address = "47 Jodhpur Park, Kolkata",
                guardianName = "Sanchita Chakraborty",
                guardianPhone = "+91 98301 66400",
                guardianRelation = "Mother",
                branchId = "BR-01",
                courseIds = listOf("CRS-04"),
                admissionDate = "2026-07-18",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-007",
                fullName = "Devansh Ghosh",
                dateOfBirth = "2009-09-11",
                gender = "Male",
                phone = "+91 98316 55102",
                email = "devansh.g@student.kolabhoomi.edu.in",
                address = "AE-41 Sector I, Salt Lake",
                guardianName = "Amitabha Ghosh",
                guardianPhone = "+91 98316 55100",
                guardianRelation = "Father",
                branchId = "BR-02",
                courseIds = listOf("CRS-07", "CRS-06"),
                admissionDate = "2025-08-25",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-008",
                fullName = "Tania Paul",
                dateOfBirth = "2011-01-30",
                gender = "Female",
                phone = "+91 98304 48911",
                email = "tania.p@student.kolabhoomi.edu.in",
                address = "12 Fern Road, Ballygunge",
                guardianName = "Suman Paul",
                guardianPhone = "+91 98304 48910",
                guardianRelation = "Father",
                branchId = "BR-03",
                courseIds = listOf("CRS-01", "CRS-08"),
                admissionDate = "2026-09-10",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-009",
                fullName = "Arjun Mitra",
                dateOfBirth = "2010-06-17",
                gender = "Male",
                phone = "+91 98308 11904",
                email = "arjun.m@student.kolabhoomi.edu.in",
                address = "Uniworld City, New Town",
                guardianName = "Debasis Mitra",
                guardianPhone = "+91 98308 11900",
                guardianRelation = "Father",
                branchId = "BR-04",
                courseIds = listOf("CRS-02", "CRS-07"),
                admissionDate = "2026-10-14",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-010",
                fullName = "Riya Bhattacharya",
                dateOfBirth = "2014-04-08",
                gender = "Female",
                phone = "+91 98303 91028",
                email = "riya.b@student.kolabhoomi.edu.in",
                address = "62 Pratapaditya Road, Kalighat",
                guardianName = "Mousumi Bhattacharya",
                guardianPhone = "+91 98303 91020",
                guardianRelation = "Mother",
                branchId = "BR-01",
                courseIds = listOf("CRS-05", "CRS-01"),
                admissionDate = "2026-11-04",
                status = StudentStatus.ACTIVE
            ),
            Student(
                id = "KAA-STU-2026-011",
                fullName = "Kabir Dutta",
                dateOfBirth = "2009-11-23",
                gender = "Male",
                phone = "+91 98314 20591",
                email = "kabir.d@student.kolabhoomi.edu.in",
                address = "CL-21 Sector II, Salt Lake",
                guardianName = "Sandeep Dutta",
                guardianPhone = "+91 98314 20590",
                guardianRelation = "Father",
                branchId = "BR-02",
                courseIds = listOf("CRS-03", "CRS-01"),
                admissionDate = "2026-11-11",
                status = StudentStatus.ON_LEAVE
            ),
            Student(
                id = "KAA-STU-2026-012",
                fullName = "Suhani Majumdar",
                dateOfBirth = "2008-07-15",
                gender = "Female",
                phone = "+91 98306 77431",
                email = "suhani.m@student.kolabhoomi.edu.in",
                address = "31 Mandeville Gardens, Ballygunge",
                guardianName = "Nabanita Majumdar",
                guardianPhone = "+91 98306 77430",
                guardianRelation = "Mother",
                branchId = "BR-03",
                courseIds = listOf("CRS-04", "CRS-05"),
                admissionDate = "2026-11-19",
                status = StudentStatus.ACTIVE
            )
        )

        val attendanceRecords = listOf(
            AttendanceRecord("ATT-001", "2026-11-24", "KAA-STU-2026-001", "Aarav Chatterjee", false, "BR-01", "Drawing", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-002", "2026-11-24", "KAA-STU-2026-002", "Meera Sen", false, "BR-01", "Dance", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-003", "2026-11-24", "KAA-STU-2026-006", "Shreya Chakraborty", false, "BR-01", "Dance", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-004", "2026-11-24", "KAA-STU-2026-010", "Riya Bhattacharya", false, "BR-01", "Vocal Music", AttendanceStatus.LEAVE, "School annual fest"),
            AttendanceRecord("ATT-005", "2026-11-24", "KAA-STU-2026-003", "Rohan Das", false, "BR-02", "Tabla", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-006", "2026-11-24", "KAA-STU-2026-007", "Devansh Ghosh", false, "BR-02", "Other Musical Instruments", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-007", "2026-11-24", "KAA-STU-2026-011", "Kabir Dutta", false, "BR-02", "Handicrafts", AttendanceStatus.ABSENT),
            AttendanceRecord("ATT-008", "2026-11-24", "KAA-STU-2026-004", "Anwesha Roy", false, "BR-03", "Drawing", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-009", "2026-11-24", "KAA-STU-2026-008", "Tania Paul", false, "BR-03", "Photography", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-010", "2026-11-24", "KAA-STU-2026-012", "Suhani Majumdar", false, "BR-03", "Dance", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-011", "2026-11-24", "KAA-STU-2026-005", "Ishaan Banerjee", false, "BR-04", "Photography", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-012", "2026-11-24", "KAA-STU-2026-009", "Arjun Mitra", false, "BR-04", "Guitar", AttendanceStatus.ABSENT),
            // Historical Nov 22 records for accurate attendance rates
            AttendanceRecord("ATT-013", "2026-11-22", "KAA-STU-2026-001", "Aarav Chatterjee", false, "BR-01", "Guitar", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-014", "2026-11-22", "KAA-STU-2026-002", "Meera Sen", false, "BR-01", "Vocal Music", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-015", "2026-11-22", "KAA-STU-2026-003", "Rohan Das", false, "BR-02", "Tabla", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-016", "2026-11-22", "KAA-STU-2026-004", "Anwesha Roy", false, "BR-03", "Drawing", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-017", "2026-11-22", "KAA-STU-2026-005", "Ishaan Banerjee", false, "BR-04", "Photography", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-018", "2026-11-22", "KAA-STU-2026-009", "Arjun Mitra", false, "BR-04", "Guitar", AttendanceStatus.PRESENT),
            // Teacher Attendance
            AttendanceRecord("ATT-T01", "2026-11-24", "KAA-TCH-101", "Prof. Sudipto Mukherjee", true, "BR-01", "Drawing", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-T02", "2026-11-24", "KAA-TCH-102", "Sri Rajarshi Bose", true, "BR-02", "Guitar", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-T03", "2026-11-24", "KAA-TCH-103", "Vidushi Nandini Dasgupta", true, "BR-01", "Dance", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-T04", "2026-11-24", "KAA-TCH-104", "Pandit Anirban Roychowdhury", true, "BR-01", "Vocal Music", AttendanceStatus.PRESENT),
            AttendanceRecord("ATT-T05", "2026-11-24", "KAA-TCH-105", "Ustad Tanmoy Bhattacharya", true, "BR-02", "Tabla", AttendanceStatus.LEAVE, "Recital adjudication"),
            AttendanceRecord("ATT-T06", "2026-11-24", "KAA-TCH-106", "Ms. Devika Lahiri", true, "BR-03", "Photography", AttendanceStatus.PRESENT)
        )

        val feeRecords = listOf(
            FeeRecord("FEE-001", "KAA-RCP-2026-1041", "KAA-STU-2026-001", "Aarav Chatterjee", "BR-01", "Drawing & Guitar", FeeType.MONTHLY_TUITION, "Nov 2026", 3200.0, 3200.0, "2026-11-05", "UPI / Bank", FeeStatus.PAID),
            FeeRecord("FEE-002", "KAA-RCP-2026-1042", "KAA-STU-2026-002", "Meera Sen", "BR-01", "Dance & Vocal Music", FeeType.MONTHLY_TUITION, "Nov 2026", 3350.0, 3350.0, "2026-11-06", "Card", FeeStatus.PAID),
            FeeRecord("FEE-003", "KAA-RCP-2026-1043", "KAA-STU-2026-003", "Rohan Das", "BR-02", "Tabla & Vocal Music", FeeType.MONTHLY_TUITION, "Nov 2026", 3150.0, 3150.0, "2026-11-08", "UPI / Bank", FeeStatus.PAID),
            FeeRecord("FEE-004", "KAA-RCP-2026-1044", "KAA-STU-2026-004", "Anwesha Roy", "BR-03", "Drawing & Handicrafts", FeeType.MONTHLY_TUITION, "Nov 2026", 2600.0, 2600.0, "2026-11-10", "Cash", FeeStatus.PAID),
            FeeRecord("FEE-005", "KAA-RCP-2026-1045", "KAA-STU-2026-005", "Ishaan Banerjee", "BR-04", "Photography & Guitar", FeeType.MONTHLY_TUITION, "Nov 2026", 4000.0, 2000.0, "2026-11-12", "UPI / Bank", FeeStatus.PARTIAL),
            FeeRecord("FEE-006", "KAA-RCP-2026-1046", "KAA-STU-2026-006", "Shreya Chakraborty", "BR-01", "Dance", FeeType.MONTHLY_TUITION, "Nov 2026", 1750.0, 0.0, "-", "Unpaid", FeeStatus.PENDING),
            FeeRecord("FEE-007", "KAA-RCP-2026-1047", "KAA-STU-2026-007", "Devansh Ghosh", "BR-02", "Other Musical Instruments", FeeType.COURSE_FEE, "Nov 2026", 3450.0, 3450.0, "2026-11-14", "Net Banking", FeeStatus.PAID),
            FeeRecord("FEE-008", "KAA-RCP-2026-1048", "KAA-STU-2026-008", "Tania Paul", "BR-03", "Drawing & Photography", FeeType.MONTHLY_TUITION, "Nov 2026", 3600.0, 0.0, "-", "Unpaid", FeeStatus.OVERDUE),
            FeeRecord("FEE-009", "KAA-RCP-2026-1049", "KAA-STU-2026-010", "Riya Bhattacharya", "BR-01", "Vocal Music & Drawing", FeeType.ADMISSION, "Nov 2026", 5400.0, 5400.0, "2026-11-04", "UPI / Bank", FeeStatus.PAID),
            FeeRecord("FEE-010", "KAA-RCP-2026-1050", "KAA-STU-2026-012", "Suhani Majumdar", "BR-03", "Dance & Vocal Music", FeeType.ADMISSION, "Nov 2026", 5850.0, 5850.0, "2026-11-19", "Card", FeeStatus.PAID),
            FeeRecord("FEE-011", "KAA-RCP-2026-1051", "KAA-STU-2026-009", "Arjun Mitra", "BR-04", "Guitar & Instruments", FeeType.MONTHLY_TUITION, "Nov 2026", 3700.0, 0.0, "-", "Unpaid", FeeStatus.PENDING)
        )

        val expenses = listOf(
            ExpenseRecord("EXP-001", "Studio Rent — Heritage & Salt Lake", "Facility Lease", "BR-01", 48000.0, "2026-11-02", "Bengal Heritage Properties"),
            ExpenseRecord("EXP-002", "Fine Art Canvas, Charcoal & Oil Sets", "Art Supplies", "BR-03", 12400.0, "2026-11-09", "Camlin Institutional Desk"),
            ExpenseRecord("EXP-003", "Tabla Tuning & Acoustic Maintenance", "Instruments", "BR-02", 8500.0, "2026-11-14", "Rikhi Ram & Sons Kolkata"),
            ExpenseRecord("EXP-004", "Annual Exhibition Lighting & Sound", "Events", "BR-01", 16200.0, "2026-11-18", "Starlight Stage Craft"),
            ExpenseRecord("EXP-005", "Utility & Fiber Broadband — All Wings", "Operations", "BR-04", 7850.0, "2026-11-20", "CESC & Airtel Business")
        )

        val examinations = listOf(
            Examination("EXM-2026-01", "Annual Fine Arts Assessment", "2026–2027", "CRS-01", "BR-01", "2026-11-15", 30, 40, 20, 10),
            Examination("EXM-2026-02", "Autumn Classical Dance Grade Exam", "2026–2027", "CRS-04", "BR-01", "2026-11-16", 30, 40, 20, 10),
            Examination("EXM-2026-03", "Classical Percussion & Tabla Jury", "2026–2027", "CRS-06", "BR-02", "2026-11-18", 30, 40, 20, 10),
            Examination("EXM-2026-04", "Visual Media & Photography Exhibition", "2026–2027", "CRS-08", "BR-04", "2026-11-20", 30, 40, 20, 10)
        )

        val examResults = listOf(
            ExamResult(
                id = "RES-001",
                examId = "EXM-2026-01",
                examTitle = "Annual Fine Arts Assessment",
                session = "2026–2027",
                studentId = "KAA-STU-2026-001",
                studentName = "Aarav Chatterjee",
                courseName = "Drawing",
                branchName = "South Kolkata Heritage Campus",
                theoryMarks = 28,
                practicalMarks = 38,
                projectMarks = 19,
                teamworkMarks = 9,
                remarks = "Outstanding mastery of tonal shading and studio collaboration.",
                certificateId = "KAA-CERT-2026-8492",
                issuedDate = "2026-11-21"
            ),
            ExamResult(
                id = "RES-002",
                examId = "EXM-2026-02",
                examTitle = "Autumn Classical Dance Grade Exam",
                session = "2026–2027",
                studentId = "KAA-STU-2026-002",
                studentName = "Meera Sen",
                courseName = "Dance",
                branchName = "South Kolkata Heritage Campus",
                theoryMarks = 27,
                practicalMarks = 39,
                projectMarks = 18,
                teamworkMarks = 10,
                remarks = "Graceful abhinaya, immaculate taal precision, and stage poise.",
                certificateId = "KAA-CERT-2026-8493",
                issuedDate = "2026-11-21"
            ),
            ExamResult(
                id = "RES-003",
                examId = "EXM-2026-03",
                examTitle = "Classical Percussion & Tabla Jury",
                session = "2026–2027",
                studentId = "KAA-STU-2026-003",
                studentName = "Rohan Das",
                courseName = "Tabla",
                branchName = "Salt Lake Cultural Wing",
                theoryMarks = 25,
                practicalMarks = 36,
                projectMarks = 17,
                teamworkMarks = 9,
                remarks = "Strong command of Teentaal kayda and ensemble responsiveness.",
                certificateId = "KAA-CERT-2026-8494",
                issuedDate = "2026-11-22"
            ),
            ExamResult(
                id = "RES-004",
                examId = "EXM-2026-01",
                examTitle = "Annual Fine Arts Assessment",
                session = "2026–2027",
                studentId = "KAA-STU-2026-004",
                studentName = "Anwesha Roy",
                courseName = "Drawing",
                branchName = "Ballygunge Fine Arts Studio",
                theoryMarks = 26,
                practicalMarks = 35,
                projectMarks = 18,
                teamworkMarks = 9,
                remarks = "Expressive watercolor composition and neat sketchbook craft.",
                certificateId = "KAA-CERT-2026-8495",
                issuedDate = "2026-11-22"
            ),
            ExamResult(
                id = "RES-005",
                examId = "EXM-2026-04",
                examTitle = "Visual Media & Photography Exhibition",
                session = "2026–2027",
                studentId = "KAA-STU-2026-005",
                studentName = "Ishaan Banerjee",
                courseName = "Photography",
                branchName = "New Town Conservatory Annex",
                theoryMarks = 24,
                practicalMarks = 34,
                projectMarks = 18,
                teamworkMarks = 8,
                remarks = "Compelling street monochrome portfolio with strong exposure control.",
                certificateId = "KAA-CERT-2026-8496",
                issuedDate = "2026-11-23"
            )
        )

        val notices = listOf(
            AcademyNotice(
                id = "NOT-001",
                title = "Annual Winter Art & Music Convocation 2026",
                body = "The Annual Exhibition and Classical Recital will be hosted at Rabindra Sadan on December 18, 2026. All certified scholars are requested to submit display frames by Dec 5.",
                category = NoticeCategory.GENERAL,
                date = "2026-11-24",
                targetAudience = "All Members",
                isRead = false
            ),
            AcademyNotice(
                id = "NOT-002",
                title = "November Tuition Fee Settlement Reminder",
                body = "Kindly clear pending November 2026 tuition dues before November 30 to avoid late administrative charges and receive verified digital receipts.",
                category = NoticeCategory.FEE_REMINDER,
                date = "2026-11-22",
                targetAudience = "Students & Guardians",
                isRead = false
            ),
            AcademyNotice(
                id = "NOT-003",
                title = "Practical Jury Schedule Published",
                body = "Winter grade examinations for Guitar, Vocal Music, and Handicrafts will commence on December 8 across all four branches. Check your branch noticeboard.",
                category = NoticeCategory.EXAM,
                date = "2026-11-20",
                targetAudience = "Students & Teachers",
                isRead = false
            ),
            AcademyNotice(
                id = "NOT-004",
                title = "New Admission Welcome — Winter Batch",
                body = "We warmly welcome 14 newly admitted scholars across South Kolkata, Salt Lake, Ballygunge, and New Town wings.",
                category = NoticeCategory.ADMISSION,
                date = "2026-11-19",
                targetAudience = "Faculty & Admin",
                isRead = true
            ),
            AcademyNotice(
                id = "NOT-005",
                title = "Minimum 80% Attendance Eligibility",
                body = "Scholars appearing for Annual Diploma Certification must maintain a minimum 80% attendance record across theory and studio sessions.",
                category = NoticeCategory.ATTENDANCE,
                date = "2026-11-15",
                targetAudience = "Students",
                isRead = true
            )
        )

        val activities = listOf(
            ActivityLog("ACT-01", "New Admission Confirmed", "Suhani Majumdar enrolled in Dance & Vocal Music (Ballygunge)", "2 hrs ago", "Admission"),
            ActivityLog("ACT-02", "Receipt #KAA-RCP-2026-1050 Issued", "₹5,850 settled via Card — Verified Digital Receipt generated", "3 hrs ago", "Finance"),
            ActivityLog("ACT-03", "Certificate QR-Verified", "KAA-CERT-2026-8492 published for Aarav Chatterjee (94% A+)", "Yesterday", "Examination"),
            ActivityLog("ACT-04", "Daily Attendance Synced", "4 branches completed student & faculty attendance register", "Yesterday", "Attendance"),
            ActivityLog("ACT-05", "Faculty Schedule Updated", "New Town Conservatory Guitar & Photography studio timings updated", "2 days ago", "Branch")
        )

        val revenueHistory = listOf(
            MonthlyRevenuePoint("Jun", 184000.0, 92000.0),
            MonthlyRevenuePoint("Jul", 198500.0, 95400.0),
            MonthlyRevenuePoint("Aug", 214000.0, 98200.0),
            MonthlyRevenuePoint("Sep", 229500.0, 102000.0),
            MonthlyRevenuePoint("Oct", 248000.0, 106500.0),
            MonthlyRevenuePoint("Nov", 268400.0, 92950.0)
        )

        val accounts = listOf(
            UserAccount("KAA-ADM-001", "admin123", UserRole.SUPER_ADMIN, "Smt. Ananya Chatterjee", "director@kolabhoomi.edu.in", "+91 98300 41280", "ADMIN"),
            UserAccount("KAA-TCH-101", "teach123", UserRole.TEACHER, "Prof. Sudipto Mukherjee", "sudipto.m@kolabhoomi.edu.in", "+91 98304 11820", "KAA-TCH-101"),
            UserAccount("KAA-TCH-102", "teach123", UserRole.TEACHER, "Sri Rajarshi Bose", "rajarshi.b@kolabhoomi.edu.in", "+91 98310 49201", "KAA-TCH-102"),
            UserAccount("KAA-STU-2026-001", "student123", UserRole.STUDENT, "Aarav Chatterjee", "aarav.c@student.kolabhoomi.edu.in", "+91 98302 10441", "KAA-STU-2026-001"),
            UserAccount("KAA-STU-2026-002", "student123", UserRole.STUDENT, "Meera Sen", "meera.sen@student.kolabhoomi.edu.in", "+91 98311 22019", "KAA-STU-2026-002")
        )

        return AcademySnapshot(
            academyInfo = AcademyInfo(),
            accounts = accounts,
            branches = branches,
            courses = courses,
            teachers = teachers,
            students = students,
            attendanceRecords = attendanceRecords,
            feeRecords = feeRecords,
            expenses = expenses,
            examinations = examinations,
            examResults = examResults,
            notices = notices,
            activities = activities,
            monthlyRevenueHistory = revenueHistory
        )
    }

    override fun exportBackupJson(context: Context, snapshot: AcademySnapshot): Result<File> = runCatching {
        val dir = File(context.filesDir, "backups").apply { mkdirs() }
        val file = File(dir, "kolabhoomi_erp_backup.json")
        val root = JSONObject().apply {
            put("academyName", snapshot.academyInfo.name)
            put("exportedAt", System.currentTimeMillis())
            put("branchesCount", snapshot.branches.size)
            put("coursesCount", snapshot.courses.size)
            put("teachersCount", snapshot.teachers.size)
            put("studentsCount", snapshot.students.size)
            put("feesCount", snapshot.feeRecords.size)
            put("resultsCount", snapshot.examResults.size)
            val studentsArr = JSONArray()
            snapshot.students.forEach { s ->
                studentsArr.put(JSONObject().apply {
                    put("id", s.id)
                    put("fullName", s.fullName)
                    put("branchId", s.branchId)
                    put("status", s.status.name)
                })
            }
            put("students", studentsArr)
        }
        file.writeText(root.toString(2))
        file
    }

    override fun restoreLatestBackupSummary(context: Context): Result<String> = runCatching {
        val file = File(File(context.filesDir, "backups"), "kolabhoomi_erp_backup.json")
        if (!file.exists()) {
            throw IllegalStateException("No local backup snapshot found yet. Create a backup first.")
        }
        val json = JSONObject(file.readText())
        val sCount = json.optInt("studentsCount", 0)
        val bCount = json.optInt("branchesCount", 0)
        val cCount = json.optInt("coursesCount", 0)
        "Verified snapshot restored: $sCount students, $bCount branches, $cCount courses."
    }
}

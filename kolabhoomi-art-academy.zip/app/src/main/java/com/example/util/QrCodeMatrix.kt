package com.example.util

import java.security.MessageDigest

/**
 * Generates a deterministic 25x25 QR-style verification matrix containing standard
 * finder patterns (top-left, top-right, bottom-left), timing tracks, alignment square,
 * and SHA-256 deterministic payload encoding for Kolabhoomi Art Academy certificates.
 */
object QrCodeMatrix {
    const val SIZE = 25

    fun generate(payload: String): Array<BooleanArray> {
        val matrix = Array(SIZE) { BooleanArray(SIZE) }
        val reserved = Array(SIZE) { BooleanArray(SIZE) }

        fun drawFinder(row: Int, col: Int) {
            for (r in -1..7) {
                for (c in -1..7) {
                    val rr = row + r
                    val cc = col + c
                    if (rr in 0 until SIZE && cc in 0 until SIZE) {
                        reserved[rr][cc] = true
                        val inOuter = r in 0..6 && c in 0..6
                        val onBorder = r == 0 || r == 6 || c == 0 || c == 6
                        val inCenter = r in 2..4 && c in 2..4
                        matrix[rr][cc] = inOuter && (onBorder || inCenter)
                    }
                }
            }
        }

        // Standard 3 corner finder patterns
        drawFinder(0, 0)
        drawFinder(0, SIZE - 7)
        drawFinder(SIZE - 7, 0)

        // Alignment pattern near bottom-right (standard Version 2 position: 18, 18)
        for (r in -2..2) {
            for (c in -2..2) {
                val rr = 18 + r
                val cc = 18 + c
                reserved[rr][cc] = true
                matrix[rr][cc] = (kotlin.math.abs(r) == 2 || kotlin.math.abs(c) == 2 || (r == 0 && c == 0))
            }
        }

        // Timing patterns
        for (i in 8 until SIZE - 8) {
            reserved[6][i] = true
            matrix[6][i] = i % 2 == 0
            reserved[i][6] = true
            matrix[i][6] = i % 2 == 0
        }

        // Deterministic payload bitstream from chained SHA-256 digests
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = ByteArray(96)
        var seed = payload.toByteArray()
        for (chunk in 0 until 3) {
            seed = digest.digest(seed + byteArrayOf(chunk.toByte()))
            System.arraycopy(seed, 0, bytes, chunk * 32, 32)
        }

        var bitIndex = 0
        for (r in 0 until SIZE) {
            for (c in 0 until SIZE) {
                if (!reserved[r][c]) {
                    val byteVal = bytes[(bitIndex / 8) % bytes.size].toInt()
                    val bit = (byteVal shr (bitIndex % 8)) and 1
                    // Light checkerboard mask for balanced QR module density
                    val masked = if ((r + c) % 3 == 0) bit xor 1 else bit
                    matrix[r][c] = masked == 1
                    bitIndex++
                }
            }
        }
        return matrix
    }
}

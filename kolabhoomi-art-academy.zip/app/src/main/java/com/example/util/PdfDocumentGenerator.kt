package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.AcademyInfo
import com.example.data.model.ExamResult
import com.example.data.model.FeeRecord
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

object PdfDocumentGenerator {

    private val navyColor = Color.parseColor("#0B1D3A")
    private val royalColor = Color.parseColor("#1B3B6F")
    private val goldColor = Color.parseColor("#C8A24A")
    private val goldLightColor = Color.parseColor("#FBF4DF")
    private val inkColor = Color.parseColor("#0F1B2E")
    private val mutedColor = Color.parseColor("#54637A")
    private val borderColor = Color.parseColor("#D4DCE8")
    private val successColor = Color.parseColor("#147A52")
    private val whiteColor = Color.WHITE

    private fun formatInr(amount: Double): String {
        val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        formatter.maximumFractionDigits = 0
        return formatter.format(amount)
    }

    private fun getPdfOutputFile(context: Context, fileName: String): File {
        val dir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        return File(dir, fileName)
    }

    private fun loadScaledBitmap(context: Context, resId: Int, maxSize: Int): Bitmap? {
        return try {
            val raw = BitmapFactory.decodeResource(context.resources, resId) ?: return null
            Bitmap.createScaledBitmap(raw, maxSize, maxSize, true)
        } catch (_: Exception) {
            null
        }
    }

    private fun drawQrOnCanvas(canvas: Canvas, payload: String, left: Float, top: Float, size: Float) {
        val matrix = QrCodeMatrix.generate(payload)
        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        val borderPaint = Paint().apply { color = goldColor; style = Paint.Style.STROKE; strokeWidth = 1.5f }
        val modPaint = Paint().apply { color = navyColor; style = Paint.Style.FILL }
        canvas.drawRect(left - 4f, top - 4f, left + size + 4f, top + size + 4f, bgPaint)
        canvas.drawRect(left - 4f, top - 4f, left + size + 4f, top + size + 4f, borderPaint)
        val cell = size / QrCodeMatrix.SIZE
        for (r in 0 until QrCodeMatrix.SIZE) {
            for (c in 0 until QrCodeMatrix.SIZE) {
                if (matrix[r][c]) {
                    canvas.drawRect(
                        left + c * cell,
                        top + r * cell,
                        left + (c + 1) * cell,
                        top + (r + 1) * cell,
                        modPaint
                    )
                }
            }
        }
    }

    private fun drawSignatureLine(
        canvas: Canvas,
        xCenter: Float,
        yLine: Float,
        signatoryName: String,
        designation: String
    ) {
        val scriptPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = royalColor
            textSize = 13f
            typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            textAlign = Paint.Align.CENTER
        }
        val linePaint = Paint().apply { color = navyColor; strokeWidth = 1f }
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = inkColor
            textSize = 10f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val rolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = mutedColor
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(signatoryName.substringBeforeLast(" "), xCenter, yLine - 8f, scriptPaint)
        canvas.drawLine(xCenter - 72f, yLine, xCenter + 72f, yLine, linePaint)
        canvas.drawText(signatoryName, xCenter, yLine + 13f, namePaint)
        canvas.drawText(designation, xCenter, yLine + 24f, rolePaint)
    }

    /**
     * Generates a formal A4 Academy Payment Receipt PDF with institutional crest,
     * itemized table, digital signatures, and verification QR code.
     */
    fun exportPaymentReceiptPdf(
        context: Context,
        academyInfo: AcademyInfo,
        fee: FeeRecord,
        branchName: String
    ): Result<File> = runCatching {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas

        // Background & Outer Border
        c.drawColor(whiteColor)
        val outerBorder = Paint().apply { color = navyColor; style = Paint.Style.STROKE; strokeWidth = 2f }
        val goldInner = Paint().apply { color = goldColor; style = Paint.Style.STROKE; strokeWidth = 1f }
        c.drawRect(24f, 24f, 571f, 818f, outerBorder)
        c.drawRect(29f, 29f, 566f, 813f, goldInner)

        // Header Navy Banner
        val headerBg = Paint().apply { color = navyColor }
        c.drawRect(30f, 30f, 565f, 134f, headerBg)

        // Crest Logo
        loadScaledBitmap(context, R.drawable.img_academy_crest_1795593425517, 74)?.let { bmp ->
            c.drawBitmap(bmp, null, Rect(48, 44, 122, 118), null)
        }

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = whiteColor
            textSize = 19f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val goldSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = goldColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            letterSpacing = 0.08f
        }
        val headerSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D8E2F2")
            textSize = 8.5f
        }
        c.drawText(academyInfo.name, 138f, 68f, titlePaint)
        c.drawText("OFFICIAL FEE PAYMENT RECEIPT", 138f, 86f, goldSubPaint)
        c.drawText(academyInfo.address, 138f, 104f, headerSubPaint)
        c.drawText("Reg: ${academyInfo.registrationNo}  |  ${academyInfo.phone}", 138f, 118f, headerSubPaint)

        // Receipt Meta Box
        val metaBg = Paint().apply { color = goldLightColor }
        c.drawRect(44f, 152f, 551f, 206f, metaBg)
        c.drawRect(44f, 152f, 551f, 206f, goldInner)

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mutedColor; textSize = 9f }
        val boldValPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = inkColor; textSize = 11f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        c.drawText("RECEIPT NO.", 58f, 172f, labelPaint)
        c.drawText(fee.receiptNo, 58f, 190f, boldValPaint)
        c.drawText("PAYMENT DATE", 238f, 172f, labelPaint)
        c.drawText(fee.paymentDate, 238f, 190f, boldValPaint)
        c.drawText("STATUS", 420f, 172f, labelPaint)
        val statusPaint = Paint(boldValPaint).apply {
            color = if (fee.status.name == "PAID") successColor else Color.parseColor("#C47D12")
        }
        c.drawText(fee.status.label.uppercase(), 420f, 190f, statusPaint)

        // Student Info
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = navyColor; textSize = 11.5f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        c.drawText("SCHOLAR & ENROLLMENT DETAILS", 44f, 236f, sectionPaint)
        val dividerPaint = Paint().apply { color = borderColor; strokeWidth = 1f }
        c.drawLine(44f, 244f, 551f, 244f, dividerPaint)

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = inkColor; textSize = 10.5f }
        c.drawText("Student Name:  ${fee.studentName}", 44f, 266f, boldValPaint)
        c.drawText("Student ID:  ${fee.studentId}", 330f, 266f, bodyPaint)
        c.drawText("Branch Wing:  $branchName", 44f, 286f, bodyPaint)
        c.drawText("Course(s):  ${fee.courseName}", 330f, 286f, bodyPaint)
        c.drawText("Billing Cycle:  ${fee.billingMonth}", 44f, 306f, bodyPaint)
        c.drawText("Payment Mode:  ${fee.paymentMode}", 330f, 306f, bodyPaint)

        // Fee Breakdown Table
        val tblTop = 334f
        c.drawRect(44f, tblTop, 551f, tblTop + 30f, Paint().apply { color = royalColor })
        val thPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = whiteColor; textSize = 10f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        c.drawText("SL", 56f, tblTop + 19f, thPaint)
        c.drawText("FEE DESCRIPTION", 104f, tblTop + 19f, thPaint)
        c.drawText("MONTH", 336f, tblTop + 19f, thPaint)
        c.drawText("AMOUNT", 460f, tblTop + 19f, thPaint)

        val rowY = tblTop + 56f
        c.drawRect(44f, tblTop + 30f, 551f, tblTop + 76f, Paint().apply { color = Color.parseColor("#F8FAFD") })
        c.drawRect(44f, tblTop, 551f, tblTop + 76f, Paint().apply { color = borderColor; style = Paint.Style.STROKE })
        c.drawText("01", 56f, rowY, bodyPaint)
        c.drawText("${fee.feeType.label} — ${fee.courseName}", 104f, rowY, boldValPaint)
        c.drawText(fee.billingMonth, 336f, rowY, bodyPaint)
        c.drawText(formatInr(fee.amount), 460f, rowY, boldValPaint)

        // Totals Summary Box
        val sumTop = 434f
        c.drawRect(310f, sumTop, 551f, sumTop + 92f, Paint().apply { color = Color.parseColor("#F5F7FB") })
        c.drawRect(310f, sumTop, 551f, sumTop + 92f, Paint().apply { color = borderColor; style = Paint.Style.STROKE })
        c.drawText("Total Billed:", 326f, sumTop + 24f, labelPaint)
        c.drawText(formatInr(fee.amount), 458f, sumTop + 24f, boldValPaint)
        c.drawText("Amount Settled:", 326f, sumTop + 48f, labelPaint)
        c.drawText(formatInr(fee.paidAmount), 458f, sumTop + 48f, Paint(boldValPaint).apply { color = successColor })
        c.drawLine(322f, sumTop + 60f, 540f, sumTop + 60f, dividerPaint)
        c.drawText("Balance Due:", 326f, sumTop + 80f, boldValPaint)
        c.drawText(formatInr(fee.balanceDue), 458f, sumTop + 80f, boldValPaint)

        // QR Verification for Receipt
        drawQrOnCanvas(c, "KAA-RECEIPT|${fee.receiptNo}|${fee.studentId}|${fee.paidAmount.toInt()}", 52f, sumTop + 6f, 84f)
        c.drawText("Scan to verify receipt", 50f, sumTop + 106f, labelPaint)
        c.drawText("authenticity in Academy Ledger", 50f, sumTop + 118f, labelPaint)

        // Official Seal
        loadScaledBitmap(context, R.drawable.img_certificate_seal_1795593430154, 72)?.let { seal ->
            c.drawBitmap(seal, null, Rect(260, 610, 332, 682), null)
        }

        // Digital Signature Fields
        drawSignatureLine(c, 134f, 706f, "Accounts Registrar", "Accounts & Finance Office")
        drawSignatureLine(c, 456f, 706f, academyInfo.directorName, "Director, Kolabhoomi Art Academy")

        // Footer
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = mutedColor; textSize = 8f; textAlign = Paint.Align.CENTER
        }
        c.drawText("This is an electronically generated official receipt of ${academyInfo.name}. ${academyInfo.website}", 297f, 792f, footerPaint)

        doc.finishPage(page)
        val outFile = getPdfOutputFile(context, "Receipt_${fee.receiptNo}.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        outFile
    }

    /**
     * Generates a formal A4 Student Marksheet PDF with Theory, Practical, Project & Teamwork table,
     * grade summary, academy logo, gold seal, and digital signature fields.
     */
    fun exportMarksheetPdf(
        context: Context,
        academyInfo: AcademyInfo,
        result: ExamResult
    ): Result<File> = runCatching {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas

        c.drawColor(whiteColor)
        val navyBorder = Paint().apply { color = navyColor; style = Paint.Style.STROKE; strokeWidth = 2.5f }
        val goldBorder = Paint().apply { color = goldColor; style = Paint.Style.STROKE; strokeWidth = 1.2f }
        c.drawRect(22f, 22f, 573f, 820f, navyBorder)
        c.drawRect(28f, 28f, 567f, 814f, goldBorder)

        // Header
        c.drawRect(29f, 29f, 566f, 140f, Paint().apply { color = navyColor })
        loadScaledBitmap(context, R.drawable.img_academy_crest_1795593425517, 76)?.let { bmp ->
            c.drawBitmap(bmp, null, Rect(46, 46, 122, 122), null)
        }
        val hTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = whiteColor; textSize = 19f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val hGold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = goldColor; textSize = 10f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val hSub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D8E2F2"); textSize = 8.5f }
        c.drawText(academyInfo.name, 138f, 70f, hTitle)
        c.drawText("STATEMENT OF MARKS • OFFICIAL ACADEMIC TRANSCRIPT", 138f, 89f, hGold)
        c.drawText("${result.examTitle}  |  Academic Session: ${result.session}", 138f, 108f, hSub)
        c.drawText("Reg. No: ${academyInfo.registrationNo}  •  ${academyInfo.email}", 138f, 122f, hSub)

        // Scholar Details Grid
        val cardBg = Paint().apply { color = Color.parseColor("#F5F7FB") }
        val strokeP = Paint().apply { color = borderColor; style = Paint.Style.STROKE }
        c.drawRect(44f, 158f, 551f, 246f, cardBg)
        c.drawRect(44f, 158f, 551f, 246f, strokeP)

        val lblP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mutedColor; textSize = 9f }
        val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = inkColor; textSize = 10.5f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        c.drawText("CANDIDATE NAME", 58f, 178f, lblP)
        c.drawText(result.studentName, 58f, 194f, valP)
        c.drawText("SCHOLAR ID", 320f, 178f, lblP)
        c.drawText(result.studentId, 320f, 194f, valP)
        c.drawText("DISCIPLINE / COURSE", 58f, 218f, lblP)
        c.drawText(result.courseName, 58f, 234f, valP)
        c.drawText("CAMPUS BRANCH", 320f, 218f, lblP)
        c.drawText(result.branchName, 320f, 234f, valP)

        // Marks Table
        val tTop = 272f
        c.drawRect(44f, tTop, 551f, tTop + 32f, Paint().apply { color = royalColor })
        val th = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = whiteColor; textSize = 9.5f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        c.drawText("ASSESSMENT COMPONENT", 60f, tTop + 20f, th)
        c.drawText("MAX MARKS", 288f, tTop + 20f, th)
        c.drawText("OBTAINED", 386f, tTop + 20f, th)
        c.drawText("PERFORMANCE", 464f, tTop + 20f, th)

        val components = listOf(
            Triple("Theory & Aesthetic Foundations", result.maxTheory, result.theoryMarks),
            Triple("Practical Studio / Performance", result.maxPractical, result.practicalMarks),
            Triple("Capstone Project / Portfolio", result.maxProject, result.projectMarks),
            Triple("Ensemble & Teamwork Discipline", result.maxTeamwork, result.teamworkMarks)
        )
        var rowY = tTop + 32f
        components.forEachIndexed { idx, (label, maxM, obt) ->
            val bg = if (idx % 2 == 0) whiteColor else Color.parseColor("#F8FAFD")
            c.drawRect(44f, rowY, 551f, rowY + 34f, Paint().apply { color = bg })
            c.drawRect(44f, rowY, 551f, rowY + 34f, strokeP)
            c.drawText(label, 60f, rowY + 21f, valP)
            c.drawText(maxM.toString(), 308f, rowY + 21f, valP)
            c.drawText(obt.toString(), 404f, rowY + 21f, Paint(valP).apply { color = royalColor })
            val pct = if (maxM > 0) (obt * 100) / maxM else 0
            c.drawText("$pct%", 484f, rowY + 21f, valP)
            rowY += 34f
        }

        // Grand Total Row
        c.drawRect(44f, rowY, 551f, rowY + 38f, Paint().apply { color = goldLightColor })
        c.drawRect(44f, rowY, 551f, rowY + 38f, goldBorder)
        c.drawText("GRAND AGGREGATE TOTAL", 60f, rowY + 24f, valP)
        c.drawText(result.totalMax.toString(), 308f, rowY + 24f, valP)
        c.drawText(result.totalObtained.toString(), 404f, rowY + 24f, Paint(valP).apply { color = navyColor })
        c.drawText(String.format(Locale.US, "%.1f%%", result.percentage), 474f, rowY + 24f, Paint(valP).apply { color = successColor })

        // Result Summary & Remarks
        val resTop = rowY + 58f
        c.drawRect(44f, resTop, 551f, resTop + 88f, cardBg)
        c.drawRect(44f, resTop, 551f, resTop + 88f, strokeP)
        c.drawText("FINAL RESULT: ${if (result.isPassed) "PASSED WITH HONORS" else "RE-APPEAR"}", 60f, resTop + 26f, Paint(valP).apply { color = successColor; textSize = 11.5f })
        c.drawText("AWARDED GRADE: ${result.grade}", 340f, resTop + 26f, Paint(valP).apply { color = navyColor; textSize = 11.5f })
        c.drawText("Examiner Remarks: ${result.remarks}", 60f, resTop + 54f, lblP)
        c.drawText("Date of Issue: ${result.issuedDate}   •   Transcript Ref: ${result.id}", 60f, resTop + 72f, lblP)

        // Verification QR + Seal
        val qrY = 602f
        val certRef = result.certificateId ?: result.id
        drawQrOnCanvas(c, "https://verify.kolabhoomi.edu/marksheet/$certRef", 52f, qrY, 76f)
        c.drawText("Transcript Verification QR", 50f, qrY + 90f, lblP)

        loadScaledBitmap(context, R.drawable.img_certificate_seal_1795593430154, 78)?.let { seal ->
            c.drawBitmap(seal, null, Rect(258, 602, 336, 680), null)
        }

        // Digital Signature Blocks
        drawSignatureLine(c, 152f, 738f, academyInfo.controllerName, "Controller of Examinations")
        drawSignatureLine(c, 444f, 738f, academyInfo.principalName, "Principal, Kolabhoomi Art Academy")

        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mutedColor; textSize = 8f; textAlign = Paint.Align.CENTER }
        c.drawText("Digitally verified by ${academyInfo.name} Examination Board • ${academyInfo.website}", 297f, 796f, foot)

        doc.finishPage(page)
        val outFile = getPdfOutputFile(context, "Marksheet_${result.studentId}_${result.id}.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        outFile
    }

    /**
     * Generates a formal Landscape Diploma Certificate PDF with Navy & Gold frame,
     * Academy Crest, Embossed Gold Medallion Seal, Digital Signatures, and Scannable QR Verification Code.
     */
    fun exportCertificatePdf(
        context: Context,
        academyInfo: AcademyInfo,
        result: ExamResult
    ): Result<File> = runCatching {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(842, 595, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas

        c.drawColor(Color.parseColor("#FFFDF8"))

        // Double Ornamental Border
        c.drawRect(22f, 22f, 820f, 573f, Paint().apply { color = navyColor; style = Paint.Style.STROKE; strokeWidth = 6f })
        c.drawRect(33f, 33f, 809f, 562f, Paint().apply { color = goldColor; style = Paint.Style.STROKE; strokeWidth = 2f })
        c.drawRect(39f, 39f, 803f, 556f, Paint().apply { color = navyColor; style = Paint.Style.STROKE; strokeWidth = 0.8f })

        // Top Corner Gold Accents
        val cornerPaint = Paint().apply { color = goldColor; style = Paint.Style.FILL }
        c.drawRect(22f, 22f, 52f, 28f, cornerPaint)
        c.drawRect(790f, 22f, 820f, 28f, cornerPaint)
        c.drawRect(22f, 567f, 52f, 573f, cornerPaint)
        c.drawRect(790f, 567f, 820f, 573f, cornerPaint)

        // Centered Academy Crest
        loadScaledBitmap(context, R.drawable.img_academy_crest_1795593425517, 68)?.let { crest ->
            c.drawBitmap(crest, null, Rect(387, 52, 455, 120), null)
        }

        val centerSerifBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = navyColor; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val centerGold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = goldColor; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val centerBody = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = inkColor; textAlign = Paint.Align.CENTER; textSize = 13f
        }

        centerSerifBold.textSize = 23f
        c.drawText(academyInfo.name, 421f, 150f, centerSerifBold)
        centerGold.textSize = 10.5f
        c.drawText("REGD. FINE ARTS & CLASSICAL MUSIC INSTITUTION  •  ${academyInfo.registrationNo}", 421f, 168f, centerGold)

        c.drawLine(250f, 182f, 592f, 182f, Paint().apply { color = goldColor; strokeWidth = 1.5f })

        centerSerifBold.textSize = 30f
        centerSerifBold.color = royalColor
        c.drawText("CERTIFICATE OF EXCELLENCE", 421f, 224f, centerSerifBold)

        c.drawText("This is proudly conferred upon", 421f, 258f, centerBody)

        centerSerifBold.textSize = 32f
        centerSerifBold.color = navyColor
        c.drawText(result.studentName, 421f, 300f, centerSerifBold)
        c.drawLine(240f, 310f, 602f, 310f, Paint().apply { color = goldColor; strokeWidth = 1.2f })

        c.drawText(
            "Scholar ID: ${result.studentId}  •  ${result.branchName}",
            421f, 332f,
            Paint(centerBody).apply { color = mutedColor; textSize = 11f }
        )

        c.drawText(
            "for successfully completing the ${result.examTitle} in ${result.courseName}",
            421f, 360f, centerBody
        )
        c.drawText(
            "during the Academic Session ${result.session} with Grade ${result.grade} (${String.format(Locale.US, "%.1f", result.percentage)}%).",
            421f, 380f, Paint(centerBody).apply { typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); color = royalColor }
        )

        // Gold Medallion Seal
        loadScaledBitmap(context, R.drawable.img_certificate_seal_1795593430154, 86)?.let { seal ->
            c.drawBitmap(seal, null, Rect(378, 412, 464, 498), null)
        }

        // Digital Signature Lines
        drawSignatureLine(c, 198f, 476f, academyInfo.principalName, "Principal")
        drawSignatureLine(c, 558f, 476f, academyInfo.directorName, "Director & Founder")

        // QR Code Verification Block (Bottom Right)
        val certId = result.certificateId ?: "KAA-CERT-2026-9001"
        val verifyPayload = "https://verify.kolabhoomi.edu/cert/$certId|${result.studentId}|${result.shortGrade}"
        drawQrOnCanvas(c, verifyPayload, 686f, 422f, 84f)
        val qrLbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = navyColor; textSize = 8f; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        c.drawText("QR VERIFIED", 728f, 518f, qrLbl)
        c.drawText(certId, 728f, 529f, Paint(qrLbl).apply { color = mutedColor; typeface = Typeface.DEFAULT })

        // Issue Date Bottom Left
        val leftLbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mutedColor; textSize = 9f }
        c.drawText("Certificate ID: $certId", 56f, 534f, leftLbl)
        c.drawText("Issued On: ${result.issuedDate}", 56f, 546f, leftLbl)

        doc.finishPage(page)
        val outFile = getPdfOutputFile(context, "Certificate_${certId}.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        outFile
    }

    /**
     * Generates an institutional tabular summary report PDF (Student, Financial, Attendance, Branch, or Course).
     */
    fun exportInstitutionalReportPdf(
        context: Context,
        academyInfo: AcademyInfo,
        reportTitle: String,
        subtitle: String,
        headers: List<String>,
        rows: List<List<String>>
    ): Result<File> = runCatching {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas

        c.drawColor(whiteColor)
        c.drawRect(0f, 0f, 595f, 104f, Paint().apply { color = navyColor })
        loadScaledBitmap(context, R.drawable.img_academy_crest_1795593425517, 56)?.let { crest ->
            c.drawBitmap(crest, null, Rect(32, 24, 88, 80), null)
        }
        val titleP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = whiteColor; textSize = 17f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val subP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = goldColor; textSize = 10f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        val metaP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D8E2F2"); textSize = 9f }
        c.drawText(academyInfo.name, 104f, 46f, titleP)
        c.drawText(reportTitle.uppercase(), 104f, 66f, subP)
        c.drawText(subtitle, 104f, 84f, metaP)

        val tableLeft = 32f
        val tableWidth = 531f
        val colWidth = tableWidth / headers.size.coerceAtLeast(1)
        var y = 128f

        c.drawRect(tableLeft, y, tableLeft + tableWidth, y + 28f, Paint().apply { color = royalColor })
        val th = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = whiteColor; textSize = 9f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
        headers.forEachIndexed { idx, h ->
            c.drawText(h.take(18), tableLeft + idx * colWidth + 8f, y + 18f, th)
        }
        y += 28f

        val cellP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = inkColor; textSize = 9f }
        val strokeP = Paint().apply { color = borderColor; style = Paint.Style.STROKE }
        rows.take(22).forEachIndexed { rIdx, row ->
            val bg = if (rIdx % 2 == 0) whiteColor else Color.parseColor("#F5F7FB")
            c.drawRect(tableLeft, y, tableLeft + tableWidth, y + 26f, Paint().apply { color = bg })
            c.drawRect(tableLeft, y, tableLeft + tableWidth, y + 26f, strokeP)
            row.forEachIndexed { cIdx, cell ->
                c.drawText(cell.take(22), tableLeft + cIdx * colWidth + 8f, y + 17f, cellP)
            }
            y += 26f
        }

        drawSignatureLine(c, 470f, 770f, academyInfo.directorName, "Authorized Institutional Seal")
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mutedColor; textSize = 8f }
        c.drawText("Generated from Kolabhoomi Art Academy Official ERP • ${academyInfo.email}", 32f, 808f, foot)

        doc.finishPage(page)
        val safeName = reportTitle.replace(Regex("[^A-Za-z0-9]"), "_")
        val outFile = getPdfOutputFile(context, "KAA_${safeName}.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        outFile
    }

    fun sharePdfFile(context: Context, file: File, subject: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share or Save Official PDF"))
    }
}

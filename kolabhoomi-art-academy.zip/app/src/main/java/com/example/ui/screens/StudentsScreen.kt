package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Branch
import com.example.data.model.Course
import com.example.data.model.Student
import com.example.data.model.StudentStatus
import com.example.data.model.UserRole
import com.example.ui.components.GoldAccentChip
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.viewmodel.AcademyUiState

@Composable
fun StudentsScreen(
    state: AcademyUiState,
    onGenerateStudentId: () -> String,
    onSaveStudent: (Student, Boolean) -> Unit,
    onDeleteStudent: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val canManage = state.currentUser?.role == UserRole.SUPER_ADMIN
    var searchQuery by remember { mutableStateOf("") }
    var selectedBranchId by remember { mutableStateOf<String?>(null) }
    var selectedStatus by remember { mutableStateOf<StudentStatus?>(null) }

    var viewingStudent by remember { mutableStateOf<Student?>(null) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var showAddForm by remember { mutableStateOf(false) }

    val filteredStudents = remember(state.students, searchQuery, selectedBranchId, selectedStatus) {
        state.students.filter { s ->
            val matchesQuery = searchQuery.isBlank() ||
                s.fullName.contains(searchQuery, ignoreCase = true) ||
                s.id.contains(searchQuery, ignoreCase = true) ||
                s.guardianName.contains(searchQuery, ignoreCase = true) ||
                state.courseNames(s.courseIds).contains(searchQuery, ignoreCase = true)
            val matchesBranch = selectedBranchId == null || s.branchId == selectedBranchId
            val matchesStatus = selectedStatus == null || s.status == selectedStatus
            matchesQuery && matchesBranch && matchesStatus
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = AlabasterCanvas,
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = { editingStudent = null; showAddForm = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("add_student_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Student")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search & Branch Filters
            Surface(color = PureWhite, shadowElevation = 1.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Student Directory", style = MaterialTheme.typography.headlineMedium, color = DeepNavy)
                            Text("${filteredStudents.size} of ${state.students.size} enrolled scholars", style = MaterialTheme.typography.bodySmall, color = InkMuted)
                        }
                        GoldAccentChip("Auto-ID Active")
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search name, Student ID, course, guardian...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RoyalBlue) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_search_input")
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedBranchId == null,
                            onClick = { selectedBranchId = null },
                            label = { Text("All Branches") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = DeepNavy, selectedLabelColor = PureWhite)
                        )
                        state.branches.forEach { br ->
                            FilterChip(
                                selected = selectedBranchId == br.id,
                                onClick = { selectedBranchId = if (selectedBranchId == br.id) null else br.id },
                                label = { Text(br.code) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = DeepNavy, selectedLabelColor = PureWhite)
                            )
                        }
                        StudentStatus.entries.forEach { st ->
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = if (selectedStatus == st) null else st },
                                label = { Text(st.label) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = RoyalBlue, selectedLabelColor = PureWhite)
                            )
                        }
                    }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredStudents, key = { it.id }) { student ->
                    val statusColors = when (student.status) {
                        StudentStatus.ACTIVE -> EmeraldSoft to EmeraldSuccess
                        StudentStatus.ON_LEAVE -> AmberSoft to AmberWarning
                        StudentStatus.ALUMNI -> RoyalBlueSoft to RoyalBlue
                        StudentStatus.INACTIVE -> CrimsonSoft to CrimsonAlert
                    }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewingStudent = student }
                            .testTag("student_card_${student.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = BorderStroke(1.dp, CardOutline)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            InitialsAvatar(name = student.fullName, photoUri = student.photoUri, size = 48.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = student.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = DeepNavy,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    StatusPill(student.status.label, statusColors.first, statusColors.second)
                                }
                                Text(
                                    text = "${student.id} • ${state.branchName(student.branchId)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RoyalBlue
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "Courses: ${state.courseNames(student.courseIds)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Guardian: ${student.guardianName} (${student.guardianPhone})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = InkMuted
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    // Student Profile Detail Dialog
    viewingStudent?.let { stu ->
        val attPct = state.studentAttendancePercent(stu.id)
        AlertDialog(
            onDismissRequest = { viewingStudent = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    InitialsAvatar(name = stu.fullName, photoUri = stu.photoUri, size = 50.dp)
                    Column {
                        Text(stu.fullName, style = MaterialTheme.typography.titleLarge, color = DeepNavy)
                        Text(stu.id, style = MaterialTheme.typography.labelMedium, color = InstitutionalGold)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfileDetailRow("Status", stu.status.label)
                    ProfileDetailRow("Branch", state.branchName(stu.branchId))
                    ProfileDetailRow("Enrolled Courses", state.courseNames(stu.courseIds))
                    ProfileDetailRow("Admission Date", stu.admissionDate)
                    ProfileDetailRow("Attendance Rate", "$attPct%")
                    HorizontalDivider(color = CardOutline)
                    ProfileDetailRow("Date of Birth", "${stu.dateOfBirth} (${stu.gender})")
                    ProfileDetailRow("Phone", stu.phone)
                    ProfileDetailRow("Email", stu.email)
                    ProfileDetailRow("Address", stu.address)
                    HorizontalDivider(color = CardOutline)
                    ProfileDetailRow("Guardian", "${stu.guardianName} (${stu.guardianRelation})")
                    ProfileDetailRow("Guardian Phone", stu.guardianPhone)
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (canManage) {
                        IconButton(onClick = {
                            onDeleteStudent(stu.id)
                            viewingStudent = null
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Student", tint = CrimsonAlert)
                        }
                        Button(
                            onClick = {
                                editingStudent = stu
                                viewingStudent = null
                                showAddForm = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit")
                        }
                    } else {
                        Button(
                            onClick = { viewingStudent = null },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                        ) { Text("Done") }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { viewingStudent = null }) { Text("Close") }
            }
        )
    }

    if (showAddForm) {
        StudentFormDialog(
            initial = editingStudent,
            generatedId = onGenerateStudentId(),
            branches = state.branches,
            courses = state.courses,
            onDismiss = { showAddForm = false; editingStudent = null },
            onSave = { stu ->
                onSaveStudent(stu, editingStudent != null)
                showAddForm = false
                editingStudent = null
            }
        )
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = InkMuted, modifier = Modifier.weight(0.42f))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = InkPrimary, modifier = Modifier.weight(0.58f))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudentFormDialog(
    initial: Student?,
    generatedId: String,
    branches: List<Branch>,
    courses: List<Course>,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    val studentId = remember { initial?.id ?: generatedId }
    var fullName by remember { mutableStateOf(initial?.fullName ?: "") }
    var dob by remember { mutableStateOf(initial?.dateOfBirth ?: "2012-06-15") }
    var gender by remember { mutableStateOf(initial?.gender ?: "Female") }
    var phone by remember { mutableStateOf(initial?.phone ?: "+91 ") }
    var email by remember { mutableStateOf(initial?.email ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var photoUri by remember { mutableStateOf(initial?.photoUri) }
    var guardianName by remember { mutableStateOf(initial?.guardianName ?: "") }
    var guardianPhone by remember { mutableStateOf(initial?.guardianPhone ?: "+91 ") }
    var guardianRelation by remember { mutableStateOf(initial?.guardianRelation ?: "Father") }
    var branchId by remember { mutableStateOf(initial?.branchId ?: branches.firstOrNull()?.id ?: "BR-01") }
    var selectedCourses by remember { mutableStateOf(initial?.courseIds?.toSet() ?: setOf(courses.firstOrNull()?.id ?: "CRS-01")) }
    var status by remember { mutableStateOf(initial?.status ?: StudentStatus.ACTIVE) }

    // Zero-permission Android Photo Picker (Play Policy compliant!)
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(if (initial == null) "New Student Admission" else "Edit Student Profile", color = DeepNavy)
                Text("Student ID: $studentId (Auto-Generated)", style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Upload Student Photo via Android Photo Picker
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InitialsAvatar(name = fullName.ifBlank { "New" }, photoUri = photoUri, size = 56.dp)
                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("upload_student_photo_btn")
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (photoUri == null) "Upload Photo" else "Change Photo")
                    }
                }

                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dob, onValueChange = { dob = it }, label = { Text("DOB") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = gender, onValueChange = { gender = it }, label = { Text("Gender") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Residential Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                HorizontalDivider(color = CardOutline)
                Text("Guardian Information", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                OutlinedTextField(value = guardianName, onValueChange = { guardianName = it }, label = { Text("Guardian Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = guardianRelation, onValueChange = { guardianRelation = it }, label = { Text("Relation") }, singleLine = true, modifier = Modifier.weight(0.45f))
                    OutlinedTextField(value = guardianPhone, onValueChange = { guardianPhone = it }, label = { Text("Guardian Phone") }, singleLine = true, modifier = Modifier.weight(0.55f))
                }

                HorizontalDivider(color = CardOutline)
                Text("Branch Assignment", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    branches.forEach { br ->
                        FilterChip(
                            selected = branchId == br.id,
                            onClick = { branchId = br.id },
                            label = { Text(br.code) }
                        )
                    }
                }

                Text("Course Enrollment", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    courses.forEach { c ->
                        val isSel = c.id in selectedCourses
                        FilterChip(
                            selected = isSel,
                            onClick = {
                                selectedCourses = if (isSel && selectedCourses.size > 1) selectedCourses - c.id else selectedCourses + c.id
                            },
                            label = { Text(c.name) }
                        )
                    }
                }

                Text("Student Status", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StudentStatus.entries.forEach { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st.label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fullName.isNotBlank()) {
                        onSave(
                            Student(
                                id = studentId,
                                fullName = fullName.trim(),
                                dateOfBirth = dob.trim(),
                                gender = gender.trim(),
                                phone = phone.trim(),
                                email = email.trim().ifBlank { "${fullName.lowercase().replace(" ", ".")}@student.kolabhoomi.edu.in" },
                                address = address.trim().ifBlank { "Kolkata, West Bengal" },
                                photoUri = photoUri,
                                guardianName = guardianName.trim().ifBlank { "Parent / Guardian" },
                                guardianPhone = guardianPhone.trim(),
                                guardianRelation = guardianRelation.trim(),
                                branchId = branchId,
                                courseIds = selectedCourses.toList(),
                                admissionDate = initial?.admissionDate ?: "2026-11-24",
                                status = status
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
            ) { Text("Save Scholar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ExamResult
import com.example.data.model.FeeRecord
import com.example.data.model.FeeStatus
import com.example.ui.components.AcademyLogoBadge
import com.example.ui.components.BranchAttendanceBarChart
import com.example.ui.components.CourseEnrollmentPieChart
import com.example.ui.components.GoldAccentChip
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.InstitutionalKpiCard
import com.example.ui.components.MonthlyRevenueLineChart
import com.example.ui.components.NavyGradientBanner
import com.example.ui.components.QuickActionTile
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.formatCurrencyInr
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.viewmodel.AcademyUiState
import java.util.Locale

@Composable
fun SuperAdminDashboardScreen(
    state: AcademyUiState,
    onNavigateRoute: (String) -> Unit,
    onOpenDocumentStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val branchAttendanceStats = remember(state.branches, state.attendanceRecords) {
        state.branchAttendanceStats()
    }
    val courseSlices = remember(state.courses, state.students) {
        state.courseEnrollmentDistribution()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .testTag("super_admin_dashboard"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Executive Institutional Header
        item {
            NavyGradientBanner {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            AcademyLogoBadge(logoUri = state.academyInfo.logoUri, size = 48.dp)
                            Column {
                                Text(
                                    text = "SUPER ADMIN CONSOLE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RichGold
                                )
                                Text(
                                    text = state.currentUser?.fullName ?: state.academyInfo.directorName,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = PureWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        IconButton(
                            onClick = { onNavigateRoute("notifications") },
                            modifier = Modifier.testTag("admin_notifications_btn")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (state.unreadNoticeCount > 0) {
                                        Badge(containerColor = RichGold, contentColor = DeepNavy) {
                                            Text(state.unreadNoticeCount.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = PureWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = PureWhite.copy(alpha = 0.14f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Monthly Academy Revenue",
                                style = MaterialTheme.typography.labelSmall,
                                color = RoyalBlueSoft
                            )
                            Text(
                                text = formatCurrencyInr(state.totalMonthlyRevenue),
                                style = MaterialTheme.typography.displayMedium,
                                color = PureWhite
                            )
                        }
                        Surface(
                            color = InstitutionalGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, InstitutionalGold.copy(alpha = 0.65f)),
                            modifier = Modifier.clickable { onNavigateRoute("fees") }
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text("Pending Fees", style = MaterialTheme.typography.labelSmall, color = GoldBorder)
                                Text(
                                    text = formatCurrencyInr(state.totalPendingFees),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = RichGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Core KPI Grid (Students, Teachers, Branches, Courses)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InstitutionalKpiCard(
                        title = "Total Students",
                        value = state.students.size.toString(),
                        subtitle = "${state.students.count { it.status.name == "ACTIVE" }} Active Scholars",
                        icon = Icons.Default.Groups,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateRoute("students") }
                    )
                    InstitutionalKpiCard(
                        title = "Total Teachers",
                        value = state.teachers.size.toString(),
                        subtitle = "Faculty & Gurus",
                        icon = Icons.Default.School,
                        accentColor = InstitutionalGold,
                        badgeColor = GoldContainer,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateRoute("teachers") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InstitutionalKpiCard(
                        title = "Total Branches",
                        value = state.branches.size.toString(),
                        subtitle = "Unlimited scalable",
                        icon = Icons.Default.Apartment,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateRoute("branches") }
                    )
                    InstitutionalKpiCard(
                        title = "Active Courses",
                        value = state.courses.size.toString(),
                        subtitle = "Art, Music & Craft",
                        icon = Icons.Default.Palette,
                        accentColor = EmeraldSuccess,
                        badgeColor = EmeraldSoft,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateRoute("courses") }
                    )
                }
            }
        }

        // Quick Actions (Complete ERP Modules Hub)
        item {
            SectionHeader(
                title = "Academy Command Center",
                subtitle = "Direct access to every ERP module"
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionTile("Branches", Icons.Default.Apartment, "qa_branches", { onNavigateRoute("branches") }, Modifier.weight(1f))
                    QuickActionTile("Courses", Icons.Default.Palette, "qa_courses", { onNavigateRoute("courses") }, Modifier.weight(1f))
                    QuickActionTile("Teachers", Icons.Default.School, "qa_teachers", { onNavigateRoute("teachers") }, Modifier.weight(1f))
                    QuickActionTile("Exams", Icons.AutoMirrored.Filled.Assignment, "qa_exams", { onNavigateRoute("exams") }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickActionTile("Documents", Icons.Default.Description, "qa_documents", onOpenDocumentStudio, Modifier.weight(1f))
                    QuickActionTile("Reports", Icons.Default.Assessment, "qa_reports", { onNavigateRoute("reports") }, Modifier.weight(1f))
                    QuickActionTile("Notices", Icons.Default.Campaign, "qa_notices", { onNavigateRoute("notifications") }, Modifier.weight(1f))
                    QuickActionTile("Settings", Icons.Default.Settings, "qa_settings", { onNavigateRoute("settings") }, Modifier.weight(1f))
                }
            }
        }

        // INTERACTIVE ANALYTICS SECTION (Line Chart, Bar Chart, Pie Chart)
        item {
            SectionHeader(
                title = "Executive Analytics",
                subtitle = "Interactive financial, attendance & course insights",
                actionLabel = "Full Reports",
                onActionClick = { onNavigateRoute("reports") }
            )
        }
        item {
            MonthlyRevenueLineChart(data = state.monthlyRevenueHistory)
        }
        item {
            BranchAttendanceBarChart(stats = branchAttendanceStats)
        }
        item {
            CourseEnrollmentPieChart(slices = courseSlices)
        }

        // Recent Admissions
        item {
            SectionHeader(
                title = "Recent Admissions",
                subtitle = "Newly enrolled scholars",
                actionLabel = "View All",
                onActionClick = { onNavigateRoute("students") }
            )
        }
        items(state.students.take(3)) { student ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateRoute("students") },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InitialsAvatar(name = student.fullName, photoUri = student.photoUri)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(student.fullName, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                        Text(
                            text = "${student.id} • ${state.courseNames(student.courseIds)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${state.branchName(student.branchId)} • Admitted ${student.admissionDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMuted
                        )
                    }
                    StatusPill(student.status.label, EmeraldSoft, EmeraldSuccess)
                }
            }
        }

        // Recent Institutional Activities
        item {
            SectionHeader(title = "Recent Activities", subtitle = "Live administrative ledger")
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    state.activities.take(5).forEachIndexed { idx, act ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(if (idx == 0) InstitutionalGold else RoyalBlue)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(act.title, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                                    Text(act.timestamp, style = MaterialTheme.typography.labelSmall, color = InkMuted)
                                }
                                Text(act.subtitle, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                            }
                        }
                        if (idx < state.activities.take(5).lastIndex) {
                            HorizontalDivider(color = CardOutline.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TeacherDashboardScreen(
    state: AcademyUiState,
    onNavigateRoute: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val teacher = state.currentTeacher()
    val assignedStudents = remember(state.students, teacher) {
        if (teacher == null) state.students
        else state.students.filter { s ->
            s.branchId in teacher.branchIds || s.courseIds.any { it in teacher.courseIds }
        }
    }
    val assignedCourses = remember(state.courses, teacher) {
        if (teacher == null) state.courses
        else state.courses.filter { it.id in teacher.courseIds }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .testTag("teacher_dashboard"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            NavyGradientBanner {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AcademyLogoBadge(logoUri = state.academyInfo.logoUri, size = 48.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FACULTY PORTAL", style = MaterialTheme.typography.labelSmall, color = RichGold)
                            Text(
                                text = teacher?.fullName ?: state.currentUser?.fullName ?: "Faculty Member",
                                style = MaterialTheme.typography.titleLarge,
                                color = PureWhite
                            )
                            Text(
                                text = "${teacher?.id ?: ""} • ${teacher?.specialization ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = RoyalBlueSoft
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = PureWhite.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = RichGold)
                            Column {
                                Text("Class Schedule", style = MaterialTheme.typography.labelSmall, color = GoldBorder)
                                Text(
                                    text = teacher?.classSchedule ?: "Tue, Thu, Sat • 10:00 AM – 06:00 PM",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PureWhite
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InstitutionalKpiCard(
                    title = "Assigned Students",
                    value = assignedStudents.size.toString(),
                    subtitle = "Active cohort",
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateRoute("students") }
                )
                InstitutionalKpiCard(
                    title = "Assigned Courses",
                    value = assignedCourses.size.toString(),
                    subtitle = "Disciplines taught",
                    icon = Icons.Default.Palette,
                    accentColor = InstitutionalGold,
                    badgeColor = GoldContainer,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateRoute("courses") }
                )
            }
        }

        item {
            SectionHeader(title = "Faculty Quick Actions")
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickActionTile("Attendance", Icons.Default.FactCheck, "tqa_att", { onNavigateRoute("attendance") }, Modifier.weight(1f))
                QuickActionTile("Enter Marks", Icons.AutoMirrored.Filled.Assignment, "tqa_exams", { onNavigateRoute("exams") }, Modifier.weight(1f))
                QuickActionTile("Documents", Icons.Default.Description, "tqa_docs", { onNavigateRoute("documents") }, Modifier.weight(1f))
                QuickActionTile("Notices", Icons.Default.Campaign, "tqa_notices", { onNavigateRoute("notifications") }, Modifier.weight(1f))
            }
        }

        item {
            SectionHeader(title = "Student Progress Overview", subtitle = "Attendance & recent examination standing")
        }

        items(assignedStudents.take(6)) { stu ->
            val attPct = state.studentAttendancePercent(stu.id)
            val latestRes = state.examResults.find { it.studentId == stu.id }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        InitialsAvatar(name = stu.fullName, photoUri = stu.photoUri, size = 40.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stu.fullName, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                            Text(state.courseNames(stu.courseIds), style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        }
                        if (latestRes != null) {
                            GoldAccentChip("${latestRes.shortGrade} • ${latestRes.percentage.toInt()}%")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Attendance Progress", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                        Text("$attPct%", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    }
                    LinearProgressIndicator(
                        progress = { (attPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (attPct >= 80) DeepNavy else AmberWarning,
                        trackColor = RoyalBlueSoft
                    )
                }
            }
        }
    }
}

@Composable
fun StudentDashboardScreen(
    state: AcademyUiState,
    onNavigateRoute: (String) -> Unit,
    onViewMarksheet: (ExamResult) -> Unit,
    onViewCertificate: (ExamResult) -> Unit,
    onViewReceipt: (FeeRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val student = state.currentStudent()
    val attPct = student?.let { state.studentAttendancePercent(it.id) } ?: 94
    val myFees = remember(state.feeRecords, student) {
        if (student == null) emptyList() else state.feeRecords.filter { it.studentId == student.id }
    }
    val myResults = remember(state.examResults, student) {
        if (student == null) emptyList() else state.examResults.filter { it.studentId == student.id }
    }
    val myCourses = remember(state.courses, student) {
        if (student == null) emptyList() else state.courses.filter { it.id in student.courseIds }
    }
    val pendingDue = myFees.sumOf { it.balanceDue }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .testTag("student_dashboard"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Digital Scholar ID Card Banner
        item {
            NavyGradientBanner {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InitialsAvatar(
                            name = student?.fullName ?: "Scholar",
                            photoUri = student?.photoUri,
                            size = 54.dp,
                            containerColor = GoldContainer,
                            textColor = DeepNavy
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text("SCHOLAR IDENTITY CARD", style = MaterialTheme.typography.labelSmall, color = RichGold)
                            Text(student?.fullName ?: "Aarav Chatterjee", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                            Text(
                                text = "${student?.id ?: ""} • ${student?.let { state.branchName(it.branchId) } ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = RoyalBlueSoft
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            color = PureWhite.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Attendance", style = MaterialTheme.typography.labelSmall, color = GoldBorder)
                                Text("$attPct%", style = MaterialTheme.typography.headlineSmall, color = PureWhite)
                            }
                        }
                        Surface(
                            color = PureWhite.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Fee Status", style = MaterialTheme.typography.labelSmall, color = GoldBorder)
                                Text(
                                    text = if (pendingDue <= 0) "All Clear" else formatCurrencyInr(pendingDue),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if (pendingDue <= 0) RichGold else PureWhite
                                )
                            }
                        }
                    }
                }
            }
        }

        // Enrolled Courses & Class Schedule
        item {
            SectionHeader(title = "Enrolled Courses & Schedule")
        }
        items(myCourses) { course ->
            val branch = state.branches.find { it.id == student?.branchId }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(GoldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = DeepNavy)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(course.name, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                        Text(course.category, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Text(branch?.classTimings ?: "Tue–Sun", style = MaterialTheme.typography.labelSmall, color = RoyalBlue)
                    }
                    Text(
                        text = "${formatCurrencyInr(course.monthlyFee)}/mo",
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepNavy
                    )
                }
            }
        }

        // Exam Results & Certificates
        item {
            SectionHeader(title = "Examination Results & Certificates", subtitle = "Download verified PDF marksheets & QR diplomas")
        }
        items(myResults) { res ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, GoldBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(res.examTitle, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                            Text("${res.courseName} • Session ${res.session}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        }
                        GoldAccentChip("${String.format(Locale.US, "%.1f", res.percentage)}% (${res.shortGrade})")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            color = DeepNavy,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onViewMarksheet(res) }
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Description, contentDescription = null, tint = PureWhite, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Marksheet PDF", style = MaterialTheme.typography.labelMedium, color = PureWhite)
                            }
                        }
                        Surface(
                            color = GoldContainer,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, GoldBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onViewCertificate(res) }
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("QR Certificate", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                            }
                        }
                    }
                }
            }
        }

        // Latest Fee Receipt Shortcut
        if (myFees.isNotEmpty()) {
            item {
                SectionHeader(title = "Recent Payment Receipts", actionLabel = "All Fees", onActionClick = { onNavigateRoute("fees") })
            }
            items(myFees.take(2)) { fee ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, CardOutline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewReceipt(fee) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(fee.receiptNo, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                            Text("${fee.feeType.label} • ${fee.billingMonth}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatCurrencyInr(fee.amount), style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                            StatusPill(
                                text = fee.status.label,
                                containerColor = if (fee.status == FeeStatus.PAID) EmeraldSoft else AmberSoft,
                                contentColor = if (fee.status == FeeStatus.PAID) EmeraldSuccess else AmberWarning
                            )
                        }
                    }
                }
            }
        }

        // Notices
        item {
            SectionHeader(title = "Academy Notices", actionLabel = "All Notices", onActionClick = { onNavigateRoute("notifications") })
        }
        items(state.notices.take(2)) { notice ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusPill(notice.category.label, RoyalBlueSoft, RoyalBlue)
                        Text(notice.date, style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(notice.title, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                    Text(notice.body, style = MaterialTheme.typography.bodySmall, color = InkSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AcademyInfo
import com.example.data.model.UserRole
import com.example.ui.components.AcademyLogoBadge
import com.example.ui.components.GoldAccentChip
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.DeepNavyDark
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    academyInfo: AcademyInfo,
    onFinished: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        visible = true
        delay(1350)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepNavyDark, DeepNavy, RoyalBlue)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(650)) + scaleIn(initialScale = 0.88f, animationSpec = tween(650))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(32.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(134.dp)
                        .clip(CircleShape)
                        .background(InstitutionalGold.copy(alpha = 0.14f))
                        .border(1.dp, InstitutionalGold.copy(alpha = 0.45f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 110.dp, borderWidth = 2.5.dp)
                }
                Spacer(modifier = Modifier.height(26.dp))
                Text(
                    text = "KOLABHOOMI ART ACADEMY",
                    style = MaterialTheme.typography.headlineLarge,
                    color = PureWhite,
                    textAlign = TextAlign.Center,
                    letterSpacing = 1.2.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = InstitutionalGold.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(1.dp, InstitutionalGold.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = "OFFICIAL ACADEMY ERP",
                        style = MaterialTheme.typography.labelMedium,
                        color = RichGold,
                        letterSpacing = 1.6.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = academyInfo.tagline,
                    style = MaterialTheme.typography.bodyMedium,
                    color = RoyalBlueSoft.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(36.dp))
                CircularProgressIndicator(
                    color = RichGold,
                    trackColor = PureWhite.copy(alpha = 0.14f),
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
fun WelcomeScreen(
    academyInfo: AcademyInfo,
    onContinueToLogin: () -> Unit,
    onQuickRoleLogin: (UserRole) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Full-bleed Architectural Conservatory Hero
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_welcome_hero_1795593428361),
                contentDescription = "Kolabhoomi Art Academy Conservatory Hall",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                DeepNavyDark.copy(alpha = 0.55f),
                                DeepNavy.copy(alpha = 0.35f),
                                DeepNavyDark.copy(alpha = 0.94f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 48.dp)
                    Column {
                        Text(
                            text = "ESTD. 2018 • KOLKATA",
                            style = MaterialTheme.typography.labelSmall,
                            color = RichGold,
                            letterSpacing = 1.4.sp
                        )
                        Text(
                            text = academyInfo.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = PureWhite
                        )
                    }
                }
                Column {
                    GoldAccentChip("OFFICIAL INSTITUTIONAL PLATFORM")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Art, Music & Academic Excellence in One Portal",
                        style = MaterialTheme.typography.displayMedium,
                        color = PureWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Unified ERP for Admissions, Attendance, Finance, Examinations, and QR-Verified Certification.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = RoyalBlueSoft
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = onContinueToLogin,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("welcome_sign_in_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy, contentColor = PureWhite)
            ) {
                Text(
                    text = "Sign In with Academy ID",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
            }

            Text(
                text = "QUICK PORTAL ACCESS (DEMO CREDENTIALS)",
                style = MaterialTheme.typography.labelMedium,
                color = InkMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            RolePortalPreviewCard(
                title = "Super Admin (Owner / Director)",
                subtitle = "Full control: Branches, Analytics, Finance, Reports & Settings",
                idHint = "KAA-ADM-001",
                icon = Icons.Default.AdminPanelSettings,
                tag = "quick_login_admin",
                onClick = { onQuickRoleLogin(UserRole.SUPER_ADMIN) }
            )
            RolePortalPreviewCard(
                title = "Faculty / Teacher Portal",
                subtitle = "Assigned Batches, Daily Attendance, Marks Entry & Student Progress",
                idHint = "KAA-TCH-101",
                icon = Icons.Default.School,
                tag = "quick_login_teacher",
                onClick = { onQuickRoleLogin(UserRole.TEACHER) }
            )
            RolePortalPreviewCard(
                title = "Student / Scholar Portal",
                subtitle = "Courses, Attendance %, Fee Receipts, Marksheets & QR Certificates",
                idHint = "KAA-STU-2026-001",
                icon = Icons.Outlined.Person,
                tag = "quick_login_student",
                onClick = { onQuickRoleLogin(UserRole.STUDENT) }
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Registration No: ${academyInfo.registrationNo}\n${academyInfo.address}",
                style = MaterialTheme.typography.bodySmall,
                color = InkMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun RolePortalPreviewCard(
    title: String,
    subtitle: String,
    idHint: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RoyalBlueSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = DeepNavy, modifier = Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ID: $idHint  •  Tap to sign in directly",
                    style = MaterialTheme.typography.labelSmall,
                    color = InstitutionalGold
                )
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Open", tint = RoyalBlue)
        }
    }
}

@Composable
fun LoginScreen(
    academyInfo: AcademyInfo,
    onBack: () -> Unit,
    onLoginSubmit: (String, String) -> Result<*>,
    onForgotPassword: (String) -> Result<String>
) {
    var selectedRole by remember { mutableStateOf(UserRole.SUPER_ADMIN) }
    var academyId by remember { mutableStateOf("KAA-ADM-001") }
    var password by remember { mutableStateOf("admin123") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showForgotDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("login_back_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 60.dp)
                Column {
                    Text(
                        text = "KOLABHOOMI ART ACADEMY",
                        style = MaterialTheme.typography.headlineSmall,
                        color = DeepNavy,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Institutional Portal Sign In",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Select Portal Role (Auto-fills demo credentials)",
                style = MaterialTheme.typography.labelLarge,
                color = InkPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                UserRole.entries.forEach { role ->
                    val isSel = role == selectedRole
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            selectedRole = role
                            errorMessage = null
                            when (role) {
                                UserRole.SUPER_ADMIN -> {
                                    academyId = "KAA-ADM-001"
                                    password = "admin123"
                                }
                                UserRole.TEACHER -> {
                                    academyId = "KAA-TCH-101"
                                    password = "teach123"
                                }
                                UserRole.STUDENT -> {
                                    academyId = "KAA-STU-2026-001"
                                    password = "student123"
                                }
                            }
                        },
                        label = { Text(role.displayName, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = DeepNavy,
                            selectedLabelColor = PureWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("role_chip_${role.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = academyId,
                        onValueChange = { academyId = it; errorMessage = null },
                        label = { Text("Student ID / Teacher ID / Admin ID") },
                        placeholder = { Text("e.g. KAA-STU-2026-001") },
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = RoyalBlue) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_id_input")
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = RoyalBlue) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_password_input")
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonAlert
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { showForgotDialog = true },
                            modifier = Modifier.testTag("forgot_password_button")
                        ) {
                            Text("Forgot Password?", color = RoyalBlue)
                        }
                    }

                    Button(
                        onClick = {
                            onLoginSubmit(academyId, password).onFailure {
                                errorMessage = it.message
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("login_submit_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy, contentColor = PureWhite)
                    ) {
                        Text("Sign In to ${selectedRole.displayName} Dashboard", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                color = GoldContainer,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, GoldBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Official Demo Directory",
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepNavy
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Super Admin: KAA-ADM-001 / admin123\n• Teacher: KAA-TCH-101 / teach123\n• Student: KAA-STU-2026-001 / student123",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkSecondary
                    )
                }
            }
        }
    }

    if (showForgotDialog) {
        var resetId by remember { mutableStateOf(academyId) }
        var resetFeedback by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showForgotDialog = false },
            title = { Text("Reset Portal Password", color = DeepNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter your Academy ID (Student, Teacher, or Admin) to dispatch a verified password reset token to your registered email.",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkSecondary
                    )
                    OutlinedTextField(
                        value = resetId,
                        onValueChange = { resetId = it; resetFeedback = null },
                        label = { Text("Academy ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    resetFeedback?.let {
                        Text(text = it, style = MaterialTheme.typography.bodySmall, color = RoyalBlue)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onForgotPassword(resetId)
                            .onSuccess { msg -> resetFeedback = msg }
                            .onFailure { err -> resetFeedback = err.message }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) {
                    Text("Send Reset Link")
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun ChangePasswordDialog(
    onDismiss: () -> Unit,
    onChangePassword: (String, String) -> Result<String>
) {
    var currentPwd by remember { mutableStateOf("") }
    var newPwd by remember { mutableStateOf("") }
    var confirmPwd by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change Account Password", color = DeepNavy) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = currentPwd,
                    onValueChange = { currentPwd = it; error = null },
                    label = { Text("Current Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPwd,
                    onValueChange = { newPwd = it; error = null },
                    label = { Text("New Password (min 6 chars)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = confirmPwd,
                    onValueChange = { confirmPwd = it; error = null },
                    label = { Text("Confirm New Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Text(text = it, style = MaterialTheme.typography.bodySmall, color = CrimsonAlert)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPwd != confirmPwd) {
                        error = "New passwords do not match."
                    } else {
                        onChangePassword(currentPwd, newPwd)
                            .onSuccess { onDismiss() }
                            .onFailure { error = it.message }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
            ) { Text("Update Password") }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

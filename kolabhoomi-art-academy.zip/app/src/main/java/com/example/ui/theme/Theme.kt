package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val KolabhoomiLightColorScheme = lightColorScheme(
    primary = DeepNavy,
    onPrimary = PureWhite,
    primaryContainer = RoyalBlueSoft,
    onPrimaryContainer = DeepNavy,
    secondary = RoyalBlue,
    onSecondary = PureWhite,
    secondaryContainer = SurfaceMuted,
    onSecondaryContainer = RoyalBlue,
    tertiary = InstitutionalGold,
    onTertiary = DeepNavyDark,
    tertiaryContainer = GoldContainer,
    onTertiaryContainer = DeepNavy,
    background = AlabasterCanvas,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = InkSecondary,
    outline = CardOutline,
    outlineVariant = SurfaceMuted,
    error = CrimsonAlert,
    onError = PureWhite,
    errorContainer = CrimsonSoft,
    onErrorContainer = CrimsonAlert
)

private val KolabhoomiDarkColorScheme = darkColorScheme(
    primary = RichGold,
    onPrimary = DeepNavyDark,
    primaryContainer = RoyalBlue,
    onPrimaryContainer = PureWhite,
    secondary = RoyalBlueBright,
    onSecondary = PureWhite,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = RoyalBlueSoft,
    tertiary = InstitutionalGold,
    onTertiary = DeepNavyDark,
    tertiaryContainer = DarkSurfaceElevated,
    onTertiaryContainer = GoldBorder,
    background = DarkCanvas,
    onBackground = PureWhite,
    surface = DarkSurface,
    onSurface = PureWhite,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = RoyalBlueSoft,
    outline = DarkOutline,
    outlineVariant = DarkSurfaceElevated,
    error = CrimsonAlert,
    onError = PureWhite
)

val AcademyShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun KolabhoomiTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KolabhoomiDarkColorScheme else KolabhoomiLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AcademyTypography,
        shapes = AcademyShapes,
        content = content
    )
}

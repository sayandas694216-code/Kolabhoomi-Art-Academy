package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.UserRole
import com.example.ui.screens.AttendanceScreen
import com.example.ui.screens.BranchManagementScreen
import com.example.ui.screens.CourseManagementScreen
import com.example.ui.screens.DocumentStudioScreen
import com.example.ui.screens.ExaminationResultsScreen
import com.example.ui.screens.FeesFinanceScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileAndSettingsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StudentDashboardScreen
import com.example.ui.screens.StudentsScreen
import com.example.ui.screens.SuperAdminDashboardScreen
import com.example.ui.screens.TeacherDashboardScreen
import com.example.ui.screens.TeacherManagementScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.InkMuted
import com.example.ui.theme.PureWhite
import com.example.ui.viewmodel.AcademyViewModel

private data class BottomNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val PrimaryTabs = listOf(
    BottomNavTab("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    BottomNavTab("students", "Students", Icons.Filled.Groups, Icons.Outlined.Groups),
    BottomNavTab("attendance", "Attendance", Icons.Filled.FactCheck, Icons.Outlined.FactCheck),
    BottomNavTab("fees", "Fees", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    BottomNavTab("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)
)

@Composable
fun KolabhoomiAcademyApp(
    viewModel: AcademyViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    // Deep-link state for opening specific document in Document Studio
    var docStudioTab by remember { mutableIntStateOf(0) }
    var docResultId by remember { mutableStateOf<String?>(null) }
    var docFeeId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    val navBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStack?.destination?.route
    val showMainChrome = currentRoute in PrimaryTabs.map { it.route }

    fun openDocumentStudio(tab: Int, resultId: String? = null, feeId: String? = null) {
        docStudioTab = tab
        docResultId = resultId
        docFeeId = feeId
        navController.navigate("documents")
    }

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 700.dp

        Scaffold(
            containerColor = AlabasterCanvas,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (showMainChrome && !isWideScreen) {
                    NavigationBar(
                        containerColor = PureWhite,
                        tonalElevation = 4.dp,
                        windowInsets = WindowInsets.navigationBars,
                        modifier = Modifier.testTag("academy_bottom_nav")
                    ) {
                        PrimaryTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DeepNavy,
                                    selectedTextColor = DeepNavy,
                                    indicatorColor = GoldContainer,
                                    unselectedIconColor = InkMuted,
                                    unselectedTextColor = InkMuted
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showMainChrome && isWideScreen) {
                    NavigationRail(
                        containerColor = PureWhite,
                        modifier = Modifier.statusBarsPadding()
                    ) {
                        PrimaryTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = DeepNavy,
                                    selectedTextColor = DeepNavy,
                                    indicatorColor = GoldContainer
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = "splash"
                    ) {
                        composable("splash") {
                            SplashScreen(
                                academyInfo = state.academyInfo,
                                onFinished = {
                                    navController.navigate("welcome") {
                                        popUpTo("splash") { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable("welcome") {
                            WelcomeScreen(
                                academyInfo = state.academyInfo,
                                onContinueToLogin = { navController.navigate("login") },
                                onQuickRoleLogin = { role ->
                                    val (id, pwd) = when (role) {
                                        UserRole.SUPER_ADMIN -> "KAA-ADM-001" to "admin123"
                                        UserRole.TEACHER -> "KAA-TCH-101" to "teach123"
                                        UserRole.STUDENT -> "KAA-STU-2026-001" to "student123"
                                    }
                                    if (viewModel.login(id, pwd).isSuccess) {
                                        navController.navigate("home") {
                                            popUpTo("welcome") { inclusive = true }
                                        }
                                    }
                                }
                            )
                        }

                        composable("login") {
                            LoginScreen(
                                academyInfo = state.academyInfo,
                                onBack = { navController.popBackStack() },
                                onLoginSubmit = { id, pwd ->
                                    viewModel.login(id, pwd).onSuccess {
                                        navController.navigate("home") {
                                            popUpTo("welcome") { inclusive = true }
                                        }
                                    }
                                },
                                onForgotPassword = { id -> viewModel.requestPasswordReset(id) }
                            )
                        }

                        // PRIMARY TAB 1: HOME (Role-based Dashboards)
                        composable("home") {
                            val mod = Modifier.statusBarsPadding()
                            when (state.currentUser?.role ?: UserRole.SUPER_ADMIN) {
                                UserRole.SUPER_ADMIN -> SuperAdminDashboardScreen(
                                    state = state,
                                    onNavigateRoute = { route ->
                                        if (route in PrimaryTabs.map { it.route }) navigateToTab(route)
                                        else navController.navigate(route)
                                    },
                                    onOpenDocumentStudio = { openDocumentStudio(0) },
                                    modifier = mod
                                )
                                UserRole.TEACHER -> TeacherDashboardScreen(
                                    state = state,
                                    onNavigateRoute = { route ->
                                        if (route in PrimaryTabs.map { it.route }) navigateToTab(route)
                                        else navController.navigate(route)
                                    },
                                    modifier = mod
                                )
                                UserRole.STUDENT -> StudentDashboardScreen(
                                    state = state,
                                    onNavigateRoute = { route ->
                                        if (route in PrimaryTabs.map { it.route }) navigateToTab(route)
                                        else navController.navigate(route)
                                    },
                                    onViewMarksheet = { res -> openDocumentStudio(0, resultId = res.id) },
                                    onViewCertificate = { res -> openDocumentStudio(2, resultId = res.id) },
                                    onViewReceipt = { fee -> openDocumentStudio(1, feeId = fee.id) },
                                    modifier = mod
                                )
                            }
                        }

                        // PRIMARY TAB 2: STUDENTS
                        composable("students") {
                            StudentsScreen(
                                state = state,
                                onGenerateStudentId = { viewModel.generateNextStudentId() },
                                onSaveStudent = { stu, isEdit -> viewModel.addOrUpdateStudent(stu, isEdit) },
                                onDeleteStudent = { id -> viewModel.deleteStudent(id) },
                                modifier = Modifier.statusBarsPadding()
                            )
                        }

                        // PRIMARY TAB 3: ATTENDANCE
                        composable("attendance") {
                            AttendanceScreen(
                                state = state,
                                onMarkAttendance = { d, pid, pname, isT, bid, cname, st ->
                                    viewModel.markAttendance(d, pid, pname, isT, bid, cname, st)
                                },
                                onMarkAllPresent = { d, bid, isT ->
                                    viewModel.markAllPresentForBranch(d, bid, isT)
                                },
                                modifier = Modifier.statusBarsPadding()
                            )
                        }

                        // PRIMARY TAB 4: FEES
                        composable("fees") {
                            FeesFinanceScreen(
                                state = state,
                                onCollectFee = { stu, type, month, amt, paid, mode ->
                                    viewModel.collectFeePayment(stu, type, month, amt, paid, mode)
                                },
                                onSettlePending = { feeId -> viewModel.settlePendingFee(feeId) },
                                onAddExpense = { t, cat, bid, amt, v -> viewModel.addExpense(t, cat, bid, amt, v) },
                                onOpenReceiptDocument = { fee -> openDocumentStudio(1, feeId = fee.id) },
                                modifier = Modifier.statusBarsPadding()
                            )
                        }

                        // PRIMARY TAB 5: PROFILE & SETTINGS
                        composable("profile") {
                            ProfileAndSettingsScreen(
                                state = state,
                                onNavigateRoute = { navController.navigate(it) },
                                onUpdateAcademyInfo = { viewModel.updateAcademyInfo(it) },
                                onUpdateLogoUri = { viewModel.updateAcademyLogoUri(it) },
                                onToggleAccountActive = { viewModel.toggleUserAccountActive(it) },
                                onChangePassword = { cur, newPwd -> viewModel.changePassword(cur, newPwd) },
                                onBackup = { viewModel.performLocalBackup(context) },
                                onRestore = { viewModel.performLocalRestore(context) },
                                onLogout = {
                                    viewModel.logout()
                                    navController.navigate("welcome") {
                                        popUpTo(0) { inclusive = true }
                                    }
                                },
                                modifier = Modifier.statusBarsPadding()
                            )
                        }

                        // SECONDARY ERP MODULE SCREENS
                        composable("branches") {
                            BranchManagementScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onSaveBranch = { br, isEdit -> viewModel.addOrUpdateBranch(br, isEdit) },
                                onDeleteBranch = { viewModel.deleteBranch(it) }
                            )
                        }

                        composable("courses") {
                            CourseManagementScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onSaveCourse = { c, isEdit -> viewModel.addOrUpdateCourse(c, isEdit) },
                                onDeleteCourse = { viewModel.deleteCourse(it) }
                            )
                        }

                        composable("teachers") {
                            TeacherManagementScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onGenerateTeacherId = { viewModel.generateNextTeacherId() },
                                onSaveTeacher = { t, isEdit -> viewModel.addOrUpdateTeacher(t, isEdit) },
                                onPaySalary = { id, m -> viewModel.recordTeacherSalaryPaid(id, m) }
                            )
                        }

                        composable("exams") {
                            ExaminationResultsScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onCreateExam = { t, s, cid, bid, d -> viewModel.createExamination(t, s, cid, bid, d) },
                                onAssignMarks = { e, stu, th, pr, pj, tw, rem ->
                                    viewModel.assignExamMarks(e, stu, th, pr, pj, tw, rem)
                                },
                                onOpenMarksheet = { res -> openDocumentStudio(0, resultId = res.id) },
                                onOpenCertificate = { res -> openDocumentStudio(2, resultId = res.id) }
                            )
                        }

                        composable("documents") {
                            DocumentStudioScreen(
                                state = state,
                                initialTab = docStudioTab,
                                initialResultId = docResultId,
                                initialFeeId = docFeeId,
                                onBack = { navController.popBackStack() },
                                onNotify = { viewModel.postMessage(it) }
                            )
                        }

                        composable("reports") {
                            ReportsScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onNotify = { viewModel.postMessage(it) }
                            )
                        }

                        composable("notifications") {
                            NotificationsScreen(
                                state = state,
                                onBack = { navController.popBackStack() },
                                onMarkAllRead = { viewModel.markAllNoticesRead() },
                                onPublishNotice = { t, b, cat, aud -> viewModel.publishNotice(t, b, cat, aud) }
                            )
                        }

                        composable("settings") {
                            ProfileAndSettingsScreen(
                                state = state,
                                onNavigateRoute = { navController.navigate(it) },
                                onUpdateAcademyInfo = { viewModel.updateAcademyInfo(it) },
                                onUpdateLogoUri = { viewModel.updateAcademyLogoUri(it) },
                                onToggleAccountActive = { viewModel.toggleUserAccountActive(it) },
                                onChangePassword = { cur, newPwd -> viewModel.changePassword(cur, newPwd) },
                                onBackup = { viewModel.performLocalBackup(context) },
                                onRestore = { viewModel.performLocalRestore(context) },
                                onLogout = {
                                    viewModel.logout()
                                    navController.navigate("welcome") {
                                        popUpTo(0) { inclusive = true }
                                    }
                                },
                                modifier = Modifier.statusBarsPadding()
                            )
                        }
                    }
                }
            }
        }
    }
}

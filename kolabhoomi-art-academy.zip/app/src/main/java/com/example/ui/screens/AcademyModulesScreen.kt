package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Branch
import com.example.data.model.Course
import com.example.data.model.Teacher
import com.example.data.model.UserRole
import com.example.ui.components.GoldAccentChip
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.StatusPill
import com.example.ui.components.formatCurrencyInr
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.viewmodel.AcademyUiState

// =========================================================================
// 1. BRANCH MANAGEMENT (Unlimited manual branches)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchManagementScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onSaveBranch: (Branch, Boolean) -> Unit,
    onDeleteBranch: (String) -> Unit
) {
    val canManage = state.currentUser?.role == UserRole.SUPER_ADMIN
    var editingBranch by remember { mutableStateOf<Branch?>(null) }
    var showForm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Branch Management", style = MaterialTheme.typography.titleLarge)
                        Text("${state.branches.size} Active Wings • Unlimited Creation", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = { editingBranch = null; showForm = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("add_branch_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add New Branch")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.branches, key = { it.id }) { branch ->
                val studentCount = state.students.count { it.branchId == branch.id }
                val teacherCount = state.teachers.count { branch.id in it.branchIds }
                val branchRevenue = state.feeRecords.filter { it.branchId == branch.id }.sumOf { it.paidAmount }

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, CardOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Apartment, contentDescription = null, tint = DeepNavy)
                                Column {
                                    Text(branch.name, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                    Text("Code: ${branch.code} • Est. ${branch.establishedYear}", style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
                                }
                            }
                            if (canManage) {
                                Row {
                                    IconButton(onClick = { editingBranch = branch; showForm = true }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Branch", tint = RoyalBlue, modifier = Modifier.size(20.dp))
                                    }
                                    if (state.branches.size > 1) {
                                        IconButton(onClick = { onDeleteBranch(branch.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Branch", tint = CrimsonAlert, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                            }
                        }
                        Text(branch.address, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(15.dp))
                            Text(branch.classTimings, style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                        }
                        Text("Coordinator: ${branch.coordinatorName} (${branch.coordinatorPhone})", style = MaterialTheme.typography.bodySmall, color = InkPrimary)
                        HorizontalDivider(color = CardOutline)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatusPill("$studentCount Students", RoyalBlueSoft, DeepNavy)
                            StatusPill("$teacherCount Teachers", RoyalBlueSoft, RoyalBlue)
                            StatusPill(formatCurrencyInr(branchRevenue), EmeraldSoft, EmeraldSuccess)
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        BranchFormDialog(
            initial = editingBranch,
            nextIndex = state.branches.size + 1,
            onDismiss = { showForm = false; editingBranch = null },
            onSave = { br ->
                onSaveBranch(br, editingBranch != null)
                showForm = false
                editingBranch = null
            }
        )
    }
}

@Composable
private fun BranchFormDialog(
    initial: Branch?,
    nextIndex: Int,
    onDismiss: () -> Unit,
    onSave: (Branch) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var code by remember { mutableStateOf(initial?.code ?: "BR$nextIndex") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var coordinator by remember { mutableStateOf(initial?.coordinatorName ?: "") }
    var phone by remember { mutableStateOf(initial?.coordinatorPhone ?: "+91 ") }
    var timings by remember { mutableStateOf(initial?.classTimings ?: "Tue–Sun • 09:00 AM – 07:30 PM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Establish New Branch" else "Edit Branch Details", color = DeepNavy) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Branch Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = code, onValueChange = { code = it.uppercase().take(4) }, label = { Text("Branch Code (3-4 letters)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Branch Address *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = coordinator, onValueChange = { coordinator = it }, label = { Text("Branch Coordinator") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Coordinator Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = timings, onValueChange = { timings = it }, label = { Text("Class Timings") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            Branch(
                                id = initial?.id ?: "BR-%02d".format(nextIndex),
                                code = code.ifBlank { "BR$nextIndex" },
                                name = name.trim(),
                                address = address.trim().ifBlank { "Kolkata, West Bengal" },
                                coordinatorName = coordinator.trim().ifBlank { "Branch Coordinator" },
                                coordinatorPhone = phone.trim(),
                                classTimings = timings.trim(),
                                establishedYear = initial?.establishedYear ?: 2026
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
            ) { Text("Save Branch") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// =========================================================================
// 2. COURSE MANAGEMENT
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CourseManagementScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onSaveCourse: (Course, Boolean) -> Unit,
    onDeleteCourse: (String) -> Unit
) {
    val canManage = state.currentUser?.role == UserRole.SUPER_ADMIN
    var editingCourse by remember { mutableStateOf<Course?>(null) }
    var showForm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Course Curriculum", style = MaterialTheme.typography.titleLarge)
                        Text("${state.courses.size} Disciplines • Fees & Faculty", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = { editingCourse = null; showForm = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("add_course_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Course")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.courses, key = { it.id }) { course ->
                val enrolled = state.students.count { course.id in it.courseIds }
                val teacherNames = state.teachers
                    .filter { it.id in course.assignedTeacherIds || course.id in it.courseIds }
                    .joinToString(", ") { it.fullName }
                    .ifBlank { "Faculty Assigned" }

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, CardOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(course.name, style = MaterialTheme.typography.titleLarge, color = DeepNavy)
                                Text("${course.category} • ${course.durationMonths} Months", style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
                            }
                            if (canManage) {
                                Row {
                                    IconButton(onClick = { editingCourse = course; showForm = true }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = RoyalBlue, modifier = Modifier.size(20.dp))
                                    }
                                    IconButton(onClick = { onDeleteCourse(course.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonAlert, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                        Text(course.description, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Text("Faculty: $teacherNames", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                        HorizontalDivider(color = CardOutline)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GoldAccentChip("Monthly: ${formatCurrencyInr(course.monthlyFee)}")
                            Text("Admission: ${formatCurrencyInr(course.admissionFee)}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                            StatusPill("$enrolled Scholars", RoyalBlueSoft, DeepNavy)
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var name by remember { mutableStateOf(editingCourse?.name ?: "") }
        var category by remember { mutableStateOf(editingCourse?.category ?: "Fine Arts") }
        var monthlyFee by remember { mutableStateOf((editingCourse?.monthlyFee ?: 1600.0).toInt().toString()) }
        var admissionFee by remember { mutableStateOf((editingCourse?.admissionFee ?: 2000.0).toInt().toString()) }
        var desc by remember { mutableStateOf(editingCourse?.description ?: "") }
        var assignedTeachers by remember { mutableStateOf(editingCourse?.assignedTeacherIds?.toSet() ?: emptySet()) }

        AlertDialog(
            onDismissRequest = { showForm = false; editingCourse = null },
            title = { Text(if (editingCourse == null) "Add Academy Course" else "Edit Course", color = DeepNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Course Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Discipline Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = monthlyFee,
                            onValueChange = { monthlyFee = it },
                            label = { Text("Monthly Fee") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = admissionFee,
                            onValueChange = { admissionFee = it },
                            label = { Text("Admission Fee") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Syllabus Description") }, modifier = Modifier.fillMaxWidth())
                    Text("Assign Faculty", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.teachers.forEach { t ->
                            val isSel = t.id in assignedTeachers
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    assignedTeachers = if (isSel) assignedTeachers - t.id else assignedTeachers + t.id
                                },
                                label = { Text(t.fullName.substringAfter(" ")) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSaveCourse(
                                Course(
                                    id = editingCourse?.id ?: "CRS-${state.courses.size + 1}",
                                    name = name.trim(),
                                    category = category.trim(),
                                    monthlyFee = monthlyFee.toDoubleOrNull() ?: 1500.0,
                                    admissionFee = admissionFee.toDoubleOrNull() ?: 2000.0,
                                    durationMonths = editingCourse?.durationMonths ?: 24,
                                    description = desc.trim().ifBlank { "Structured academy certification program." },
                                    assignedTeacherIds = assignedTeachers.toList()
                                ),
                                editingCourse != null
                            )
                            showForm = false
                            editingCourse = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Save Course") }
            },
            dismissButton = { TextButton(onClick = { showForm = false; editingCourse = null }) { Text("Cancel") } }
        )
    }
}

// =========================================================================
// 3. TEACHER MANAGEMENT
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TeacherManagementScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onGenerateTeacherId: () -> String,
    onSaveTeacher: (Teacher, Boolean) -> Unit,
    onPaySalary: (String, String) -> Unit
) {
    val canManage = state.currentUser?.role == UserRole.SUPER_ADMIN
    var viewingTeacher by remember { mutableStateOf<Teacher?>(null) }
    var showAddForm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Faculty & Teachers", style = MaterialTheme.typography.titleLarge)
                        Text("${state.teachers.size} Mentors • Schedule & Payroll", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = { showAddForm = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("add_teacher_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Teacher")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.teachers, key = { it.id }) { teacher ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewingTeacher = teacher },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, CardOutline)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            InitialsAvatar(name = teacher.fullName, size = 48.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(teacher.fullName, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                Text("${teacher.id} • ${teacher.specialization}", style = MaterialTheme.typography.bodySmall, color = RoyalBlue)
                                Text(teacher.qualification, style = MaterialTheme.typography.labelSmall, color = InkMuted)
                            }
                        }
                        Text("Courses: ${state.courseNames(teacher.courseIds)}", style = MaterialTheme.typography.bodySmall, color = InkPrimary)
                        Text("Schedule: ${teacher.classSchedule}", style = MaterialTheme.typography.labelSmall, color = InkSecondary)
                        HorizontalDivider(color = CardOutline)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GoldAccentChip("Salary: ${formatCurrencyInr(teacher.monthlySalary)}/mo")
                            Text("${teacher.branchIds.size} Branches", style = MaterialTheme.typography.labelMedium, color = RoyalBlue)
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    // Teacher Profile & Salary Dialog
    viewingTeacher?.let { t ->
        val freshTeacher = state.teachers.find { it.id == t.id } ?: t
        AlertDialog(
            onDismissRequest = { viewingTeacher = null },
            title = {
                Column {
                    Text(freshTeacher.fullName, color = DeepNavy)
                    Text("${freshTeacher.id} • ${freshTeacher.specialization}", style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Qualification: ${freshTeacher.qualification}", style = MaterialTheme.typography.bodySmall)
                    Text("Phone: ${freshTeacher.phone}", style = MaterialTheme.typography.bodySmall)
                    Text("Email: ${freshTeacher.email}", style = MaterialTheme.typography.bodySmall)
                    Text("Branches: ${freshTeacher.branchIds.joinToString { state.branchName(it) }}", style = MaterialTheme.typography.bodySmall)
                    Text("Schedule: ${freshTeacher.classSchedule}", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(color = CardOutline)
                    Text("Salary Disbursement Ledger", style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                    freshTeacher.salaryRecords.forEach { sal ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${sal.month} (${sal.paidDate})", style = MaterialTheme.typography.bodySmall)
                            Text("${formatCurrencyInr(sal.amount)} • ${sal.status}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        }
                    }
                }
            },
            confirmButton = {
                if (canManage) {
                    Button(
                        onClick = { onPaySalary(freshTeacher.id, "Nov 2026") },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                    ) {
                        Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pay Nov Salary")
                    }
                }
            },
            dismissButton = { TextButton(onClick = { viewingTeacher = null }) { Text("Close") } }
        )
    }

    if (showAddForm) {
        val nextId = remember { onGenerateTeacherId() }
        var name by remember { mutableStateOf("") }
        var spec by remember { mutableStateOf("") }
        var qual by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("+91 ") }
        var email by remember { mutableStateOf("") }
        var salary by remember { mutableStateOf("38000") }
        var schedule by remember { mutableStateOf("Tue, Thu, Sat • 04:00 PM – 07:30 PM") }
        var branchIds by remember { mutableStateOf(setOf(state.branches.firstOrNull()?.id ?: "BR-01")) }
        var courseIds by remember { mutableStateOf(setOf(state.courses.firstOrNull()?.id ?: "CRS-01")) }

        AlertDialog(
            onDismissRequest = { showAddForm = false },
            title = {
                Column {
                    Text("Onboard Faculty Member", color = DeepNavy)
                    Text("Teacher ID: $nextId", style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = spec, onValueChange = { spec = it }, label = { Text("Specialization *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = qual, onValueChange = { qual = it }, label = { Text("Qualification") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = salary,
                        onValueChange = { salary = it },
                        label = { Text("Monthly Salary (INR)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(value = schedule, onValueChange = { schedule = it }, label = { Text("Class Schedule") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Assign Branches", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.branches.forEach { br ->
                            val sel = br.id in branchIds
                            FilterChip(selected = sel, onClick = { branchIds = if (sel && branchIds.size > 1) branchIds - br.id else branchIds + br.id }, label = { Text(br.code) })
                        }
                    }
                    Text("Assign Courses", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.courses.forEach { c ->
                            val sel = c.id in courseIds
                            FilterChip(selected = sel, onClick = { courseIds = if (sel && courseIds.size > 1) courseIds - c.id else courseIds + c.id }, label = { Text(c.name) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSaveTeacher(
                                Teacher(
                                    id = nextId,
                                    fullName = name.trim(),
                                    specialization = spec.trim().ifBlank { "Fine Arts Faculty" },
                                    qualification = qual.trim().ifBlank { "Master of Fine Arts" },
                                    phone = phone.trim(),
                                    email = email.trim().ifBlank { "${name.lowercase().replace(" ", ".")}@kolabhoomi.edu.in" },
                                    address = "Kolkata",
                                    branchIds = branchIds.toList(),
                                    courseIds = courseIds.toList(),
                                    monthlySalary = salary.toDoubleOrNull() ?: 35000.0,
                                    joiningDate = "2026-11-24",
                                    classSchedule = schedule.trim()
                                ),
                                false
                            )
                            showAddForm = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Add Teacher") }
            },
            dismissButton = { OutlinedButton(onClick = { showAddForm = false }) { Text("Cancel") } }
        )
    }
}

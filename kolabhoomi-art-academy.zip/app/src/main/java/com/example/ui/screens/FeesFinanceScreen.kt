package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.FeeRecord
import com.example.data.model.FeeStatus
import com.example.data.model.FeeType
import com.example.data.model.Student
import com.example.data.model.UserRole
import com.example.ui.components.NavyGradientBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.formatCurrencyInr
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.viewmodel.AcademyUiState

@Composable
fun FeesFinanceScreen(
    state: AcademyUiState,
    onCollectFee: (Student, FeeType, String, Double, Double, String) -> FeeRecord,
    onSettlePending: (String) -> Unit,
    onAddExpense: (String, String, String, Double, String) -> Unit,
    onOpenReceiptDocument: (FeeRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val role = state.currentUser?.role ?: UserRole.SUPER_ADMIN
    val isAdmin = role == UserRole.SUPER_ADMIN
    val isStudent = role == UserRole.STUDENT

    var selectedTab by remember { mutableIntStateOf(0) }
    var showCollectFeeDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    val scopedFees = remember(state.feeRecords, role, state.currentUser) {
        if (isStudent) {
            val sid = state.currentStudent()?.id
            state.feeRecords.filter { it.studentId == sid }
        } else {
            state.feeRecords
        }
    }

    val tabs = if (isAdmin) listOf("Payments", "Pending", "Expenses") else listOf("All Receipts", "Pending")

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("fees_finance_screen"),
        containerColor = AlabasterCanvas,
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = {
                        if (selectedTab == 2) showAddExpenseDialog = true else showCollectFeeDialog = true
                    },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("fees_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = if (selectedTab == 2) "Log Expense" else "Collect Fee")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(color = PureWhite, shadowElevation = 1.dp) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(
                            text = if (isStudent) "My Fees & Receipts" else "Fees & Finance Ledger",
                            style = MaterialTheme.typography.headlineMedium,
                            color = DeepNavy
                        )
                        Text(
                            text = "Admission, tuition, receipts, income reports & expenses",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkMuted
                        )
                    }
                    TabRow(
                        selectedTabIndex = selectedTab.coerceIn(0, tabs.lastIndex),
                        containerColor = PureWhite,
                        contentColor = DeepNavy,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.coerceIn(0, tabs.lastIndex)]),
                                color = InstitutionalGold
                            )
                        }
                    ) {
                        tabs.forEachIndexed { idx, title ->
                            Tab(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                            )
                        }
                    }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Summary Banner
                item {
                    NavyGradientBanner {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (isStudent) "Total Settled" else "Collected Tuition",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldBorder
                                )
                                Text(
                                    text = formatCurrencyInr(scopedFees.sumOf { it.paidAmount }),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = PureWhite
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Pending Dues", style = MaterialTheme.typography.labelSmall, color = RoyalBlueSoft)
                                Text(
                                    text = formatCurrencyInr(scopedFees.sumOf { it.balanceDue }),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = RichGold
                                )
                            }
                        }
                    }
                }

                if (isAdmin && selectedTab == 2) {
                    // Expense Management List
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Operating Expenses", style = MaterialTheme.typography.titleLarge, color = DeepNavy)
                            Text(
                                text = "Total: ${formatCurrencyInr(state.totalMonthlyExpenses)}",
                                style = MaterialTheme.typography.titleSmall,
                                color = CrimsonAlert
                            )
                        }
                    }
                    items(state.expenses, key = { it.id }) { exp ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, CardOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(exp.title, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                                    Text("${exp.category} • ${exp.vendor}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                                    Text("${exp.date} • ${state.branchName(exp.branchId)}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                                }
                                Text(
                                    text = "- ${formatCurrencyInr(exp.amount)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CrimsonAlert,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                } else {
                    val displayedFees = if (selectedTab == 1) {
                        scopedFees.filter { it.status != FeeStatus.PAID }
                    } else {
                        scopedFees
                    }

                    items(displayedFees, key = { it.id }) { fee ->
                        val (bg, fg) = when (fee.status) {
                            FeeStatus.PAID -> EmeraldSoft to EmeraldSuccess
                            FeeStatus.PARTIAL -> AmberSoft to AmberWarning
                            FeeStatus.PENDING -> AmberSoft to AmberWarning
                            FeeStatus.OVERDUE -> CrimsonSoft to CrimsonAlert
                        }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, CardOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(fee.studentName, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                        Text("${fee.receiptNo} • ${fee.feeType.label}", style = MaterialTheme.typography.labelSmall, color = RoyalBlue)
                                        Text("${fee.courseName} • ${fee.billingMonth}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(formatCurrencyInr(fee.amount), style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                        StatusPill(fee.status.label, bg, fg)
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { onOpenReceiptDocument(fee) },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("open_receipt_${fee.receiptNo}")
                                    ) {
                                        Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Receipt PDF", style = MaterialTheme.typography.labelMedium)
                                    }
                                    if (isAdmin && fee.status != FeeStatus.PAID) {
                                        Button(
                                            onClick = { onSettlePending(fee.id) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Mark Paid", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    if (showCollectFeeDialog && state.students.isNotEmpty()) {
        CollectFeeDialog(
            students = state.students,
            onDismiss = { showCollectFeeDialog = false },
            onSave = { student, type, month, amt, paid, mode ->
                val created = onCollectFee(student, type, month, amt, paid, mode)
                showCollectFeeDialog = false
                onOpenReceiptDocument(created)
            }
        )
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            branches = state.branches,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { title, cat, brId, amt, vendor ->
                onAddExpense(title, cat, brId, amt, vendor)
                showAddExpenseDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CollectFeeDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onSave: (Student, FeeType, String, Double, Double, String) -> Unit
) {
    var selectedStudent by remember { mutableStateOf(students.first()) }
    var feeType by remember { mutableStateOf(FeeType.MONTHLY_TUITION) }
    var monthLabel by remember { mutableStateOf("Nov 2026") }
    var amountText by remember { mutableStateOf("2800") }
    var paymentMode by remember { mutableStateOf("UPI / Bank") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Collect Fee & Generate Receipt", color = DeepNavy) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Select Scholar", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    students.take(8).forEach { stu ->
                        FilterChip(
                            selected = selectedStudent.id == stu.id,
                            onClick = { selectedStudent = stu },
                            label = { Text(stu.fullName.substringBefore(" ")) }
                        )
                    }
                }
                Text("Fee Category", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FeeType.entries.forEach { ft ->
                        FilterChip(
                            selected = feeType == ft,
                            onClick = { feeType = ft },
                            label = { Text(ft.label) }
                        )
                    }
                }
                OutlinedTextField(value = monthLabel, onValueChange = { monthLabel = it }, label = { Text("Billing Period") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (INR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Payment Mode", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("UPI / Bank", "Card", "Cash", "Net Banking").forEach { m ->
                        FilterChip(selected = paymentMode == m, onClick = { paymentMode = m }, label = { Text(m) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 2500.0
                    onSave(selectedStudent, feeType, monthLabel, amt, amt, paymentMode)
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
            ) { Text("Save & Preview Receipt") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddExpenseDialog(
    branches: List<com.example.data.model.Branch>,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Art Supplies") }
    var branchId by remember { mutableStateOf(branches.firstOrNull()?.id ?: "BR-01") }
    var amount by remember { mutableStateOf("") }
    var vendor by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Academy Expense", color = DeepNavy) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Expense Description *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount (INR) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = vendor, onValueChange = { vendor = it }, label = { Text("Vendor / Payee") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    branches.forEach { br ->
                        FilterChip(selected = branchId == br.id, onClick = { branchId = br.id }, label = { Text(br.code) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: return@Button
                    if (title.isNotBlank()) {
                        onSave(title.trim(), category.trim(), branchId, amt, vendor.trim().ifBlank { "Academy Vendor" })
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
            ) { Text("Record Expense") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

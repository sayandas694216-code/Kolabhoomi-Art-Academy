package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AttendanceStatus
import com.example.data.model.UserRole
import com.example.ui.components.BranchAttendanceBarChart
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.NavyGradientBanner
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.theme.SurfaceMuted
import com.example.ui.viewmodel.AcademyUiState

@Composable
fun AttendanceScreen(
    state: AcademyUiState,
    onMarkAttendance: (String, String, String, Boolean, String, String, AttendanceStatus) -> Unit,
    onMarkAllPresent: (String, String?, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isStudent = state.currentUser?.role == UserRole.STUDENT
    val isAdmin = state.currentUser?.role == UserRole.SUPER_ADMIN
    val dates = remember { listOf("2026-11-24", "2026-11-22", "2026-11-20") }
    var selectedDate by remember { mutableStateOf(dates.first()) }
    var selectedBranchId by remember { mutableStateOf<String?>(null) }
    var selectedTab by remember { mutableIntStateOf(0) }

    if (isStudent) {
        StudentAttendanceHistoryView(state = state, modifier = modifier)
        return
    }

    val tabs = if (isAdmin) listOf("Students", "Teachers", "Branch Report") else listOf("Students", "Branch Report")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .testTag("attendance_screen")
    ) {
        Surface(color = PureWhite, shadowElevation = 1.dp) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text("Attendance Register", style = MaterialTheme.typography.headlineMedium, color = DeepNavy)
                    Text("Daily Present / Absent / Leave tracking & monthly reports", style = MaterialTheme.typography.bodySmall, color = InkMuted)
                }
                TabRow(
                    selectedTabIndex = selectedTab.coerceIn(0, tabs.lastIndex),
                    containerColor = PureWhite,
                    contentColor = DeepNavy,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.coerceIn(0, tabs.lastIndex)]),
                            color = InstitutionalGold
                        )
                    }
                ) {
                    tabs.forEachIndexed { idx, title ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                        )
                    }
                }
            }
        }

        val isReportTab = (isAdmin && selectedTab == 2) || (!isAdmin && selectedTab == 1)
        val isTeacherTab = isAdmin && selectedTab == 1

        if (isReportTab) {
            val branchStats = remember(state.branches, state.attendanceRecords) { state.branchAttendanceStats() }
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item { BranchAttendanceBarChart(stats = branchStats) }
                item {
                    Text("Recent Attendance History", style = MaterialTheme.typography.titleLarge, color = DeepNavy)
                }
                items(state.attendanceRecords.take(15)) { rec ->
                    val (bg, fg) = statusColors(rec.status)
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = BorderStroke(1.dp, CardOutline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rec.personName, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                                Text(
                                    text = "${if (rec.isTeacher) "Faculty" else "Student"} • ${rec.date} • ${state.branchName(rec.branchId)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = InkMuted
                                )
                            }
                            StatusPill(rec.status.label, bg, fg)
                        }
                    }
                }
            }
        } else {
            // Date & Branch Filter Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PureWhite)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        dates.forEach { d ->
                            FilterChip(
                                selected = selectedDate == d,
                                onClick = { selectedDate = d },
                                label = { Text(d.takeLast(5), style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = DeepNavy, selectedLabelColor = PureWhite)
                            )
                        }
                    }
                    Button(
                        onClick = { onMarkAllPresent(selectedDate, selectedBranchId, isTeacherTab) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("mark_all_present_btn")
                    ) {
                        Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("All Present", style = MaterialTheme.typography.labelMedium)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedBranchId == null,
                        onClick = { selectedBranchId = null },
                        label = { Text("All Branches") }
                    )
                    state.branches.forEach { br ->
                        FilterChip(
                            selected = selectedBranchId == br.id,
                            onClick = { selectedBranchId = if (selectedBranchId == br.id) null else br.id },
                            label = { Text(br.code) }
                        )
                    }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (!isTeacherTab) {
                    val list = state.students.filter { selectedBranchId == null || it.branchId == selectedBranchId }
                    items(list, key = { it.id }) { stu ->
                        val currentStatus = state.attendanceRecords.find {
                            !it.isTeacher && it.date == selectedDate && it.personId == stu.id
                        }?.status
                        AttendanceToggleCard(
                            name = stu.fullName,
                            subtitle = "${stu.id} • ${state.courseNames(stu.courseIds)}",
                            photoUri = stu.photoUri,
                            currentStatus = currentStatus,
                            onSelectStatus = { st ->
                                onMarkAttendance(selectedDate, stu.id, stu.fullName, false, stu.branchId, state.courseNames(stu.courseIds), st)
                            }
                        )
                    }
                } else {
                    val list = state.teachers.filter { selectedBranchId == null || selectedBranchId in it.branchIds }
                    items(list, key = { it.id }) { tch ->
                        val currentStatus = state.attendanceRecords.find {
                            it.isTeacher && it.date == selectedDate && it.personId == tch.id
                        }?.status
                        AttendanceToggleCard(
                            name = tch.fullName,
                            subtitle = "${tch.id} • ${tch.specialization}",
                            photoUri = null,
                            currentStatus = currentStatus,
                            onSelectStatus = { st ->
                                onMarkAttendance(
                                    selectedDate,
                                    tch.id,
                                    tch.fullName,
                                    true,
                                    tch.branchIds.firstOrNull() ?: "BR-01",
                                    tch.specialization,
                                    st
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendanceToggleCard(
    name: String,
    subtitle: String,
    photoUri: String?,
    currentStatus: AttendanceStatus?,
    onSelectStatus: (AttendanceStatus) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InitialsAvatar(name = name, photoUri = photoUri, size = 40.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                }
                currentStatus?.let {
                    val (bg, fg) = statusColors(it)
                    StatusPill(it.label, bg, fg)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                AttendanceStatus.entries.forEach { st ->
                    val isSel = currentStatus == st
                    val (activeBg, activeFg) = when (st) {
                        AttendanceStatus.PRESENT -> DeepNavy to PureWhite
                        AttendanceStatus.LEAVE -> InstitutionalGold to DeepNavy
                        AttendanceStatus.ABSENT -> CrimsonAlert to PureWhite
                    }
                    Surface(
                        color = if (isSel) activeBg else SurfaceMuted,
                        shape = RoundedCornerShape(10.dp),
                        border = if (isSel) null else BorderStroke(1.dp, CardOutline),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectStatus(st) }
                    ) {
                        Text(
                            text = st.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSel) activeFg else InkSecondary,
                            modifier = Modifier.padding(vertical = 10.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StudentAttendanceHistoryView(
    state: AcademyUiState,
    modifier: Modifier = Modifier
) {
    val student = state.currentStudent()
    val myRecords = remember(state.attendanceRecords, student) {
        if (student == null) emptyList()
        else state.attendanceRecords.filter { !it.isTeacher && it.personId == student.id }
    }
    val pct = student?.let { state.studentAttendancePercent(it.id) } ?: 94

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            NavyGradientBanner {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("MY ATTENDANCE STANDING", style = MaterialTheme.typography.labelSmall, color = RichGold)
                        Text("$pct% Overall", style = MaterialTheme.typography.displayMedium, color = PureWhite)
                        Text("Minimum 80% required for Annual Diploma", style = MaterialTheme.typography.bodySmall, color = RoyalBlueSoft)
                    }
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RichGold, modifier = Modifier.size(44.dp))
                }
            }
        }
        item {
            Text("Attendance Log History", style = MaterialTheme.typography.titleLarge, color = DeepNavy)
        }
        items(myRecords) { rec ->
            val (bg, fg) = statusColors(rec.status)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(rec.courseName, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                        Text("${rec.date} • ${state.branchName(rec.branchId)}", style = MaterialTheme.typography.bodySmall, color = InkMuted)
                    }
                    StatusPill(rec.status.label, bg, fg)
                }
            }
        }
    }
}

private fun statusColors(status: AttendanceStatus) = when (status) {
    AttendanceStatus.PRESENT -> EmeraldSoft to EmeraldSuccess
    AttendanceStatus.LEAVE -> AmberSoft to AmberWarning
    AttendanceStatus.ABSENT -> CrimsonSoft to CrimsonAlert
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AcademyInfo
import com.example.data.model.ExamResult
import com.example.data.model.Examination
import com.example.data.model.FeeRecord
import com.example.data.model.FeeStatus
import com.example.data.model.Student
import com.example.data.model.UserRole
import com.example.ui.components.AcademyLogoBadge
import com.example.ui.components.GoldAccentChip
import com.example.ui.components.QrVerificationCanvas
import com.example.ui.components.SignatureFieldBlock
import com.example.ui.components.StatusPill
import com.example.ui.components.formatCurrencyInr
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.CardOutline
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PlayfairDisplayFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.theme.SurfaceMuted
import com.example.ui.viewmodel.AcademyUiState
import com.example.util.PdfDocumentGenerator
import java.util.Locale

// =========================================================================
// 1. EXAMINATION & RESULTS MANAGEMENT
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExaminationResultsScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onCreateExam: (String, String, String, String, String) -> Unit,
    onAssignMarks: (Examination, Student, Int, Int, Int, Int, String) -> ExamResult,
    onOpenMarksheet: (ExamResult) -> Unit,
    onOpenCertificate: (ExamResult) -> Unit
) {
    val canEdit = state.currentUser?.role != UserRole.STUDENT
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreateExamDialog by remember { mutableStateOf(false) }
    var gradingExam by remember { mutableStateOf<Examination?>(null) }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Examinations & Results", style = MaterialTheme.typography.titleLarge)
                        Text("Theory, Practical, Project & Teamwork Evaluation", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        floatingActionButton = {
            if (canEdit) {
                FloatingActionButton(
                    onClick = { showCreateExamDialog = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("create_exam_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create Examination")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = PureWhite,
                contentColor = DeepNavy,
                indicator = { pos ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(pos[selectedTab]),
                        color = InstitutionalGold
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Published Results") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Scheduled Exams") })
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (selectedTab == 0) {
                    items(state.examResults, key = { it.id }) { res ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, CardOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(res.studentName, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                        Text("${res.examTitle} • ${res.courseName}", style = MaterialTheme.typography.bodySmall, color = RoyalBlue)
                                        Text("${res.studentId} • ${res.branchName}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                                    }
                                    GoldAccentChip("${res.totalObtained}/${res.totalMax} • ${res.shortGrade}")
                                }

                                // 4-Component Marks Strip
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    MarkMiniChip("Theory", "${res.theoryMarks}/${res.maxTheory}", Modifier.weight(1f))
                                    MarkMiniChip("Practical", "${res.practicalMarks}/${res.maxPractical}", Modifier.weight(1f))
                                    MarkMiniChip("Project", "${res.projectMarks}/${res.maxProject}", Modifier.weight(1f))
                                    MarkMiniChip("Teamwork", "${res.teamworkMarks}/${res.maxTeamwork}", Modifier.weight(1f))
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { onOpenMarksheet(res) },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Marksheet PDF", style = MaterialTheme.typography.labelMedium)
                                    }
                                    Button(
                                        onClick = { onOpenCertificate(res) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("QR Certificate", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(state.examinations, key = { it.id }) { exam ->
                        val courseName = state.courses.find { it.id == exam.courseId }?.name ?: "Fine Arts"
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = BorderStroke(1.dp, CardOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(exam.title, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                                        Text("$courseName • Session ${exam.session}", style = MaterialTheme.typography.bodySmall, color = RoyalBlue)
                                        Text("Exam Date: ${exam.examDate} • ${state.branchName(exam.branchId)}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                                    }
                                    StatusPill("Max ${exam.totalMaxMarks}", RoyalBlueSoft, DeepNavy)
                                }
                                Text(
                                    text = "Weights: Theory (${exam.maxTheory}) • Practical (${exam.maxPractical}) • Project (${exam.maxProject}) • Teamwork (${exam.maxTeamwork})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = InkSecondary
                                )
                                if (canEdit) {
                                    Button(
                                        onClick = { gradingExam = exam },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Assign Student Marks & Generate Result")
                                    }
                                }
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    if (showCreateExamDialog) {
        var title by remember { mutableStateOf("") }
        var session by remember { mutableStateOf("2026–2027") }
        var examDate by remember { mutableStateOf("2026-12-10") }
        var courseId by remember { mutableStateOf(state.courses.firstOrNull()?.id ?: "CRS-01") }
        var branchId by remember { mutableStateOf(state.branches.firstOrNull()?.id ?: "BR-01") }

        AlertDialog(
            onDismissRequest = { showCreateExamDialog = false },
            title = { Text("Create New Examination", color = DeepNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Examination Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = session, onValueChange = { session = it }, label = { Text("Session") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = examDate, onValueChange = { examDate = it }, label = { Text("Exam Date") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("Course Discipline", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.courses.forEach { c ->
                            FilterChip(selected = courseId == c.id, onClick = { courseId = c.id }, label = { Text(c.name) })
                        }
                    }
                    Text("Branch Center", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.branches.forEach { br ->
                            FilterChip(selected = branchId == br.id, onClick = { branchId = br.id }, label = { Text(br.code) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            onCreateExam(title.trim(), session.trim(), courseId, branchId, examDate.trim())
                            showCreateExamDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Create Exam") }
            },
            dismissButton = { TextButton(onClick = { showCreateExamDialog = false }) { Text("Cancel") } }
        )
    }

    gradingExam?.let { exam ->
        var selectedStudent by remember { mutableStateOf(state.students.first()) }
        var theory by remember { mutableStateOf("26") }
        var practical by remember { mutableStateOf("36") }
        var project by remember { mutableStateOf("18") }
        var teamwork by remember { mutableStateOf("9") }
        var remarks by remember { mutableStateOf("Distinguished artistry and studio discipline.") }

        AlertDialog(
            onDismissRequest = { gradingExam = null },
            title = {
                Column {
                    Text("Assign Marks", color = DeepNavy)
                    Text(exam.title, style = MaterialTheme.typography.labelSmall, color = InstitutionalGold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Select Student", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.students.take(8).forEach { s ->
                            FilterChip(selected = selectedStudent.id == s.id, onClick = { selectedStudent = s }, label = { Text(s.fullName.substringBefore(" ")) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = theory,
                            onValueChange = { theory = it },
                            label = { Text("Theory /${exam.maxTheory}") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = practical,
                            onValueChange = { practical = it },
                            label = { Text("Practical /${exam.maxPractical}") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = project,
                            onValueChange = { project = it },
                            label = { Text("Project /${exam.maxProject}") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = teamwork,
                            onValueChange = { teamwork = it },
                            label = { Text("Teamwork /${exam.maxTeamwork}") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(value = remarks, onValueChange = { remarks = it }, label = { Text("Examiner Remarks") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val saved = onAssignMarks(
                            exam,
                            selectedStudent,
                            theory.toIntOrNull() ?: 25,
                            practical.toIntOrNull() ?: 35,
                            project.toIntOrNull() ?: 17,
                            teamwork.toIntOrNull() ?: 8,
                            remarks
                        )
                        gradingExam = null
                        onOpenMarksheet(saved)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Publish & View Marksheet") }
            },
            dismissButton = { TextButton(onClick = { gradingExam = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MarkMiniChip(label: String, score: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = SurfaceMuted,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = InkMuted, maxLines = 1)
            Text(score, style = MaterialTheme.typography.labelLarge, color = DeepNavy, fontWeight = FontWeight.Bold)
        }
    }
}

// =========================================================================
// 2. PROFESSIONAL DOCUMENT GENERATION STUDIO (Marksheet, Receipt, QR Cert)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentStudioScreen(
    state: AcademyUiState,
    initialTab: Int = 0, // 0 = Marksheet, 1 = Payment Receipt, 2 = QR Certificate
    initialResultId: String? = null,
    initialFeeId: String? = null,
    onBack: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 2)) }
    var selectedResult by remember(state.examResults, initialResultId) {
        mutableStateOf(
            state.examResults.find { it.id == initialResultId } ?: state.examResults.firstOrNull()
        )
    }
    var selectedFee by remember(state.feeRecords, initialFeeId) {
        mutableStateOf(
            state.feeRecords.find { it.id == initialFeeId } ?: state.feeRecords.firstOrNull()
        )
    }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Official Document Studio", style = MaterialTheme.typography.titleLarge)
                        Text("Print-Ready PDFs • Digital Signatures • QR Verification", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("document_studio_screen")
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = PureWhite,
                contentColor = DeepNavy,
                indicator = { pos ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(pos[selectedTab]),
                        color = InstitutionalGold
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Marksheet") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Fee Receipt") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("QR Certificate") })
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Record Switcher Strip
                if (selectedTab == 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.feeRecords.take(8).forEach { fee ->
                            FilterChip(
                                selected = selectedFee?.id == fee.id,
                                onClick = { selectedFee = fee },
                                label = { Text("${fee.studentName.substringBefore(" ")} (${fee.receiptNo.takeLast(4)})") },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = DeepNavy, selectedLabelColor = PureWhite)
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.examResults.forEach { res ->
                            FilterChip(
                                selected = selectedResult?.id == res.id,
                                onClick = { selectedResult = res },
                                label = { Text("${res.studentName.substringBefore(" ")} • ${res.courseName}") },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = DeepNavy, selectedLabelColor = PureWhite)
                            )
                        }
                    }
                }

                // Live High-Fidelity Document Preview
                when (selectedTab) {
                    0 -> selectedResult?.let { res ->
                        MarksheetPreviewCard(academyInfo = state.academyInfo, result = res)
                        PdfExportActionBar(
                            label = "Export Official Marksheet PDF",
                            tag = "export_marksheet_pdf_btn",
                            onExportOnly = {
                                PdfDocumentGenerator.exportMarksheetPdf(context, state.academyInfo, res)
                                    .onSuccess { file -> onNotify("Saved Marksheet PDF: ${file.name}") }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            },
                            onExportAndShare = {
                                PdfDocumentGenerator.exportMarksheetPdf(context, state.academyInfo, res)
                                    .onSuccess { file ->
                                        onNotify("Marksheet PDF ready: ${file.name}")
                                        PdfDocumentGenerator.sharePdfFile(context, file, "Kolabhoomi Marksheet - ${res.studentName}")
                                    }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            }
                        )
                    }
                    1 -> selectedFee?.let { fee ->
                        val branchName = state.branchName(fee.branchId)
                        PaymentReceiptPreviewCard(academyInfo = state.academyInfo, fee = fee, branchName = branchName)
                        PdfExportActionBar(
                            label = "Export Official Receipt PDF",
                            tag = "export_receipt_pdf_btn",
                            onExportOnly = {
                                PdfDocumentGenerator.exportPaymentReceiptPdf(context, state.academyInfo, fee, branchName)
                                    .onSuccess { file -> onNotify("Saved Receipt PDF: ${file.name}") }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            },
                            onExportAndShare = {
                                PdfDocumentGenerator.exportPaymentReceiptPdf(context, state.academyInfo, fee, branchName)
                                    .onSuccess { file ->
                                        onNotify("Receipt PDF ready: ${file.name}")
                                        PdfDocumentGenerator.sharePdfFile(context, file, "Kolabhoomi Receipt - ${fee.receiptNo}")
                                    }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            }
                        )
                    }
                    else -> selectedResult?.let { res ->
                        QrCertificatePreviewCard(academyInfo = state.academyInfo, result = res)
                        PdfExportActionBar(
                            label = "Export QR-Verified Certificate PDF",
                            tag = "export_certificate_pdf_btn",
                            onExportOnly = {
                                PdfDocumentGenerator.exportCertificatePdf(context, state.academyInfo, res)
                                    .onSuccess { file -> onNotify("Saved Certificate PDF: ${file.name}") }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            },
                            onExportAndShare = {
                                PdfDocumentGenerator.exportCertificatePdf(context, state.academyInfo, res)
                                    .onSuccess { file ->
                                        onNotify("Certificate PDF ready: ${file.name}")
                                        PdfDocumentGenerator.sharePdfFile(context, file, "Kolabhoomi Certificate - ${res.studentName}")
                                    }
                                    .onFailure { err -> onNotify("PDF Error: ${err.message}") }
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun PdfExportActionBar(
    label: String,
    tag: String,
    onExportOnly: () -> Unit,
    onExportAndShare: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = onExportOnly,
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag(tag),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy, contentColor = PureWhite)
        ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        OutlinedButton(
            onClick = onExportAndShare,
            modifier = Modifier.height(50.dp),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.2.dp, InstitutionalGold)
        ) {
            Icon(Icons.Default.Share, contentDescription = "Share PDF", tint = DeepNavy)
        }
    }
}

@Composable
private fun MarksheetPreviewCard(academyInfo: AcademyInfo, result: ExamResult) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(2.dp, DeepNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("marksheet_document_preview")
    ) {
        Column(modifier = Modifier.padding(2.dp).border(1.dp, InstitutionalGold, RoundedCornerShape(14.dp))) {
            // Institutional Letterhead
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp))
                    .background(DeepNavy)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 50.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = academyInfo.name,
                        fontFamily = PlayfairDisplayFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = PureWhite
                    )
                    Text("STATEMENT OF MARKS • OFFICIAL TRANSCRIPT", style = MaterialTheme.typography.labelSmall, color = RichGold)
                    Text("${result.examTitle} (${result.session})", style = MaterialTheme.typography.labelSmall, color = RoyalBlueSoft)
                }
            }

            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Scholar Info Strip
                Surface(color = SurfaceMuted, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Candidate: ${result.studentName}", style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                            Text(result.studentId, style = MaterialTheme.typography.labelMedium, color = RoyalBlue)
                        }
                        Text("Discipline: ${result.courseName}  •  Branch: ${result.branchName}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                }

                // Marks Table
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CardOutline, RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RoyalBlue)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text("Component", style = MaterialTheme.typography.labelMedium, color = PureWhite, modifier = Modifier.weight(1.8f))
                        Text("Max", style = MaterialTheme.typography.labelMedium, color = PureWhite, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        Text("Obt", style = MaterialTheme.typography.labelMedium, color = PureWhite, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                    }
                    val rows = listOf(
                        Triple("Theory & Aesthetics", result.maxTheory, result.theoryMarks),
                        Triple("Practical / Studio Craft", result.maxPractical, result.practicalMarks),
                        Triple("Capstone Project", result.maxProject, result.projectMarks),
                        Triple("Teamwork & Discipline", result.maxTeamwork, result.teamworkMarks)
                    )
                    rows.forEachIndexed { idx, (label, maxM, obt) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) PureWhite else SurfaceMuted.copy(alpha = 0.5f))
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text(label, style = MaterialTheme.typography.bodySmall, color = InkPrimary, modifier = Modifier.weight(1.8f))
                            Text(maxM.toString(), style = MaterialTheme.typography.bodySmall, color = InkMuted, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                            Text(obt.toString(), style = MaterialTheme.typography.labelLarge, color = DeepNavy, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        }
                        HorizontalDivider(color = CardOutline.copy(alpha = 0.6f))
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GoldContainer)
                            .padding(horizontal = 10.dp, vertical = 9.dp)
                    ) {
                        Text("GRAND TOTAL", style = MaterialTheme.typography.labelLarge, color = DeepNavy, modifier = Modifier.weight(1.8f))
                        Text(result.totalMax.toString(), style = MaterialTheme.typography.labelLarge, color = DeepNavy, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        Text(result.totalObtained.toString(), style = MaterialTheme.typography.labelLarge, color = DeepNavy, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                    }
                }

                // Result Summary + QR + Gold Seal
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatusPill(
                            text = "${String.format(Locale.US, "%.1f", result.percentage)}% • ${result.grade}",
                            containerColor = EmeraldSoft,
                            contentColor = EmeraldSuccess
                        )
                        Text("Remarks: ${result.remarks}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Text("Issued: ${result.issuedDate}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    QrVerificationCanvas(
                        payload = "https://verify.kolabhoomi.edu/marksheet/${result.certificateId ?: result.id}",
                        size = 66.dp
                    )
                }

                HorizontalDivider(color = CardOutline)

                // Digital Signature Fields + Embossed Seal
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    SignatureFieldBlock(academyInfo.controllerName, "Controller of Exams", Modifier.weight(1f))
                    Image(
                        painter = painterResource(id = R.drawable.img_certificate_seal_1795593430154),
                        contentDescription = "Official Gold Academy Seal",
                        modifier = Modifier.size(52.dp),
                        contentScale = ContentScale.Fit
                    )
                    SignatureFieldBlock(academyInfo.principalName, "Principal", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PaymentReceiptPreviewCard(academyInfo: AcademyInfo, fee: FeeRecord, branchName: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(2.dp, DeepNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("receipt_document_preview")
    ) {
        Column(modifier = Modifier.padding(2.dp).border(1.dp, InstitutionalGold, RoundedCornerShape(14.dp))) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp))
                    .background(DeepNavy)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 48.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(academyInfo.name, fontFamily = PlayfairDisplayFamily, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PureWhite)
                    Text("OFFICIAL FEE PAYMENT RECEIPT", style = MaterialTheme.typography.labelSmall, color = RichGold)
                    Text("Reg: ${academyInfo.registrationNo}", style = MaterialTheme.typography.labelSmall, color = RoyalBlueSoft)
                }
            }

            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(color = GoldContainer, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, GoldBorder), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("RECEIPT NO.", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                            Text(fee.receiptNo, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("DATE: ${fee.paymentDate}", style = MaterialTheme.typography.labelSmall, color = InkSecondary)
                            StatusPill(
                                text = fee.status.label.uppercase(),
                                containerColor = if (fee.status == FeeStatus.PAID) EmeraldSoft else RoyalBlueSoft,
                                contentColor = if (fee.status == FeeStatus.PAID) EmeraldSuccess else DeepNavy
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Scholar: ${fee.studentName} (${fee.studentId})", style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                    Text("Campus Wing: $branchName", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    Text("Courses: ${fee.courseName}  •  Mode: ${fee.paymentMode}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                }

                // Itemized Table
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CardOutline, RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RoyalBlue)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Description", style = MaterialTheme.typography.labelMedium, color = PureWhite)
                        Text("Amount", style = MaterialTheme.typography.labelMedium, color = PureWhite)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${fee.feeType.label} (${fee.billingMonth})", style = MaterialTheme.typography.bodySmall, color = InkPrimary)
                        Text(formatCurrencyInr(fee.amount), style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                    }
                    HorizontalDivider(color = CardOutline)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceMuted)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Settled: ${formatCurrencyInr(fee.paidAmount)}", style = MaterialTheme.typography.labelLarge, color = EmeraldSuccess)
                        Text("Due: ${formatCurrencyInr(fee.balanceDue)}", style = MaterialTheme.typography.labelLarge, color = DeepNavy)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QrVerificationCanvas(
                            payload = "KAA-RECEIPT|${fee.receiptNo}|${fee.studentId}|${fee.paidAmount.toInt()}",
                            size = 64.dp
                        )
                        Column {
                            Text("Digital Ledger Seal", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                            Text("Scan QR to verify\nreceipt authenticity", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                        }
                    }
                    SignatureFieldBlock(academyInfo.directorName, "Authorized Signatory")
                }
            }
        }
    }
}

@Composable
private fun QrCertificatePreviewCard(academyInfo: AcademyInfo, result: ExamResult) {
    val certId = result.certificateId ?: "KAA-CERT-2026-9001"
    val verifyPayload = "https://verify.kolabhoomi.edu/cert/$certId|${result.studentId}|${result.shortGrade}"

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDF8)),
        border = BorderStroke(3.dp, DeepNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("certificate_document_preview")
    ) {
        Column(
            modifier = Modifier
                .padding(6.dp)
                .border(1.5.dp, InstitutionalGold, RoundedCornerShape(12.dp))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AcademyLogoBadge(logoUri = academyInfo.logoUri, size = 56.dp, borderWidth = 2.dp)

            Text(
                text = academyInfo.name,
                fontFamily = PlayfairDisplayFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = DeepNavy,
                textAlign = TextAlign.Center
            )
            Text(
                text = "REGD. ART & MUSIC CONSERVATORY • ${academyInfo.registrationNo}",
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalGold,
                textAlign = TextAlign.Center
            )

            HorizontalDivider(modifier = Modifier.fillMaxWidth(0.5f), color = InstitutionalGold)

            Text(
                text = "CERTIFICATE OF EXCELLENCE",
                fontFamily = PlayfairDisplayFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 21.sp,
                color = RoyalBlue,
                textAlign = TextAlign.Center
            )

            Text("This is proudly conferred upon", style = MaterialTheme.typography.bodySmall, color = InkSecondary)

            Text(
                text = result.studentName,
                fontFamily = PlayfairDisplayFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 25.sp,
                color = DeepNavy,
                textAlign = TextAlign.Center
            )
            HorizontalDivider(modifier = Modifier.fillMaxWidth(0.65f), color = GoldBorder)

            Text(
                text = "for completing ${result.examTitle} in ${result.courseName} (${result.branchName}) with Grade ${result.grade} (${String.format(Locale.US, "%.1f", result.percentage)}%).",
                style = MaterialTheme.typography.bodySmall,
                color = InkPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Official Medallion Seal + QR Code Verification Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.img_certificate_seal_1795593430154),
                        contentDescription = "Gold Academic Honor Seal",
                        modifier = Modifier.size(74.dp),
                        contentScale = ContentScale.Fit
                    )
                    Text("Official Gold Seal", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    QrVerificationCanvas(payload = verifyPayload, size = 82.dp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(13.dp))
                        Text("QR VERIFIED", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = DeepNavy)
                    }
                    Text(certId, style = MaterialTheme.typography.labelSmall, color = InkMuted)
                }
            }

            HorizontalDivider(color = CardOutline)

            // Dual Digital Signature Fields
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SignatureFieldBlock(academyInfo.principalName, "Principal", Modifier.weight(1f))
                SignatureFieldBlock(academyInfo.directorName, "Director & Founder", Modifier.weight(1f))
            }
        }
    }
}

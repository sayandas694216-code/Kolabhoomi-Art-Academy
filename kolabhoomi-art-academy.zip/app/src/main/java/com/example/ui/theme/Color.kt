package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kolabhoomi Art Academy Institutional Palette
val DeepNavy = Color(0xFF0B1D3A)
val DeepNavyDark = Color(0xFF061124)
val RoyalBlue = Color(0xFF1B3B6F)
val RoyalBlueBright = Color(0xFF2553A1)
val RoyalBlueSoft = Color(0xFFE7EEF9)

val InstitutionalGold = Color(0xFFC8A24A)
val RichGold = Color(0xFFD4AF37)
val GoldContainer = Color(0xFFFBF4DF)
val GoldBorder = Color(0xFFE2C982)

val PureWhite = Color(0xFFFFFFFF)
val AlabasterCanvas = Color(0xFFF5F7FB)
val SurfaceMuted = Color(0xFFEDF1F8)
val CardOutline = Color(0xFFDDE4F0)

val InkPrimary = Color(0xFF0F1B2E)
val InkSecondary = Color(0xFF4F5E78)
val InkMuted = Color(0xFF7B8AA3)

// Semantic Status & Chart Colors (Harmonized with Navy & Gold)
val EmeraldSuccess = Color(0xFF147A52)
val EmeraldSoft = Color(0xFFE3F5ED)
val AmberWarning = Color(0xFFC47D12)
val AmberSoft = Color(0xFFFEF3DF)
val CrimsonAlert = Color(0xFFB82D3B)
val CrimsonSoft = Color(0xFFFCE8EA)
val TealAccent = Color(0xFF1F6E7A)
val IndigoAccent = Color(0xFF3E4E88)
val BronzeAccent = Color(0xFF9C7638)
val SlateAccent = Color(0xFF5D7290)

// Dark theme tokens
val DarkCanvas = Color(0xFF071224)
val DarkSurface = Color(0xFF0E1E38)
val DarkSurfaceElevated = Color(0xFF162B4D)
val DarkOutline = Color(0xFF273E63)

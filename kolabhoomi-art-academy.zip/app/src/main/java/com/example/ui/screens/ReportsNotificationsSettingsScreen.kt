package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AcademyInfo
import com.example.data.model.NoticeCategory
import com.example.data.model.UserRole
import com.example.ui.components.AcademyLogoBadge
import com.example.ui.components.GoldAccentChip
import com.example.ui.components.NavyGradientBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.formatCurrencyInr
import com.example.ui.theme.AlabasterCanvas
import com.example.ui.theme.AmberSoft
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.viewmodel.AcademyUiState
import com.example.util.PdfDocumentGenerator

// =========================================================================
// 1. REPORTS HUB (Student, Financial, Attendance, Branch, Course PDFs)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Institutional Reports", style = MaterialTheme.typography.titleLarge)
                        Text("Downloadable PDF Summaries for All Modules", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ReportPdfCard(
                    title = "Student Enrollment Report",
                    summary = "${state.students.size} total scholars across ${state.branches.size} branches (${state.students.count { it.status.name == "ACTIVE" }} Active).",
                    metric = "${state.students.size} Records",
                    tag = "pdf_report_students",
                    onDownloadPdf = {
                        val rows = state.students.map {
                            listOf(it.id, it.fullName, state.branchName(it.branchId), state.courseNames(it.courseIds), it.status.label)
                        }
                        PdfDocumentGenerator.exportInstitutionalReportPdf(
                            context, state.academyInfo, "Student Enrollment Report",
                            "Session 2026–2027 • All Campus Wings",
                            listOf("Scholar ID", "Name", "Branch", "Courses", "Status"), rows
                        ).onSuccess {
                            onNotify("Exported Student Report PDF: ${it.name}")
                            PdfDocumentGenerator.sharePdfFile(context, it, "Kolabhoomi Student Report")
                        }.onFailure { onNotify("Export failed: ${it.message}") }
                    }
                )
            }
            item {
                ReportPdfCard(
                    title = "Financial & Revenue Report",
                    summary = "Gross Monthly Revenue ${formatCurrencyInr(state.totalMonthlyRevenue)} • Expenses ${formatCurrencyInr(state.totalMonthlyExpenses)} • Pending ${formatCurrencyInr(state.totalPendingFees)}.",
                    metric = formatCurrencyInr(state.totalMonthlyRevenue),
                    tag = "pdf_report_financial",
                    onDownloadPdf = {
                        val rows = state.feeRecords.map {
                            listOf(it.receiptNo, it.studentName, it.feeType.label, formatCurrencyInr(it.paidAmount), it.status.label)
                        }
                        PdfDocumentGenerator.exportInstitutionalReportPdf(
                            context, state.academyInfo, "Financial & Tuition Ledger",
                            "Collected: ${formatCurrencyInr(state.totalCollectedFees)} • Pending: ${formatCurrencyInr(state.totalPendingFees)}",
                            listOf("Receipt No", "Student", "Type", "Settled", "Status"), rows
                        ).onSuccess {
                            onNotify("Exported Financial Report PDF: ${it.name}")
                            PdfDocumentGenerator.sharePdfFile(context, it, "Kolabhoomi Financial Report")
                        }.onFailure { onNotify("Export failed: ${it.message}") }
                    }
                )
            }
            item {
                ReportPdfCard(
                    title = "Attendance Compliance Report",
                    summary = "Branch-wise Present, Absent & Leave analytics across ${state.attendanceRecords.size} logged sessions.",
                    metric = "${state.attendanceRecords.size} Logs",
                    tag = "pdf_report_attendance",
                    onDownloadPdf = {
                        val stats = state.branchAttendanceStats()
                        val rows = stats.map {
                            listOf(it.branchCode, it.branchName, "${it.presentPercent.toInt()}%", "${it.leavePercent.toInt()}%", "${it.absentPercent.toInt()}%")
                        }
                        PdfDocumentGenerator.exportInstitutionalReportPdf(
                            context, state.academyInfo, "Branch Attendance Report",
                            "November 2026 Institutional Compliance",
                            listOf("Code", "Branch", "Present", "Leave", "Absent"), rows
                        ).onSuccess {
                            onNotify("Exported Attendance Report PDF: ${it.name}")
                            PdfDocumentGenerator.sharePdfFile(context, it, "Kolabhoomi Attendance Report")
                        }.onFailure { onNotify("Export failed: ${it.message}") }
                    }
                )
            }
            item {
                ReportPdfCard(
                    title = "Branch Performance Report",
                    summary = "Operational comparison across ${state.branches.size} wings: coordinators, faculty strength, and student capacity.",
                    metric = "${state.branches.size} Wings",
                    tag = "pdf_report_branches",
                    onDownloadPdf = {
                        val rows = state.branches.map { br ->
                            val stCount = state.students.count { it.branchId == br.id }
                            val tCount = state.teachers.count { br.id in it.branchIds }
                            listOf(br.code, br.name, br.coordinatorName, "$stCount", "$tCount")
                        }
                        PdfDocumentGenerator.exportInstitutionalReportPdf(
                            context, state.academyInfo, "Branch Operations Report",
                            "Multi-Wing Institutional Summary",
                            listOf("Code", "Branch Name", "Coordinator", "Students", "Faculty"), rows
                        ).onSuccess {
                            onNotify("Exported Branch Report PDF: ${it.name}")
                            PdfDocumentGenerator.sharePdfFile(context, it, "Kolabhoomi Branch Report")
                        }.onFailure { onNotify("Export failed: ${it.message}") }
                    }
                )
            }
            item {
                ReportPdfCard(
                    title = "Course Enrollment & Fee Report",
                    summary = "Distribution across Drawing, Guitar, Handicrafts, Dance, Vocal Music, Tabla, Instruments & Photography.",
                    metric = "${state.courses.size} Courses",
                    tag = "pdf_report_courses",
                    onDownloadPdf = {
                        val rows = state.courses.map { c ->
                            val cnt = state.students.count { c.id in it.courseIds }
                            listOf(c.name, c.category, formatCurrencyInr(c.monthlyFee), "$cnt Scholars")
                        }
                        PdfDocumentGenerator.exportInstitutionalReportPdf(
                            context, state.academyInfo, "Course Enrollment & Tariff Report",
                            "Complete Curriculum Overview",
                            listOf("Course", "Category", "Monthly Fee", "Enrollment"), rows
                        ).onSuccess {
                            onNotify("Exported Course Report PDF: ${it.name}")
                            PdfDocumentGenerator.sharePdfFile(context, it, "Kolabhoomi Course Report")
                        }.onFailure { onNotify("Export failed: ${it.message}") }
                    }
                )
            }
        }
    }
}

@Composable
private fun ReportPdfCard(
    title: String,
    summary: String,
    metric: String,
    tag: String,
    onDownloadPdf: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = DeepNavy, modifier = Modifier.weight(1f))
                GoldAccentChip(metric)
            }
            Text(summary, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
            Button(
                onClick = onDownloadPdf,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy, contentColor = PureWhite),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(tag)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Download Official PDF Report")
            }
        }
    }
}

// =========================================================================
// 2. NOTIFICATIONS CENTER
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NotificationsScreen(
    state: AcademyUiState,
    onBack: () -> Unit,
    onMarkAllRead: () -> Unit,
    onPublishNotice: (String, String, NoticeCategory, String) -> Unit
) {
    val canCompose = state.currentUser?.role != UserRole.STUDENT
    var showComposeDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AlabasterCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Notifications & Notices", style = MaterialTheme.typography.titleLarge)
                        Text("${state.unreadNoticeCount} Unread Announcements", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DeepNavy)
                    }
                },
                actions = {
                    TextButton(onClick = onMarkAllRead) {
                        Icon(Icons.Default.DoneAll, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Read All", color = RoyalBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        floatingActionButton = {
            if (canCompose) {
                FloatingActionButton(
                    onClick = { showComposeDialog = true },
                    containerColor = DeepNavy,
                    contentColor = PureWhite,
                    modifier = Modifier.testTag("compose_notice_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Publish Notice")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.notices, key = { it.id }) { notice ->
                val (bg, fg) = when (notice.category) {
                    NoticeCategory.FEE_REMINDER -> AmberSoft to AmberWarning
                    NoticeCategory.ATTENDANCE -> RoyalBlueSoft to RoyalBlue
                    NoticeCategory.EXAM -> RoyalBlueSoft to DeepNavy
                    NoticeCategory.ADMISSION -> EmeraldSoft to EmeraldSuccess
                    NoticeCategory.GENERAL -> RoyalBlueSoft to DeepNavy
                }
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(if (!notice.isRead) 1.5.dp else 1.dp, if (!notice.isRead) InstitutionalGold else CardOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(notice.category.label, bg, fg)
                            Text("${notice.date} • ${notice.targetAudience}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                        }
                        Text(notice.title, style = MaterialTheme.typography.titleMedium, color = DeepNavy)
                        Text(notice.body, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                }
            }
        }
    }

    if (showComposeDialog) {
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        var category by remember { mutableStateOf(NoticeCategory.GENERAL) }
        var audience by remember { mutableStateOf("All Members") }

        AlertDialog(
            onDismissRequest = { showComposeDialog = false },
            title = { Text("Publish Institutional Notice", color = DeepNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Notice Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Message Body *") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Text("Category", style = MaterialTheme.typography.labelMedium, color = DeepNavy)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NoticeCategory.entries.forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.label) })
                        }
                    }
                    OutlinedTextField(value = audience, onValueChange = { audience = it }, label = { Text("Target Audience") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank() && body.isNotBlank()) {
                            onPublishNotice(title.trim(), body.trim(), category, audience.trim())
                            showComposeDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Broadcast Notice") }
            },
            dismissButton = { TextButton(onClick = { showComposeDialog = false }) { Text("Cancel") } }
        )
    }
}

// =========================================================================
// 3. PROFILE & ACADEMY SETTINGS
// =========================================================================
@Composable
fun ProfileAndSettingsScreen(
    state: AcademyUiState,
    onNavigateRoute: (String) -> Unit,
    onUpdateAcademyInfo: (AcademyInfo) -> Unit,
    onUpdateLogoUri: (String?) -> Unit,
    onToggleAccountActive: (String) -> Unit,
    onChangePassword: (String, String) -> Result<String>,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val user = state.currentUser
    val isAdmin = user?.role == UserRole.SUPER_ADMIN

    var showChangePassword by remember { mutableStateOf(false) }
    var showAcademyInfoDialog by remember { mutableStateOf(false) }
    var showUserManagementDialog by remember { mutableStateOf(false) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onUpdateLogoUri(uri.toString())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AlabasterCanvas)
            .testTag("profile_settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            NavyGradientBanner {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AcademyLogoBadge(logoUri = state.academyInfo.logoUri, size = 62.dp, borderWidth = 2.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(user?.role?.badgeLabel?.uppercase() ?: "PORTAL USER", style = MaterialTheme.typography.labelSmall, color = RichGold)
                        Text(user?.fullName ?: "Kolabhoomi Member", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                        Text("${user?.userId ?: ""} • ${user?.email ?: ""}", style = MaterialTheme.typography.bodySmall, color = RoyalBlueSoft)
                    }
                }
            }
        }

        // Quick Module Shortcuts from Profile
        item {
            SectionHeader(title = "Documents & Communications")
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Default.Description,
                        title = "Official Document Studio",
                        subtitle = "Marksheets, Payment Receipts & QR Certificates (PDF)",
                        onClick = { onNavigateRoute("documents") }
                    )
                    HorizontalDivider(color = CardOutline)
                    SettingsRowItem(
                        icon = Icons.Default.PictureAsPdf,
                        title = "Institutional Reports",
                        subtitle = "Export Student, Financial, Attendance & Branch PDFs",
                        onClick = { onNavigateRoute("reports") }
                    )
                }
            }
        }

        // Super Admin Academy Configuration
        if (isAdmin) {
            item {
                SectionHeader(title = "Academy Administration & Settings")
            }
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, CardOutline)
                ) {
                    Column {
                        SettingsRowItem(
                            icon = Icons.Default.Business,
                            title = "Academy Information",
                            subtitle = "${state.academyInfo.name} • ${state.academyInfo.registrationNo}",
                            onClick = { showAcademyInfoDialog = true }
                        )
                        HorizontalDivider(color = CardOutline)
                        SettingsRowItem(
                            icon = Icons.Default.PhotoLibrary,
                            title = "Academy Logo Management",
                            subtitle = "Upload custom institutional emblem via Photo Picker",
                            onClick = {
                                logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        )
                        HorizontalDivider(color = CardOutline)
                        SettingsRowItem(
                            icon = Icons.Default.Apartment,
                            title = "Branch Settings",
                            subtitle = "Manage ${state.branches.size} wings, timings & coordinators",
                            onClick = { onNavigateRoute("branches") }
                        )
                        HorizontalDivider(color = CardOutline)
                        SettingsRowItem(
                            icon = Icons.Default.ManageAccounts,
                            title = "User & Role Management",
                            subtitle = "${state.accounts.size} registered Admin, Teacher & Student IDs",
                            onClick = { showUserManagementDialog = true }
                        )
                        HorizontalDivider(color = CardOutline)
                        SettingsRowItem(
                            icon = Icons.Default.Backup,
                            title = "Backup Academy Data (JSON)",
                            subtitle = "Export Supabase-ready institutional snapshot locally",
                            onClick = onBackup
                        )
                        HorizontalDivider(color = CardOutline)
                        SettingsRowItem(
                            icon = Icons.Default.Restore,
                            title = "Restore Latest Snapshot",
                            subtitle = "Verify and restore saved local academy backup",
                            onClick = onRestore
                        )
                    }
                }
            }
        }

        // Security & Session
        item {
            SectionHeader(title = "Account Security")
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Default.LockReset,
                        title = "Change Password",
                        subtitle = "Update your Academy Portal login password",
                        onClick = { showChangePassword = true }
                    )
                    HorizontalDivider(color = CardOutline)
                    SettingsRowItem(
                        icon = Icons.AutoMirrored.Filled.ExitToApp,
                        title = "Sign Out / Switch Portal Role",
                        subtitle = "Return to Welcome & Login screen",
                        tint = CrimsonAlert,
                        onClick = onLogout
                    )
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showChangePassword) {
        ChangePasswordDialog(
            onDismiss = { showChangePassword = false },
            onChangePassword = onChangePassword
        )
    }

    if (showAcademyInfoDialog) {
        var name by remember { mutableStateOf(state.academyInfo.name) }
        var reg by remember { mutableStateOf(state.academyInfo.registrationNo) }
        var addr by remember { mutableStateOf(state.academyInfo.address) }
        var phone by remember { mutableStateOf(state.academyInfo.phone) }
        var principal by remember { mutableStateOf(state.academyInfo.principalName) }
        var director by remember { mutableStateOf(state.academyInfo.directorName) }

        AlertDialog(
            onDismissRequest = { showAcademyInfoDialog = false },
            title = { Text("Academy Profile & Signatories", color = DeepNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Institution Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = reg, onValueChange = { reg = it }, label = { Text("Registration No.") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = addr, onValueChange = { addr = it }, label = { Text("Headquarters Address") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Official Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = principal, onValueChange = { principal = it }, label = { Text("Principal (Digital Signature)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = director, onValueChange = { director = it }, label = { Text("Director (Digital Signature)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateAcademyInfo(
                            state.academyInfo.copy(
                                name = name.trim(),
                                registrationNo = reg.trim(),
                                address = addr.trim(),
                                phone = phone.trim(),
                                principalName = principal.trim(),
                                directorName = director.trim()
                            )
                        )
                        showAcademyInfoDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                ) { Text("Save Details") }
            },
            dismissButton = { TextButton(onClick = { showAcademyInfoDialog = false }) { Text("Cancel") } }
        )
    }

    if (showUserManagementDialog) {
        AlertDialog(
            onDismissRequest = { showUserManagementDialog = false },
            title = { Text("Portal User Accounts", color = DeepNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    state.accounts.forEach { acc ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(acc.fullName, style = MaterialTheme.typography.titleSmall, color = DeepNavy)
                                Text("${acc.userId} • ${acc.role.displayName}", style = MaterialTheme.typography.labelSmall, color = InkMuted)
                            }
                            Switch(
                                checked = acc.isActive,
                                enabled = acc.role != UserRole.SUPER_ADMIN,
                                onCheckedChange = { onToggleAccountActive(acc.userId) }
                            )
                        }
                        HorizontalDivider(color = CardOutline.copy(alpha = 0.6f))
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showUserManagementDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: androidx.compose.ui.graphics.Color = DeepNavy,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(22.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = tint)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
        }
    }
}

package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import com.example.data.model.AcademyInfo
import com.example.data.model.AcademyNotice
import com.example.data.model.ActivityLog
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.Branch
import com.example.data.model.BranchAttendanceStat
import com.example.data.model.Course
import com.example.data.model.CourseEnrollmentSlice
import com.example.data.model.ExamResult
import com.example.data.model.Examination
import com.example.data.model.ExpenseRecord
import com.example.data.model.FeeRecord
import com.example.data.model.FeeStatus
import com.example.data.model.FeeType
import com.example.data.model.MonthlyRevenuePoint
import com.example.data.model.NoticeCategory
import com.example.data.model.SalaryRecord
import com.example.data.model.Student
import com.example.data.model.StudentStatus
import com.example.data.model.Teacher
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.AcademyDataSource
import com.example.data.repository.AcademySnapshot
import com.example.data.repository.LocalAcademyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

data class AcademyUiState(
    val currentUser: UserAccount? = null,
    val academyInfo: AcademyInfo = AcademyInfo(),
    val accounts: List<UserAccount> = emptyList(),
    val branches: List<Branch> = emptyList(),
    val courses: List<Course> = emptyList(),
    val teachers: List<Teacher> = emptyList(),
    val students: List<Student> = emptyList(),
    val attendanceRecords: List<AttendanceRecord> = emptyList(),
    val feeRecords: List<FeeRecord> = emptyList(),
    val expenses: List<ExpenseRecord> = emptyList(),
    val examinations: List<Examination> = emptyList(),
    val examResults: List<ExamResult> = emptyList(),
    val notices: List<AcademyNotice> = emptyList(),
    val activities: List<ActivityLog> = emptyList(),
    val monthlyRevenueHistory: List<MonthlyRevenuePoint> = emptyList(),
    val statusMessage: String? = null
) {
    val unreadNoticeCount: Int get() = notices.count { !it.isRead }
    val totalMonthlyRevenue: Double get() = monthlyRevenueHistory.lastOrNull()?.revenue ?: feeRecords.sumOf { it.paidAmount }
    val totalCollectedFees: Double get() = feeRecords.sumOf { it.paidAmount }
    val totalPendingFees: Double get() = feeRecords.sumOf { it.balanceDue }
    val totalMonthlyExpenses: Double get() = expenses.sumOf { it.amount }

    fun branchName(branchId: String): String =
        branches.find { it.id == branchId }?.name ?: "Main Campus"

    fun courseNames(courseIds: List<String>): String =
        courseIds.mapNotNull { cid -> courses.find { it.id == cid }?.name }.joinToString(", ").ifBlank { "Unassigned" }

    fun studentAttendancePercent(studentId: String): Int {
        val recs = attendanceRecords.filter { !it.isTeacher && it.personId == studentId }
        if (recs.isEmpty()) return 92
        val present = recs.count { it.status == AttendanceStatus.PRESENT }
        return ((present * 100.0) / recs.size).toInt()
    }

    fun branchAttendanceStats(): List<BranchAttendanceStat> {
        return branches.map { branch ->
            val recs = attendanceRecords.filter { !it.isTeacher && it.branchId == branch.id }
            val total = recs.size
            if (total == 0) {
                BranchAttendanceStat(branch.id, branch.code, branch.name, 88f, 6f, 6f, 0)
            } else {
                val p = recs.count { it.status == AttendanceStatus.PRESENT } * 100f / total
                val a = recs.count { it.status == AttendanceStatus.ABSENT } * 100f / total
                val l = recs.count { it.status == AttendanceStatus.LEAVE } * 100f / total
                BranchAttendanceStat(branch.id, branch.code, branch.name, p, a, l, total)
            }
        }
    }

    fun courseEnrollmentDistribution(): List<CourseEnrollmentSlice> {
        return courses.map { course ->
            val enrolled = students.count { course.id in it.courseIds }
            CourseEnrollmentSlice(
                courseId = course.id,
                courseName = course.name,
                studentCount = enrolled,
                monthlyRevenuePotential = enrolled * course.monthlyFee
            )
        }.sortedByDescending { it.studentCount }
    }

    fun currentStudent(): Student? {
        val linkedId = currentUser?.linkedEntityId ?: return null
        return students.find { it.id == linkedId } ?: students.firstOrNull()
    }

    fun currentTeacher(): Teacher? {
        val linkedId = currentUser?.linkedEntityId ?: return null
        return teachers.find { it.id == linkedId } ?: teachers.firstOrNull()
    }
}

class AcademyViewModel(
    private val repository: AcademyDataSource = LocalAcademyRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(loadInitialUiState())
    val uiState: StateFlow<AcademyUiState> = _uiState.asStateFlow()

    private fun loadInitialUiState(): AcademyUiState {
        val snap = repository.loadInitialSnapshot()
        return AcademyUiState(
            academyInfo = snap.academyInfo,
            accounts = snap.accounts,
            branches = snap.branches,
            courses = snap.courses,
            teachers = snap.teachers,
            students = snap.students,
            attendanceRecords = snap.attendanceRecords,
            feeRecords = snap.feeRecords,
            expenses = snap.expenses,
            examinations = snap.examinations,
            examResults = snap.examResults,
            notices = snap.notices,
            activities = snap.activities,
            monthlyRevenueHistory = snap.monthlyRevenueHistory
        )
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun postMessage(msg: String) {
        _uiState.update { it.copy(statusMessage = msg) }
    }

    // --- AUTHENTICATION ---

    fun login(userId: String, password: String): Result<UserAccount> {
        val cleanId = userId.trim().uppercase(Locale.US)
        val account = _uiState.value.accounts.find {
            it.userId.equals(cleanId, ignoreCase = true) && it.password == password && it.isActive
        }
        return if (account != null) {
            _uiState.update { it.copy(currentUser = account, statusMessage = "Welcome back, ${account.fullName}") }
            Result.success(account)
        } else {
            Result.failure(IllegalArgumentException("Invalid Academy ID or Password. Check credentials or use quick demo login."))
        }
    }

    fun logout() {
        _uiState.update { it.copy(currentUser = null, statusMessage = "Signed out securely.") }
    }

    fun changePassword(currentPassword: String, newPassword: String): Result<String> {
        val user = _uiState.value.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        if (user.password != currentPassword) {
            return Result.failure(IllegalArgumentException("Current password does not match."))
        }
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }
        _uiState.update { state ->
            val updatedAccounts = state.accounts.map {
                if (it.userId == user.userId) it.copy(password = newPassword) else it
            }
            state.copy(
                accounts = updatedAccounts,
                currentUser = user.copy(password = newPassword),
                statusMessage = "Password updated successfully."
            )
        }
        return Result.success("Password updated successfully.")
    }

    fun requestPasswordReset(userId: String): Result<String> {
        val account = _uiState.value.accounts.find { it.userId.equals(userId.trim(), ignoreCase = true) }
            ?: return Result.failure(IllegalArgumentException("No Academy account found for ID '$userId'."))
        _uiState.update {
            it.copy(statusMessage = "Password reset link dispatched to ${account.email}")
        }
        return Result.success("Reset instructions sent to ${account.email}")
    }

    // --- STUDENT MANAGEMENT ---

    fun generateNextStudentId(): String {
        val nextNum = _uiState.value.students.size + 1
        return String.format(Locale.US, "KAA-STU-2026-%03d", nextNum)
    }

    fun addOrUpdateStudent(student: Student, isEdit: Boolean) {
        _uiState.update { state ->
            val updatedList = if (isEdit) {
                state.students.map { if (it.id == student.id) student else it }
            } else {
                listOf(student) + state.students
            }
            val updatedAccounts = if (!isEdit && state.accounts.none { it.userId == student.id }) {
                state.accounts + UserAccount(
                    userId = student.id,
                    password = "student123",
                    role = UserRole.STUDENT,
                    fullName = student.fullName,
                    email = student.email,
                    phone = student.phone,
                    linkedEntityId = student.id
                )
            } else state.accounts

            val activity = ActivityLog(
                id = "ACT-${System.currentTimeMillis()}",
                title = if (isEdit) "Student Profile Updated" else "New Admission Enrolled",
                subtitle = "${student.fullName} (${student.id}) • ${state.branchName(student.branchId)}",
                timestamp = "Just now",
                category = "Admission"
            )
            state.copy(
                students = updatedList,
                accounts = updatedAccounts,
                activities = listOf(activity) + state.activities,
                statusMessage = if (isEdit) "Updated ${student.fullName}" else "Enrolled ${student.fullName} (${student.id})"
            )
        }
    }

    fun deleteStudent(studentId: String) {
        _uiState.update { state ->
            val target = state.students.find { it.id == studentId }
            state.copy(
                students = state.students.filterNot { it.id == studentId },
                statusMessage = "Removed student record ${target?.fullName ?: studentId}"
            )
        }
    }

    // --- BRANCH MANAGEMENT (Unlimited manual branches) ---

    fun addOrUpdateBranch(branch: Branch, isEdit: Boolean) {
        _uiState.update { state ->
            val updated = if (isEdit) {
                state.branches.map { if (it.id == branch.id) branch else it }
            } else {
                state.branches + branch
            }
            val activity = ActivityLog(
                id = "ACT-${System.currentTimeMillis()}",
                title = if (isEdit) "Branch Updated" else "New Branch Established",
                subtitle = "${branch.name} (${branch.code}) • Coordinator: ${branch.coordinatorName}",
                timestamp = "Just now",
                category = "Branch"
            )
            state.copy(
                branches = updated,
                activities = listOf(activity) + state.activities,
                statusMessage = if (isEdit) "Branch '${branch.name}' updated" else "Branch '${branch.name}' created"
            )
        }
    }

    fun deleteBranch(branchId: String) {
        _uiState.update { state ->
            state.copy(
                branches = state.branches.filterNot { it.id == branchId },
                statusMessage = "Branch deleted."
            )
        }
    }

    // --- COURSE MANAGEMENT ---

    fun addOrUpdateCourse(course: Course, isEdit: Boolean) {
        _uiState.update { state ->
            val updated = if (isEdit) {
                state.courses.map { if (it.id == course.id) course else it }
            } else {
                state.courses + course
            }
            state.copy(
                courses = updated,
                statusMessage = if (isEdit) "Course '${course.name}' updated" else "Course '${course.name}' added"
            )
        }
    }

    fun deleteCourse(courseId: String) {
        _uiState.update { state ->
            state.copy(
                courses = state.courses.filterNot { it.id == courseId },
                statusMessage = "Course removed."
            )
        }
    }

    // --- TEACHER MANAGEMENT ---

    fun generateNextTeacherId(): String {
        val nextNum = 101 + _uiState.value.teachers.size
        return "KAA-TCH-$nextNum"
    }

    fun addOrUpdateTeacher(teacher: Teacher, isEdit: Boolean) {
        _uiState.update { state ->
            val updated = if (isEdit) {
                state.teachers.map { if (it.id == teacher.id) teacher else it }
            } else {
                listOf(teacher) + state.teachers
            }
            val updatedAccounts = if (!isEdit && state.accounts.none { it.userId == teacher.id }) {
                state.accounts + UserAccount(
                    userId = teacher.id,
                    password = "teach123",
                    role = UserRole.TEACHER,
                    fullName = teacher.fullName,
                    email = teacher.email,
                    phone = teacher.phone,
                    linkedEntityId = teacher.id
                )
            } else state.accounts
            state.copy(
                teachers = updated,
                accounts = updatedAccounts,
                statusMessage = if (isEdit) "Faculty profile updated" else "Added ${teacher.fullName} (${teacher.id})"
            )
        }
    }

    fun recordTeacherSalaryPaid(teacherId: String, monthLabel: String) {
        _uiState.update { state ->
            val updated = state.teachers.map { t ->
                if (t.id == teacherId) {
                    val newRec = SalaryRecord(
                        id = "SAL-${System.currentTimeMillis()}",
                        month = monthLabel,
                        amount = t.monthlySalary,
                        status = "Paid",
                        paidDate = "2026-11-24"
                    )
                    t.copy(salaryRecords = listOf(newRec) + t.salaryRecords)
                } else t
            }
            state.copy(teachers = updated, statusMessage = "Salary payout recorded for $monthLabel")
        }
    }

    // --- ATTENDANCE MANAGEMENT ---

    fun markAttendance(
        date: String,
        personId: String,
        personName: String,
        isTeacher: Boolean,
        branchId: String,
        courseName: String,
        status: AttendanceStatus
    ) {
        _uiState.update { state ->
            val existingIdx = state.attendanceRecords.indexOfFirst {
                it.date == date && it.personId == personId && it.isTeacher == isTeacher
            }
            val newRec = AttendanceRecord(
                id = if (existingIdx >= 0) state.attendanceRecords[existingIdx].id else "ATT-${System.currentTimeMillis()}",
                date = date,
                personId = personId,
                personName = personName,
                isTeacher = isTeacher,
                branchId = branchId,
                courseName = courseName,
                status = status
            )
            val updated = if (existingIdx >= 0) {
                state.attendanceRecords.toMutableList().apply { set(existingIdx, newRec) }
            } else {
                listOf(newRec) + state.attendanceRecords
            }
            state.copy(attendanceRecords = updated)
        }
    }

    fun markAllPresentForBranch(date: String, branchId: String?, isTeacher: Boolean) {
        _uiState.update { state ->
            val mutable = state.attendanceRecords.toMutableList()
            if (!isTeacher) {
                val list = state.students.filter { branchId == null || it.branchId == branchId }
                list.forEach { s ->
                    val idx = mutable.indexOfFirst { it.date == date && it.personId == s.id && !it.isTeacher }
                    val rec = AttendanceRecord(
                        id = if (idx >= 0) mutable[idx].id else "ATT-${s.id}-$date",
                        date = date,
                        personId = s.id,
                        personName = s.fullName,
                        isTeacher = false,
                        branchId = s.branchId,
                        courseName = state.courseNames(s.courseIds),
                        status = AttendanceStatus.PRESENT
                    )
                    if (idx >= 0) mutable[idx] = rec else mutable.add(0, rec)
                }
            } else {
                val list = state.teachers.filter { branchId == null || branchId in it.branchIds }
                list.forEach { t ->
                    val idx = mutable.indexOfFirst { it.date == date && it.personId == t.id && it.isTeacher }
                    val rec = AttendanceRecord(
                        id = if (idx >= 0) mutable[idx].id else "ATT-${t.id}-$date",
                        date = date,
                        personId = t.id,
                        personName = t.fullName,
                        isTeacher = true,
                        branchId = t.branchIds.firstOrNull() ?: "BR-01",
                        courseName = t.specialization,
                        status = AttendanceStatus.PRESENT
                    )
                    if (idx >= 0) mutable[idx] = rec else mutable.add(0, rec)
                }
            }
            state.copy(
                attendanceRecords = mutable,
                statusMessage = "Marked all ${if (isTeacher) "teachers" else "students"} Present for $date"
            )
        }
    }

    // --- FEES & FINANCE ---

    fun collectFeePayment(
        student: Student,
        feeType: FeeType,
        billingMonth: String,
        amount: Double,
        paidAmount: Double,
        paymentMode: String
    ): FeeRecord {
        val nextNum = 1041 + _uiState.value.feeRecords.size
        val status = when {
            paidAmount >= amount -> FeeStatus.PAID
            paidAmount > 0 -> FeeStatus.PARTIAL
            else -> FeeStatus.PENDING
        }
        val newRecord = FeeRecord(
            id = "FEE-${System.currentTimeMillis()}",
            receiptNo = "KAA-RCP-2026-$nextNum",
            studentId = student.id,
            studentName = student.fullName,
            branchId = student.branchId,
            courseName = _uiState.value.courseNames(student.courseIds),
            feeType = feeType,
            billingMonth = billingMonth,
            amount = amount,
            paidAmount = paidAmount,
            paymentDate = if (paidAmount > 0) "2026-11-24" else "-",
            paymentMode = paymentMode,
            status = status
        )
        _uiState.update { state ->
            val updatedRevenue = state.monthlyRevenueHistory.mapIndexed { idx, pt ->
                if (idx == state.monthlyRevenueHistory.lastIndex) pt.copy(revenue = pt.revenue + paidAmount) else pt
            }
            val activity = ActivityLog(
                id = "ACT-${System.currentTimeMillis()}",
                title = "Fee Receipt ${newRecord.receiptNo}",
                subtitle = "₹${paidAmount.toInt()} received from ${student.fullName} via $paymentMode",
                timestamp = "Just now",
                category = "Finance"
            )
            state.copy(
                feeRecords = listOf(newRecord) + state.feeRecords,
                monthlyRevenueHistory = updatedRevenue,
                activities = listOf(activity) + state.activities,
                statusMessage = "Payment recorded • Receipt ${newRecord.receiptNo} ready"
            )
        }
        return newRecord
    }

    fun settlePendingFee(feeId: String, mode: String = "UPI / Bank") {
        _uiState.update { state ->
            var delta = 0.0
            val updated = state.feeRecords.map { rec ->
                if (rec.id == feeId) {
                    delta = rec.balanceDue
                    rec.copy(
                        paidAmount = rec.amount,
                        paymentDate = "2026-11-24",
                        paymentMode = mode,
                        status = FeeStatus.PAID
                    )
                } else rec
            }
            val updatedRevenue = state.monthlyRevenueHistory.mapIndexed { idx, pt ->
                if (idx == state.monthlyRevenueHistory.lastIndex) pt.copy(revenue = pt.revenue + delta) else pt
            }
            state.copy(
                feeRecords = updated,
                monthlyRevenueHistory = updatedRevenue,
                statusMessage = "Pending balance settled & official receipt unlocked."
            )
        }
    }

    fun addExpense(title: String, category: String, branchId: String, amount: Double, vendor: String) {
        val exp = ExpenseRecord(
            id = "EXP-${System.currentTimeMillis()}",
            title = title,
            category = category,
            branchId = branchId,
            amount = amount,
            date = "2026-11-24",
            vendor = vendor
        )
        _uiState.update { state ->
            val updatedRevenue = state.monthlyRevenueHistory.mapIndexed { idx, pt ->
                if (idx == state.monthlyRevenueHistory.lastIndex) pt.copy(expenses = pt.expenses + amount) else pt
            }
            state.copy(
                expenses = listOf(exp) + state.expenses,
                monthlyRevenueHistory = updatedRevenue,
                statusMessage = "Expense '${exp.title}' logged."
            )
        }
    }

    // --- EXAMINATIONS & RESULTS ---

    fun createExamination(
        title: String,
        session: String,
        courseId: String,
        branchId: String,
        examDate: String
    ) {
        val exam = Examination(
            id = "EXM-2026-${_uiState.value.examinations.size + 1}",
            title = title,
            session = session,
            courseId = courseId,
            branchId = branchId,
            examDate = examDate
        )
        _uiState.update { state ->
            state.copy(
                examinations = listOf(exam) + state.examinations,
                statusMessage = "Examination '$title' scheduled."
            )
        }
    }

    fun assignExamMarks(
        exam: Examination,
        student: Student,
        theory: Int,
        practical: Int,
        project: Int,
        teamwork: Int,
        remarks: String
    ): ExamResult {
        val courseName = _uiState.value.courses.find { it.id == exam.courseId }?.name ?: "Fine Arts"
        val branchName = _uiState.value.branchName(student.branchId)
        val certId = "KAA-CERT-2026-${8492 + _uiState.value.examResults.size + 1}"
        val result = ExamResult(
            id = "RES-${System.currentTimeMillis()}",
            examId = exam.id,
            examTitle = exam.title,
            session = exam.session,
            studentId = student.id,
            studentName = student.fullName,
            courseName = courseName,
            branchName = branchName,
            theoryMarks = theory.coerceIn(0, exam.maxTheory),
            practicalMarks = practical.coerceIn(0, exam.maxPractical),
            projectMarks = project.coerceIn(0, exam.maxProject),
            teamworkMarks = teamwork.coerceIn(0, exam.maxTeamwork),
            maxTheory = exam.maxTheory,
            maxPractical = exam.maxPractical,
            maxProject = exam.maxProject,
            maxTeamwork = exam.maxTeamwork,
            remarks = remarks.ifBlank { "Commendable artistry and consistent dedication." },
            certificateId = certId,
            issuedDate = "2026-11-24"
        )
        _uiState.update { state ->
            val filtered = state.examResults.filterNot { it.examId == exam.id && it.studentId == student.id }
            val activity = ActivityLog(
                id = "ACT-${System.currentTimeMillis()}",
                title = "Exam Marks Published",
                subtitle = "${student.fullName} scored ${result.totalObtained}/${result.totalMax} (${result.shortGrade})",
                timestamp = "Just now",
                category = "Examination"
            )
            state.copy(
                examResults = listOf(result) + filtered,
                activities = listOf(activity) + state.activities,
                statusMessage = "Marks saved • Marksheet & QR Certificate ($certId) generated."
            )
        }
        return result
    }

    // --- NOTICES ---

    fun publishNotice(title: String, body: String, category: NoticeCategory, audience: String) {
        val notice = AcademyNotice(
            id = "NOT-${System.currentTimeMillis()}",
            title = title,
            body = body,
            category = category,
            date = "2026-11-24",
            targetAudience = audience,
            isRead = false
        )
        _uiState.update {
            it.copy(
                notices = listOf(notice) + it.notices,
                statusMessage = "Notice broadcast to $audience"
            )
        }
    }

    fun markAllNoticesRead() {
        _uiState.update { state ->
            state.copy(notices = state.notices.map { it.copy(isRead = true) })
        }
    }

    // --- SETTINGS & BACKUP ---

    fun updateAcademyInfo(info: AcademyInfo) {
        _uiState.update { it.copy(academyInfo = info, statusMessage = "Academy details updated.") }
    }

    fun updateAcademyLogoUri(uri: String?) {
        _uiState.update {
            it.copy(
                academyInfo = it.academyInfo.copy(logoUri = uri),
                statusMessage = if (uri != null) "Custom academy logo updated." else "Restored official crest logo."
            )
        }
    }

    fun toggleUserAccountActive(userId: String) {
        _uiState.update { state ->
            state.copy(
                accounts = state.accounts.map {
                    if (it.userId == userId && it.role != UserRole.SUPER_ADMIN) it.copy(isActive = !it.isActive) else it
                },
                statusMessage = "Updated portal access for $userId"
            )
        }
    }

    fun performLocalBackup(context: Context) {
        val state = _uiState.value
        val snapshot = AcademySnapshot(
            academyInfo = state.academyInfo,
            accounts = state.accounts,
            branches = state.branches,
            courses = state.courses,
            teachers = state.teachers,
            students = state.students,
            attendanceRecords = state.attendanceRecords,
            feeRecords = state.feeRecords,
            expenses = state.expenses,
            examinations = state.examinations,
            examResults = state.examResults,
            notices = state.notices,
            activities = state.activities,
            monthlyRevenueHistory = state.monthlyRevenueHistory
        )
        repository.exportBackupJson(context, snapshot)
            .onSuccess { file -> postMessage("Backup saved: ${file.name}") }
            .onFailure { err -> postMessage("Backup failed: ${err.message}") }
    }

    fun performLocalRestore(context: Context) {
        repository.restoreLatestBackupSummary(context)
            .onSuccess { summary -> postMessage(summary) }
            .onFailure { err -> postMessage(err.message ?: "Restore failed") }
    }
}

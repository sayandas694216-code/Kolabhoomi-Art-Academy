package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.BranchAttendanceStat
import com.example.data.model.CourseEnrollmentSlice
import com.example.data.model.MonthlyRevenuePoint
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BronzeAccent
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.InstitutionalGold
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RichGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBlueSoft
import com.example.ui.theme.SlateAccent
import com.example.ui.theme.SurfaceMuted
import com.example.ui.theme.TealAccent
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * 1. Interactive Monthly Revenue & Expense Line Graph (Navy Blue & Gold Theme)
 */
@Composable
fun MonthlyRevenueLineChart(
    data: List<MonthlyRevenuePoint>,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return
    var selectedIndex by remember(data.size) { mutableIntStateOf(data.lastIndex) }
    var showExpenses by remember { mutableStateOf(true) }
    val selected = data[selectedIndex.coerceIn(0, data.lastIndex)]
    val maxVal = remember(data) {
        (data.maxOf { maxOf(it.revenue, it.expenses) } * 1.15).coerceAtLeast(1000.0)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("monthly_revenue_line_chart"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Monthly Revenue Trend",
                        style = MaterialTheme.typography.titleLarge,
                        color = DeepNavy
                    )
                    Text(
                        text = "Tap any month node to inspect revenue & margin",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkMuted
                    )
                }
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50.dp))
                        .clickable { showExpenses = !showExpenses },
                    color = if (showExpenses) GoldContainer else SurfaceMuted,
                    border = BorderStroke(1.dp, if (showExpenses) GoldBorder else CardOutline),
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = if (showExpenses) "vs Expenses" else "Revenue Only",
                        style = MaterialTheme.typography.labelSmall,
                        color = DeepNavy,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Callout Banner for Selected Month
            Surface(
                color = DeepNavy,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, InstitutionalGold.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${selected.month} 2026 Revenue",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldBorder
                        )
                        Text(
                            text = formatCurrencyInr(selected.revenue),
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Expenses: ${formatCurrencyInr(selected.expenses)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoyalBlueSoft
                        )
                        Text(
                            text = "Net: ${formatCurrencyInr(selected.revenue - selected.expenses)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = RichGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Line Graph Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .pointerInput(data) {
                            detectTapGestures { tap ->
                                val leftPad = 14.dp.toPx()
                                val rightPad = 14.dp.toPx()
                                val usableW = (size.width - leftPad - rightPad).coerceAtLeast(1f)
                                val stepX = if (data.size > 1) usableW / (data.size - 1) else usableW
                                val nearest = ((tap.x - leftPad) / stepX).toInt().coerceIn(0, data.lastIndex)
                                selectedIndex = nearest
                            }
                        }
                ) {
                    val leftPad = 14.dp.toPx()
                    val rightPad = 14.dp.toPx()
                    val topPad = 16.dp.toPx()
                    val bottomPad = 12.dp.toPx()
                    val chartW = size.width - leftPad - rightPad
                    val chartH = size.height - topPad - bottomPad
                    val stepX = if (data.size > 1) chartW / (data.size - 1) else chartW

                    // Subtle Horizontal Grid Lines
                    for (i in 0..3) {
                        val y = topPad + (chartH / 3f) * i
                        drawLine(
                            color = CardOutline,
                            start = Offset(leftPad, y),
                            end = Offset(size.width - rightPad, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    val revPoints = data.mapIndexed { idx, pt ->
                        val x = leftPad + idx * stepX
                        val y = topPad + chartH * (1f - (pt.revenue / maxVal).toFloat())
                        Offset(x, y)
                    }

                    // Gradient Area Fill under Revenue Line
                    val areaPath = Path().apply {
                        moveTo(revPoints.first().x, topPad + chartH)
                        revPoints.forEach { lineTo(it.x, it.y) }
                        lineTo(revPoints.last().x, topPad + chartH)
                        close()
                    }
                    drawPath(
                        path = areaPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                RoyalBlue.copy(alpha = 0.24f),
                                InstitutionalGold.copy(alpha = 0.04f)
                            ),
                            startY = topPad,
                            endY = topPad + chartH
                        )
                    )

                    // Optional Expense Line in Subtle Gold
                    if (showExpenses) {
                        val expPoints = data.mapIndexed { idx, pt ->
                            val x = leftPad + idx * stepX
                            val y = topPad + chartH * (1f - (pt.expenses / maxVal).toFloat())
                            Offset(x, y)
                        }
                        val expPath = Path().apply {
                            moveTo(expPoints.first().x, expPoints.first().y)
                            for (i in 1 until expPoints.size) {
                                val prev = expPoints[i - 1]
                                val curr = expPoints[i]
                                val cx = (prev.x + curr.x) / 2f
                                cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
                            }
                        }
                        drawPath(
                            path = expPath,
                            color = InstitutionalGold,
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }

                    // Smooth Revenue Line in Deep Navy
                    val revPath = Path().apply {
                        moveTo(revPoints.first().x, revPoints.first().y)
                        for (i in 1 until revPoints.size) {
                            val prev = revPoints[i - 1]
                            val curr = revPoints[i]
                            val cx = (prev.x + curr.x) / 2f
                            cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
                        }
                    }
                    drawPath(
                        path = revPath,
                        color = DeepNavy,
                        style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    // Vertical Guide Line at Selected Point
                    val selPt = revPoints[selectedIndex.coerceIn(0, revPoints.lastIndex)]
                    drawLine(
                        color = InstitutionalGold.copy(alpha = 0.7f),
                        start = Offset(selPt.x, topPad),
                        end = Offset(selPt.x, topPad + chartH),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Data Point Nodes
                    revPoints.forEachIndexed { idx, pt ->
                        val isSelected = idx == selectedIndex
                        if (isSelected) {
                            drawCircle(color = InstitutionalGold.copy(alpha = 0.25f), radius = 11.dp.toPx(), center = pt)
                            drawCircle(color = RichGold, radius = 6.dp.toPx(), center = pt)
                            drawCircle(color = DeepNavy, radius = 3.dp.toPx(), center = pt)
                        } else {
                            drawCircle(color = PureWhite, radius = 4.5.dp.toPx(), center = pt)
                            drawCircle(color = RoyalBlue, radius = 3.dp.toPx(), center = pt)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Interactive Month Selector Axis Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                data.forEachIndexed { idx, pt ->
                    val isSel = idx == selectedIndex
                    Text(
                        text = pt.month,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSel) DeepNavy else InkMuted,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) GoldContainer else Color.Transparent)
                            .clickable { selectedIndex = idx }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                ChartLegendDot(color = DeepNavy, label = "Gross Revenue")
                if (showExpenses) {
                    ChartLegendDot(color = InstitutionalGold, label = "Operating Expenses")
                }
            }
        }
    }
}

/**
 * 2. Interactive Branch Attendance Statistics Bar Chart (Navy Blue & Gold Theme)
 */
@Composable
fun BranchAttendanceBarChart(
    stats: List<BranchAttendanceStat>,
    modifier: Modifier = Modifier
) {
    if (stats.isEmpty()) return
    var selectedIdx by remember(stats.size) { mutableIntStateOf(0) }
    val selected = stats[selectedIdx.coerceIn(0, stats.lastIndex)]

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("branch_attendance_bar_chart"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Attendance Across Branches",
                style = MaterialTheme.typography.titleLarge,
                color = DeepNavy
            )
            Text(
                text = "Tap any branch bar to inspect Present, Leave & Absent rates",
                style = MaterialTheme.typography.bodySmall,
                color = InkMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Selected Branch Inspection Strip
            Surface(
                color = SurfaceMuted,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selected.branchName,
                            style = MaterialTheme.typography.titleSmall,
                            color = DeepNavy,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Code: ${selected.branchCode} • ${selected.totalMarked} logs tracked",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniRateBadge("P", "${selected.presentPercent.toInt()}%", DeepNavy, PureWhite)
                        MiniRateBadge("L", "${selected.leavePercent.toInt()}%", GoldContainer, DeepNavy)
                        MiniRateBadge("A", "${selected.absentPercent.toInt()}%", Color(0xFFFCE8EA), CrimsonAlert)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Animated Interactive Bars
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(164.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                stats.forEachIndexed { idx, item ->
                    val isSelected = idx == selectedIdx
                    val animatedHeight by animateFloatAsState(
                        targetValue = (item.presentPercent / 100f).coerceIn(0.15f, 1f),
                        animationSpec = spring(dampingRatio = 0.7f, stiffness = 280f),
                        label = "bar_height_$idx"
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedIdx = idx }
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text(
                            text = "${item.presentPercent.toInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) DeepNavy else InkSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.58f)
                                .height(108.dp),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            // Track
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(108.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SurfaceMuted)
                            )
                            // Active Bar Fill
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height((108f * animatedHeight).dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isSelected) {
                                            Brush.verticalGradient(listOf(RichGold, DeepNavy))
                                        } else {
                                            Brush.verticalGradient(listOf(RoyalBlueBright, RoyalBlue))
                                        }
                                    )
                                    .then(
                                        if (isSelected) Modifier.border(1.5.dp, InstitutionalGold, RoundedCornerShape(10.dp))
                                        else Modifier
                                    )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = item.branchCode,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) DeepNavy else InkMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniRateBadge(prefix: String, value: String, bg: Color, fg: Color) {
    Surface(color = bg, shape = RoundedCornerShape(8.dp)) {
        Text(
            text = "$prefix $value",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
        )
    }
}

/**
 * 3. Interactive Course Enrollment Distribution Pie / Donut Chart (Navy Blue & Gold Palette)
 */
@Composable
fun CourseEnrollmentPieChart(
    slices: List<CourseEnrollmentSlice>,
    modifier: Modifier = Modifier
) {
    val nonZero = remember(slices) { slices.filter { it.studentCount > 0 }.ifEmpty { slices } }
    if (nonZero.isEmpty()) return

    var selectedIdx by remember(nonZero.size) { mutableIntStateOf(0) }
    val totalEnrollments = remember(nonZero) { nonZero.sumOf { it.studentCount }.coerceAtLeast(1) }
    val selected = nonZero[selectedIdx.coerceIn(0, nonZero.lastIndex)]

    val palette = remember {
        listOf(
            DeepNavy,
            InstitutionalGold,
            RoyalBlueBright,
            TealAccent,
            BronzeAccent,
            IndigoAccent,
            SlateAccent,
            AmberWarning
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("course_enrollment_pie_chart"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, CardOutline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Course Enrollment Distribution",
                style = MaterialTheme.typography.titleLarge,
                color = DeepNavy
            )
            Text(
                text = "Tap any segment or course label to inspect enrollment share",
                style = MaterialTheme.typography.bodySmall,
                color = InkMuted
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Interactive Donut Pie Canvas
                Box(
                    modifier = Modifier.size(168.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .size(168.dp)
                            .pointerInput(nonZero) {
                                detectTapGestures { offset ->
                                    val cx = size.width / 2f
                                    val cy = size.height / 2f
                                    val dist = hypot(offset.x - cx, offset.y - cy)
                                    if (dist in (size.width * 0.16f)..(size.width * 0.5f)) {
                                        var angle = (atan2(offset.y - cy, offset.x - cx) * 180.0 / PI).toFloat()
                                        angle = (angle + 90f + 360f) % 360f
                                        var accum = 0f
                                        nonZero.forEachIndexed { i, slice ->
                                            val sweep = (slice.studentCount.toFloat() / totalEnrollments) * 360f
                                            if (angle in accum..(accum + sweep)) {
                                                selectedIdx = i
                                            }
                                            accum += sweep
                                        }
                                    }
                                }
                            }
                    ) {
                        var startAngle = -90f
                        nonZero.forEachIndexed { idx, slice ->
                            val sweep = (slice.studentCount.toFloat() / totalEnrollments) * 360f
                            val isSelected = idx == selectedIdx
                            val strokeW = if (isSelected) 30.dp.toPx() else 23.dp.toPx()
                            val inset = if (isSelected) 16.dp.toPx() else 20.dp.toPx()
                            drawArc(
                                color = palette[idx % palette.size],
                                startAngle = startAngle,
                                sweepAngle = (sweep - 2.5f).coerceAtLeast(2f),
                                useCenter = false,
                                topLeft = Offset(inset, inset),
                                size = Size(size.width - inset * 2, size.height - inset * 2),
                                style = Stroke(width = strokeW, cap = StrokeCap.Butt)
                            )
                            startAngle += sweep
                        }
                    }

                    // Center KPI Readout
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val share = (selected.studentCount * 100.0) / totalEnrollments
                        Text(
                            text = String.format(Locale.US, "%.0f%%", share),
                            style = MaterialTheme.typography.headlineMedium,
                            color = DeepNavy,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${selected.studentCount} seats",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkSecondary
                        )
                    }
                }

                // Interactive Color Legend List
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    nonZero.take(6).forEachIndexed { idx, slice ->
                        val isSel = idx == selectedIdx
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) GoldContainer else Color.Transparent)
                                .clickable { selectedIdx = idx }
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(palette[idx % palette.size])
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = slice.courseName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = InkPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${slice.studentCount}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = DeepNavy
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            // Selected Course Highlight Bar
            Surface(
                color = RoyalBlueSoft,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selected.courseName,
                        style = MaterialTheme.typography.labelLarge,
                        color = DeepNavy
                    )
                    Text(
                        text = "Est. Monthly Tuition: ${formatCurrencyInr(selected.monthlyRevenuePotential)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = RoyalBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun ChartLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = InkSecondary)
    }
}
